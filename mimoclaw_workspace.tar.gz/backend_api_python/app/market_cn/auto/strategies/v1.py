"""strategies/v1.py — V1 追板策略 (StrategyBase 插件实现, Phase 2 迁移)

实现已迁移至本文件; core.v1_today_d0_signals 为 facade 转发到这里。

入场 (D0 盘后扫描 → D1 竞价):
  D0 四因子: 涨停(0.98x阈值) + 20日涨>30% + D-1回调[-10%,-3%) + OBV 5日上升 + D-1非放量(<1.5x 5日均量)
  因子5: 纯单板过热过滤 (前10天无涨停时: MACD柱<2 且 布林带宽<45%, 剔除过热)
  竞价: main: gap>=-3% 且非[3%,5%); gem: -5%<=gap<5% (monitor._gap_buyable v1 分支)
  U1~U4: prefilter_anchor='signal' (D0 即涨停日, 锚定信号日评估)

出场 (收盘重放, monitor v1 分支):
  止损-10% / 追踪-5%(自入场日峰值, held>1) / 到期7天

易错点:
  - D-1回调区间是 [-10%, -3%) 左闭右开; D0 涨停判定是 0.98x 板块阈值 (近似涨停);
  - ⚠ d1_change 是 D1 **收盘** 值, 用它过滤 D1 **开盘** 入场 = 前视 (2026-09-30 修)。
    实盘 entry_decision 只用 gap; d1_change<0 在实盘属 confirm_decision(15:00 weak)
    ⇒ 后果是「D2 开盘清仓」, 已由 _run_backtest._pre_exit 实现 ⇒ 回测侧默认关闭
    (PARAMS.require_d1_close_up=False; 开=True 可复现旧口径做对照, 勿用于生产)。
  - OBV 从 i-20 起累计且 j=0 不计 — 勿"优化"起始点, 会改变边界信号。
"""
from __future__ import annotations

from app.utils.indicators import calc_bollinger_bw, calc_macd
from app.market_cn.auto.core.market import get_board_name, get_board_type, is_limit_up
from app.market_cn.auto.strategies import register
from app.market_cn.auto.strategies.base import (
    ConfirmDecision, EntryDecision, ExitDecision, ScanSpec, Signal, StrategyBase,
    data_end_close,
)

STRATEGY_KEY = "v1"
STRATEGY_LABEL = "V1"

PARAMS = {
    "ret_20d_min": 30.0,
    "d_1_pullback_min": -10.0,
    "d_1_pullback_max": -3.0,
    "obv_filter": True,
    "d_1_vol_max": 1.5,
    # 出场 (monitor v1 分支)
    "stop": -10.0,
    "trail": -5.0,
    "hold": 7,
    # 竞价 gap (monitor._gap_buyable v1 分支)
    "min_gap_main": -3.0,
    "min_gap_gem": -5.0,
    "gem_gap_max": 5.0,
    "main_gap_band_lo": 3.0,     # 主板高开 3~5% 不入场 (v4数据驱动)
    "main_gap_band_hi": 5.0,
    # ⚠ 前视开关 (2026-09-30): D1 收盘涨跌(d1_change<0)过滤 D1 开盘入场 = 未来信息。
    #   默认 False (=实盘口径); True 仅用于复现旧回测口径做对照。
    "require_d1_close_up": False,
}


def _signal_to_legacy_dict(sig: Signal, code: str) -> dict:
    """Signal → 旧 v1_today_d0_signals 的 dict 形态 (facade 兼容层)。"""
    ex = sig.extra or {}
    return {
        "code": code,
        "board": get_board_name(code),
        "path": "v1",
        "path_label": "V1",
        "d0_date": sig.time,
        "d0_close": ex.get("d0_close"),
        "ret_20d": ex.get("ret_20d"),
        "d_1_change": ex.get("d_1_change"),
        "turnover_anchor": ex.get("turnover_anchor"),
        "turnover_anchor_total": ex.get("turnover_anchor_total"),
        "buy_mode": "next_open",
    }


@register
class V1Strategy(StrategyBase):
    key = STRATEGY_KEY
    name = STRATEGY_LABEL
    prefilter_anchor = "signal"        # D0 即涨停日, U1~U4 锚定信号日评估
    entry_style = "v1"
    scan_spec = ScanSpec(kind="daily_close", after_events=("daily_1d", "lhb"))
    default_params = dict(PARAMS)
    # 探针 day-stage 归属 (越靠后=离信号越近)
    PROBE_STAGE_RANK = {"lu": 1, "ret20": 2, "pullback": 3, "obv": 4, "vol": 5,
                        "overheat": 6, "prefilter": 7, "d1_gap": 8, "d1_chg": 8,
                        "d1_band": 8, "engine_skip": 9, "signal": 10}

    # ---- 信号判定 ----
    def scan_signals(self, bars, code, *, as_of=None, ctx=None, probe=None, **params):
        """D0 四因子 → Signal (至多1笔)。as_of=k: 只用 bars[:k+1], 末根为 D0。

        probe: 调试探针 (probe.Probe / DayTrace shim), None=零开销 —
        各过滤门 TRACE 式打点, 存档供 AI 离线分析, 与判定行为无关。"""
        p = self.params(params or None)
        if as_of is not None:
            bars = bars[:as_of + 1]
        result = []
        n = len(bars)
        if n < 26:
            return result
        i = n - 1
        if i < 2:
            return result
        board_type = get_board_type(code)
        threshold = 0.098 if board_type == "main" else 0.198
        d0 = bars[i]
        d_1 = bars[i - 1]
        d_2 = bars[i - 2]
        if d_2["close"] <= 0 or d_1["close"] <= 0:
            return result
        # 探针 shim (TRACE 宏语义): probe=None 时零开销
        if probe is not None:
            _pd = str(d0["time"])[:10]

            def _tr(stage, **kw):
                probe.trace(stage, code=code, d0_date=_pd, **kw)
        else:
            _tr = None

        if (d0["close"] / d_1["close"] - 1) < threshold * 0.98:
            if _tr:
                _tr("lu", d0_pct_chg=round((d0["close"] / d_1["close"] - 1) * 100, 2))
            return result

        # === 因子1: 强趋势 20日涨>ret_20d_min% ===
        if i < 20 or bars[i - 20]["close"] <= 0:
            return result
        ret_20d = (d0["close"] / bars[i - 20]["close"] - 1) * 100
        if ret_20d < p["ret_20d_min"]:
            if _tr:
                _tr("ret20", ret_20d=round(ret_20d, 2))
            return result

        # === 因子2: D-1回调 [d_1_pullback_min, d_1_pullback_max) ===
        d_1_change = (d_1["close"] / d_2["close"] - 1) * 100
        if d_1_change < p["d_1_pullback_min"] or d_1_change >= p["d_1_pullback_max"]:
            if _tr:
                _tr("pullback", d_1_change=round(d_1_change, 2))
            return result

        # === 因子3: OBV 5日趋势上升 ===
        if p["obv_filter"]:
            obv = 0
            obv_list = []
            for j in range(max(0, i - 20), i + 1):
                if j > 0:
                    if bars[j]["close"] > bars[j - 1]["close"]:
                        obv += bars[j]["volume"]
                    elif bars[j]["close"] < bars[j - 1]["close"]:
                        obv -= bars[j]["volume"]
                obv_list.append(obv)
            if len(obv_list) >= 5 and obv_list[-1] - obv_list[-5] <= 0:
                if _tr:
                    _tr("obv")
                return result

        # === 因子4: D-1非放量 < d_1_vol_max x 5日均量 ===
        if i >= 6:
            vol_ma5_d1 = sum(bars[j]["volume"] for j in range(i - 6, i - 1)) / 5
            if vol_ma5_d1 > 0 and d_1["volume"] / vol_ma5_d1 >= p["d_1_vol_max"]:
                if _tr:
                    _tr("vol", vol_r=round(d_1["volume"] / vol_ma5_d1, 2))
                return result

        # === 因子5: 纯单板过热过滤 (仅当前10天无涨停时生效) ===
        has_recent_lu = False
        for j in range(max(1, i - 10), i):
            if j >= 1 and is_limit_up(bars[j]["close"], bars[j - 1]["close"], board_type):
                has_recent_lu = True
                break
        if not has_recent_lu:
            closes = [bars[j]["close"] for j in range(i + 1)]
            _, _, hist = calc_macd(closes)
            macd_h = hist[-1] if hist else None
            boll_bw = calc_bollinger_bw(closes)
            if macd_h is not None and macd_h >= 2:
                if _tr:
                    _tr("overheat", reason="macd_hist", macd_h=round(macd_h, 2))
                return result
            if boll_bw is not None and boll_bw >= 45:
                if _tr:
                    _tr("overheat", reason="boll_bw", boll_bw=round(boll_bw, 2))
                return result

        circ = float((params.get("stock_info") or {}).get("circ_shares") or 0)
        total = float((params.get("stock_info") or {}).get("total_shares") or 0)
        d0_close = round(d0["close"], 3)
        if _tr:
            _tr("signal", ret_20d=round(ret_20d, 2), d_1_change=round(d_1_change, 2))
        result.append(Signal(
            code=code,
            time=d0["time"],
            score=int(min(99, max(0, ret_20d))),
            price=d0_close,
            label="V1",
            extra={
                "path": "v1",
                "path_label": "V1",
                "d0_date": d0["time"],
                "d0_close": d0_close,
                "ret_20d": round(ret_20d, 2),
                "d_1_change": round(d_1_change, 2),
                "turnover_anchor": round(d0["volume"] / circ * 100, 2) if circ > 0 else None,
                "turnover_anchor_total": round(d0["volume"] / total * 100, 2) if total > 0 else None,
                "buy_mode": "next_open",
            },
        ))
        return result

    # ---- D1 竞价处置 (monitor ~09:25) ----
    def entry_decision(self, row, snap=None, **params):
        """v1 竞价规则: main: gap>=-3% 且非[3%,5%); gem: -5%<=gap<5%。

        gap = (open/prev_close-1)*100, prev_close 取快照 previousClose 兜底 signal_price。
        """
        p = self.params(params or None)
        if not snap:
            return EntryDecision(False, "无竞价快照")
        open_px = float(snap.get("open") or snap.get("last") or 0)
        if open_px <= 0:
            return EntryDecision(False, "开盘价缺失")
        prev_close = float(snap.get("previousClose") or row.get("signal_price") or 0)
        if prev_close <= 0:
            return EntryDecision(False, "昨收缺失")
        gap = (open_px / prev_close - 1) * 100
        gem = get_board_type(row.get("code", "")) == "gem_star"
        if gem:
            ok = p["min_gap_gem"] <= gap < p["gem_gap_max"]
        else:
            ok = gap >= p["min_gap_main"] and not (p["main_gap_band_lo"] <= gap < p["main_gap_band_hi"])
        if ok:
            return EntryDecision(True, f"gap={gap:.2f}% 可买")
        return EntryDecision(False, f"gap={gap:.2f}% 越界")

    # ---- 15:00 收盘确认 ----
    def confirm_decision(self, row, snap=None, **params):
        """v1 日内动量确认: d1_chg<0 或 日内动量(entry_gap 后)<3% → weak (不确认)。

        snap={"series":[...当日快照序列]}; d1_chg 按 signal_price 基准, d1_vol_r=日内动量
        (旧 evaluate_confirm 口径)。返回 None = 无法判定, monitor 不转移。
        """
        series = (snap or {}).get("series") if isinstance(snap, dict) else None
        if not series:
            return None
        last_r = series[-1]
        prev_close = float(row.get("signal_price") or 0)
        if prev_close <= 0:
            return None
        d1_chg = (float(last_r["last"] or 0) / prev_close - 1) * 100
        entry_gap = float((row.get("extra") or {}).get("entry_gap") or 0)
        intraday = d1_chg - entry_gap
        if d1_chg < 0 or intraday < 3.0:
            return ConfirmDecision(False, "D1日内动量<3%,D2开盘清仓",
                                   d1_chg=round(d1_chg, 2), detail={"confirm": "weak"})
        return ConfirmDecision(True, "ok", d1_chg=round(d1_chg, 2),
                               d1_vol_r=round(intraday, 2),
                               detail={"confirm": "ok", "confirm_strong": False})

    def quality_key(self, row):
        """V1 质量排序: 20日涨幅越大越优先。"""
        extra = row.get("extra") or {}
        return (extra.get("ret_20d") or 0,)

    def initial_stop(self, code, entry_price):
        """-10% (板块不分档)。"""
        return round(entry_price * (1 - 10.0 / 100), 3)

    # ---- 出场判定 ----
    def exit_decision(self, row, snap=None, **params):
        """收盘重放: 止损-10 / 追踪-5(自入场日峰值, held>1) / 到期7天。

        snap={"mode":"day_close","bars":[...],"entry_idx":int}; live 模式无特殊规则 → hold
        (盘中硬止损兜底在 monitor 主循环)。"""
        p = self.params(params or None)
        if not isinstance(snap, dict) or snap.get("mode") != "day_close":
            return ExitDecision("hold")
        bars = snap.get("bars")
        entry_idx = snap.get("entry_idx")
        entry_price = float(row.get("entry_price") or 0)
        if bars is None or entry_idx is None or entry_price <= 0:
            return ExitDecision("hold")
        stop, trail, hold = p["stop"], p["trail"], p["hold"]
        today_idx = len(bars) - 1
        held = today_idx - entry_idx + 1
        entry_seg = bars[entry_idx:today_idx + 1]
        peak = max(float(b["high"]) for b in entry_seg)
        last_bar = bars[-1]
        # 2026-10-07 P1-④ (与 base.exit_decision 同口径): 止损补 T+1 守卫 —— 原裸判,
        #   held=1 (入场当日) 触及止损线即卖, 违反 A股 T+1。
        if held > 1 and last_bar["low"] <= entry_price * (1 + stop / 100):
            return ExitDecision("exit", reason=f"止损{stop}%", price=entry_price * (1 + stop / 100))
        if held > 1 and last_bar["low"] <= peak * (1 + trail / 100):
            return ExitDecision("exit", reason=f"追踪止损{trail}%", price=peak * (1 + trail / 100))
        if held >= hold:
            return ExitDecision("exit", reason=f"持仓到期{hold}天", price=float(last_bar["close"]))
        return ExitDecision("hold")

    # ---- 回测钩子 (2026-09-10 自 backtest.backtest_v1_stock 逐字搬入, 对数零差异) ----
    def backtest_stock(self, bars, code, stock_info=None, use_prefilter=True,
                      probe=None):
        """单股 V1 全历史回测 (D0四因子判定, 次日开盘买, D1入场过滤)。

        D1 过滤 (gap/高开区间) 属回测引擎 D1 口径, 不在 entry_decision — 勿合并;
        ⚠ d1_change(收盘) 过滤已默认关闭 (见 PARAMS.require_d1_close_up), 属前视;
        出场模拟 _run_backtest 在本文件 (策略专用出场规则, 2026-09-10 晚下沉)。
        """
        from app.market_cn.auto.core.filters import unified_prefilter
        from app.market_cn.auto.probe import DayTrace
        # 参数接线 (2026-09-13 修): 原入场五参数/D1过滤/出场均硬编码字面量 (kwargs
        # 压过实例覆写) → param_scan 网格无效。统一改从 params(None) 取:
        # 默认=PARAMS 同值 (行为零差异), 实例 default_params 覆写即生效。
        _p = self.params(None)
        board_type = get_board_type(code)
        n = len(bars)
        if n < 30:
            return []
        trades = []

        for i in range(25, n - 1):
            # debug 模式: day_tr 聚合该日判定门落点 (probe=None 零开销)
            day_tr = DayTrace() if probe is not None else None
            # 逐日候选判定: 与实盘 scan 完全同一函数 (切片 as_of 语义; 经 facade 等价路径)
            sigs = [_signal_to_legacy_dict(s, code) for s in self.scan_signals(
                bars[:i + 1], code,
                ret_20d_min=_p["ret_20d_min"], d_1_pullback_min=_p["d_1_pullback_min"],
                d_1_pullback_max=_p["d_1_pullback_max"], obv_filter=_p["obv_filter"],
                d_1_vol_max=_p["d_1_vol_max"], stock_info=stock_info,
                probe=day_tr)]
            if not sigs:
                if probe is not None:
                    self._probe_day(probe, day_tr, bars, i, code, stock_info)
                continue
            sig = sigs[0]

            # U1~U4 (信号日D0收盘可知; 20日涨幅>=30%已隐含U4)
            if use_prefilter:
                ok, fails = unified_prefilter(bars, i, code, stock_info)
                if not ok:
                    if probe is not None:
                        self._probe_day(probe, day_tr, bars, i, code, stock_info,
                                        stage="prefilter", sig=sig, u_fails=fails)
                    continue

            # 入场: 次日开盘价 + D1当日过滤
            d0 = bars[i]
            d1 = bars[i + 1]
            entry_price = d1["open"]
            if entry_price <= 0:
                continue
            entry_idx = i + 1
            entry_date = d1["time"]
            d1_change = (d1["close"] / d0["close"] - 1) * 100
            d1_gap = (d1["open"] / d0["close"] - 1) * 100
            min_d1_gap = _p["min_gap_main"] if board_type == "main" else _p["min_gap_gem"]
            if d1_gap < min_d1_gap:
                if probe is not None:
                    self._probe_day(probe, day_tr, bars, i, code, stock_info,
                                    stage="d1_gap", sig=sig,
                                    extra={"d1_gap": round(d1_gap, 2)})
                continue
            # ⚠ 2026-09-30 前视修复: 下面这行用 D1 **收盘** (d1_change) 决定是否已在
            #   D1 **开盘** 买入 —— 属于未来信息。实盘无此过滤 (entry_decision 只用 gap);
            #   实盘里 d1_change<0 的语义是 confirm_decision(15:00) 判 weak ⇒ D2 开盘清仓,
            #   已由 _run_backtest._pre_exit 正确实现。旧口径等于把该批交易整笔删除 ——
            #   实测被剔批次均值 -7.23%/胜率 4.5% (全市场见
            #   analysis_output/v1入场前视修复_20260930.md) ⇒ 回测收益系统性虚高。
            #   现由 PARAMS.require_d1_close_up 控制, 默认 False (无前视, 对齐实盘)。
            if _p.get("require_d1_close_up") and d1_change < 0:
                if probe is not None:
                    self._probe_day(probe, day_tr, bars, i, code, stock_info,
                                    stage="d1_chg", sig=sig,
                                    extra={"d1_change": round(d1_change, 2)})
                continue
            if board_type == "gem_star" and d1_gap >= _p["gem_gap_max"]:
                if probe is not None:
                    self._probe_day(probe, day_tr, bars, i, code, stock_info,
                                    stage="d1_band", sig=sig,
                                    extra={"d1_gap": round(d1_gap, 2), "board": "gem_star"})
                continue
            # 主板高开3%~5%不入场 (v4数据驱动)
            if board_type == "main" and _p["main_gap_band_lo"] <= d1_gap < _p["main_gap_band_hi"]:
                if probe is not None:
                    self._probe_day(probe, day_tr, bars, i, code, stock_info,
                                    stage="d1_band", sig=sig,
                                    extra={"d1_gap": round(d1_gap, 2), "board": "main"})
                continue

            d1_limit_up_val = is_limit_up(d1["close"], d0["close"], board_type)
            bt = _run_backtest(bars, entry_idx, entry_price, _p["hold"], _p["stop"],
                              _p["trail"], board_type, is_v1=True,
                              d1_limit_up=d1_limit_up_val, d1_change=d1_change,
                              d1_gap=d1_gap)
            if not bt:
                # 2026-10-08 口径分歧 #1 修复：数据结束未平 → 末日收盘平仓（原直接丢弃）。
                # 口径唯一实现见 base.data_end_close；与 core/replay.REASON_DATA_END 对齐。
                bt = data_end_close(bars, entry_idx, entry_price)
            if not bt:
                if probe is not None:
                    self._probe_day(probe, day_tr, bars, i, code, stock_info,
                                    stage="engine_skip", sig=sig)
                continue

            if probe is not None:
                self._probe_day(
                    probe, day_tr, bars, i, code, stock_info, stage="signal",
                    sig=sig, extra={"engine": {k: bt.get(k) for k in
                                               ("return_pct", "peak_return_pct",
                                                "exit_reason", "exit_day")}})
            trades.append({
                **sig,
                "entry_date": entry_date,
                "entry_price": round(entry_price, 3),
                "buy_mode": "next_open",
                "d1_change": round(d1_change, 2),
                "d1_gap": round(d1_gap, 2),
                "intraday": round(d1_change - d1_gap, 2),
                **bt,
            })

        return trades


# ================================================================
# 出场模拟 (2026-09-10 晚自 backtest.py 下沉回归本文件 — 出场规则是策略专用,
# 通用流水线不承载策略专属出场; 逐字搬运, 回归以三策略对数验证)
# ================================================================
from app.market_cn.auto.core.exec import (
    fill_blocked_by_limit_dn,
    fill_on_gap,
    is_one_word_limit_dn,
    limit_dn_price as _limit_dn_price,
)


def _run_backtest(bars, entry_idx, entry_price, hold_days=7, stop_loss=-10.0, trailing_stop=-8.0, board_type="main", peak_exit=False, is_v1=False, d1_limit_up=None, d1_change=None, d1_gap=None):
    """V1/通用出场 — 2026-09-26 P1-7: 骨架上收 core.exit_engines.run_trail_stop。

    现实约束 (T+1 / 跳空 / 跌停顺延) 已在引擎内按 MarketSpec 处理:
      spec.intraday_t0=false → 最早 d=2 卖 (A股); true → d=1 (HK/US)。
    本函数只保留 V1 专属:
      - d1_limit_up 判定 (若调用方未传入);
      - D1 日内动量 <3% → D2 开盘清仓 (pre_exit 钩子)。
    """
    if entry_price <= 0 or entry_idx >= len(bars):
        return None
    from app.market_cn.auto.core.exit_engines import run_trail_stop

    # d1_limit_up: 若外部未传入则在回测内计算 (兼容旧调用)
    if d1_limit_up is None:
        d1_limit_up = False
        limit_threshold = 0.098 if board_type == "main" else 0.198
        if entry_idx + 1 < len(bars):
            d1_bar = bars[entry_idx + 1]
            d1_ret = (float(d1_bar["close"]) / entry_price - 1)
            if d1_ret >= limit_threshold * 0.98:
                d1_limit_up = True

    def _pre_exit(d, b, peak, peak_prev):
        # V1出场 (v3): D1日内动量<3% → D2开盘清仓
        if not (is_v1 and d == 2):
            return None
        if d1_change is not None and d1_gap is not None:
            intraday = d1_change - d1_gap
        else:
            d1_bar = bars[entry_idx]
            d0_close = bars[entry_idx - 1]["close"] if entry_idx > 0 else entry_price
            intraday = (float(d1_bar["close"]) - float(d1_bar["open"])) / d0_close * 100 if d0_close > 0 else 0
        return "open" if intraday < 3 else None

    result = run_trail_stop(
        bars, entry_idx, entry_price,
        hold_days=hold_days, stop_loss=stop_loss, trailing_stop=trailing_stop,
        board_type=board_type, peak_exit=peak_exit,
        pre_exit=_pre_exit if is_v1 else None,
    )
    if result is not None and d1_limit_up:
        result["d1_limit_up"] = d1_limit_up
    return result


# ---- exit_modes 注册 (2026-09-26 P1-9 层反转) ----
def _exit_v1_combo(bars, entry_idx, entry_price, *, code, board_type, params, diag):
    """V1 combo 出场 (止损/追踪/到期 + D1 动量清仓) — 供 YAML exit.mode=v1_combo。"""
    return _run_backtest(
        bars, entry_idx, entry_price,
        params["hold"], params["stop"], params["trail"], board_type,
        is_v1=True,
        d1_limit_up=diag.get("d1_limit_up"),
        d1_change=diag.get("d1_change"),
        d1_gap=diag.get("d1_gap"),
    )


from app.market_cn.auto.core.exit_modes import register_exit as _register_exit
_register_exit("v1_combo", _exit_v1_combo)


# ================================================================
# 门表回测编排 (2026-09-28 分层改造: 自 core/runtime/evaluate.py **纯搬运**下沉)
# ----------------------------------------------------------------
# 为什么搬回来: 编排是策略的一部分 (枚举顺序/去重键/展示字段集/入场腿), 放在 core
# 会让"改 g56 口径"变成改架构层, 且 core 反过来惰性 import strategies.* (层反转)。
# 自注册到 core/runtime/flows 注册表 → core 只查表, 未登记即 fail-fast (不再静默落 v1)。
# ⚠ 搬运要求: 签名与语义**逐字不变**; 逐笔等价回归见
#    analysis_output/auto架构分层_20260928.md
# ================================================================

from typing import Any, Dict, List

from app.market_cn.auto.core.entry_modes import resolve_entry
from app.market_cn.auto.core.exit_modes import run_exit
from app.market_cn.auto.core.filters import unified_prefilter
from app.market_cn.auto.core.runtime.flows import register_day_flow

def _backtest_day_flow(bars, code, spec, ev, board_type, stock_info, use_prefilter):
    """门表版 V1 全历史回测，返回 trades 列表（与 v1.backtest_stock 逐笔等价）。

    编排逐字镜像 v1.backtest_stock：逐日候选判定（门表求值）→ U1~U4 锚定 D0 →
    入场=entry_modes(open + gap 过滤) → 出场=exit_modes(v1_combo，含 V1 动量 D2 清仓)。
    v1 原版无去重 ±4（本路径不施加）；起点/最小长度由 meta.day_start / day_min_n 声明。
    """
    n = len(bars)
    if n < int(spec.meta.get("day_min_n", 30)):
        return []
    _p = spec.params
    trades: List[Dict[str, Any]] = []

    for i in range(int(spec.meta.get("day_start", 25)), n - 1):
        # D0 逐日判定（门表一次性求所有门，与 scan_signals 同一逻辑）
        ok, _ = ev.evaluate_all(bars, i, _p)
        if not ok:
            continue

        # U1~U4（信号日 D0 锚定，v1 prefilter_anchor='signal'）
        if use_prefilter:
            ok, _ = unified_prefilter(bars, i, code, stock_info, spec.market_spec)
            if not ok:
                continue

        # 入场 = entry_modes（open + gap 过滤；阈值来自 YAML entry 块，可引用 params 名）
        d0 = bars[i]
        site, _reason = resolve_entry(spec.entry, bars, i, board_type, _p)
        if site is None:
            continue
        entry_idx = site["entry_idx"]
        entry_price = site["entry_price"]
        entry_date = site["entry_date"]
        d1_gap = site["diag"]["d1_gap"]
        d1_change = site["diag"]["d1_change"]

        # 信号附字段（与 _signal_to_legacy_dict + backtest_stock 完全一致）
        d_1 = bars[i - 1]
        d_2 = bars[i - 2]
        # 20 日收益 (信号展示字段; 与 v1 参考版同式)。⚠ 2026-09-28 审计 P2: 原无零值守卫,
        # 参照 close<=0 的脏数据会在此抛 ZeroDivisionError 打断整轮回测 (v1.py:119 有守卫)。
        _ref20 = float(bars[i - 20]["close"])
        ret_20d = (float(d0["close"]) / _ref20 - 1) * 100 if _ref20 > 0 else None
        d_1_change = (float(d_1["close"]) / float(d_2["close"]) - 1) * 100
        circ = float((stock_info or {}).get("circ_shares") or 0)
        total = float((stock_info or {}).get("total_shares") or 0)
        sig = {
            "code": code,
            "board": get_board_name(code, spec.market_spec),
            "path": "v1",
            "path_label": "V1",
            "d0_date": d0["time"],
            "d0_close": round(float(d0["close"]), 3),
            "ret_20d": round(ret_20d, 2) if ret_20d is not None else None,
            "d_1_change": round(d_1_change, 2),
            "turnover_anchor": round(float(d0["volume"]) / circ * 100, 2) if circ > 0 else None,
            "turnover_anchor_total": round(float(d0["volume"]) / total * 100, 2) if total > 0 else None,
            "buy_mode": "next_open",
        }

        # 出场 = exit_modes（v1_combo；成交语义见 core/exec.py，只此一份）
        d1 = bars[i + 1]
        diag = dict(site["diag"])
        diag["d1_limit_up"] = is_limit_up(float(d1["close"]), float(d0["close"]),
                                        board_type, spec.market_spec)
        bt = run_exit(spec.exit.get("mode", "v1_combo"), bars=bars, entry_idx=entry_idx,
                      entry_price=entry_price, code=code, board_type=board_type,
                      params=_p, diag=diag)
        if not bt:
            continue

        trades.append({
            **sig,
            "entry_date": entry_date,
            "entry_price": round(entry_price, 3),
            "buy_mode": "next_open",
            "d1_change": round(d1_change, 2),
            "d1_gap": round(d1_gap, 2),
            "intraday": round(d1_change - d1_gap, 2),
            **bt,
        })
    return trades

register_day_flow("v1", _backtest_day_flow)
