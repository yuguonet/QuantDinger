"""strategies/relay3.py — 3板接力策略 (StrategyBase 插件实现, Phase 2 迁移)

⚠️ 2026-09-23 停用 (config.json enabled=false) + 逻辑复盘 (docstrong):
  入场逻辑缺陷: 3板接力的正确买点只有 2进3 (2板次日买第3板) 或 3进4 (3板次日买第4板);
  涨停价无法购买 — 本策略 D0=3板确认日、D1 开盘竞价买入, 无盘中确认, 且原回测对
  一字/秒板按 open 虚假成交。

  300日全市场重测 (5229只, 系统真实引擎, 含可成交性修复):
    2进3 位置: 693笔 胜率48.8% 均收-0.39%  (S4未封板 93%: 48%/-0.82%)
    3进4 位置: 230笔 胜率51.1% 均收-0.00%  (S4未封板 87%: 50%/-0.70%)
    封板延续组: 14笔全胜 均收+22~29% — 全部利润集中在这 1.5% 的小概率事件
    → 两个正确位置的期望都≈0或为负; 87~93% 的交易是「D1未封板当日微亏离场」

  改进方向 (relay3_rt 构想, 未实现): 提高胜率靠实时买入 — 盘中确认封板动能
  (放量上攻+封单) 后半路买入, 砍掉 93% 负期望单; 出场链 (S4+封板延续) 已被
  封板组验证全胜, 问题从不在出场。详见 docs/relay3_实时买入方案_docstrong.md。

  对照: 断板策略 (break, T3出场) 同期 +3.67% — 调整后确认介入 优于 情绪顶直追;
  若重做接力, 应基于断板框架高板位通道 (B4'), 而非复活本策略的开盘竞价入口。

策略来源: 2026-09-06 全量回测 (150天/9996接力样本/112笔1m出场模拟)。
本文件是 relay3 的**唯一实现**; 旧 auto/relay3.py 已改为 facade 转发到本模块。

入场 (D0 盘后扫描 → D1 竞价):
  池子: 昨日恰为 3 连板的票 (主板 9.8%/创科 19.8% 阈值, 排除 ST/北交所)
  特征: MA 多头排列 (MA5>MA10>MA20>MA60, 截至 D0 收盘)
  竞价: D1 开盘 gap ∈ (-2%, +9%) — 不追一字板 (>9% 无法成交), 低开超 -2% 放弃
  名额: 每日最多 2 只 (config.json strategies.relay3.daily_limit)

出场 (D1 盘中 S4+止损, D2+ 延续):
  - D1 触及涨停 → 持有 (涨停日豁免一切卖出判定)
  - 封板后炸板 (最新价 < 涨停价*99.5%) → 立即卖出 (S4 核心)
  - 盘中硬止损 -5% (monitor 主循环, 不在本策略)
  - D1 收盘未封板 → 尾盘卖; D1 封板守住 → D2 起转 holding:
    止损-5% / 追踪-8%(自D1高点) / 到期3天强制离场

易错点:
  - 连续涨停数判定以**收盘价**比前收, 含当日 → board_height=3 表示"昨日至今恰好3连板";
  - eval_exit_day_close 的 seg 索引约定: seg[0]=买入日, seg[1]=D1 —— 勿改成 seg[-1];
  - 涨停价按 entry_price (非 signal_price) 推算, 与回测口径一致。
"""
from __future__ import annotations

from datetime import datetime

from app.utils.indicators import ma as _ma  # D2: 收编内联, 逐字等价
from app.market_cn.auto.core.market import get_board_type, is_limit_up
from app.market_cn.auto.strategies import register
from app.market_cn.auto.core.runtime.functions import Ctx, _closes_upto
from app.market_cn.auto.core.runtime.gate_stdlib import board_height, ma_bull
from app.market_cn.auto.strategies.base import (
    ConfirmDecision, EntryDecision, ExitDecision, ScanSpec, Signal, StrategyBase,
    data_end_close,
)

STRATEGY_KEY = "relay3"
STRATEGY_LABEL = "3板接力"

# 回测口径参数 (与 rally_backtest_report.html 一致; config.json params 可覆盖)
PARAMS = {
    "board_height": 3,          # 昨日恰为3连板
    "ma_bull": True,            # MA多头排列硬门槛
    "gap_min": -2.0,            # D1开盘 gap 下限 %
    "gap_max": 9.0,             # D1开盘 gap 上限 % (排除一字板)
    "daily_limit": 2,           # 每日买入名额
    "stop_pct": -5.0,           # 盘中硬止损 %
    "break_sell_ratio": 0.995,  # 封板后炸板判定: last < limit*0.995
    "hold_days_max": 3,         # 封板延续后最长持有天数
    "trail_after_limit": -8.0,  # 封板延续期的追踪止损 (自D1高点) %
}


# ================================================================
# 特征计算 (纯函数, 无 IO)
# ================================================================

# _ma 已收编至 core/indicators.ma (D2, 逐字等价), import 处以 _ma 别名引用。


def ma_bull_arrangement(bars) -> bool:
    """MA5>MA10>MA20>MA60 (bars: 截至当日的日K list[dict])"""
    closes = [float(b["close"]) for b in bars]
    m5, m10, m20, m60 = _ma(closes, 5), _ma(closes, 10), _ma(closes, 20), _ma(closes, 60)
    if not (m5 and m10 and m20 and m60):
        return False
    return m5 > m10 > m20 > m60


def consecutive_limit_ups(bars, code) -> int:
    """截至最后一根bar的连续涨停天数 (板高)。"""
    bt = get_board_type(code)
    h = 0
    i = len(bars) - 1
    while i >= 1:
        if is_limit_up(float(bars[i]["close"]), float(bars[i - 1]["close"]), bt):
            h += 1
            i -= 1
        else:
            break
    return h


def calc_features(bars, code) -> dict:
    """D0 收盘后的日线特征 (供扫描判定与 extra 落库)。"""
    closes = [float(b["close"]) for b in bars]
    vols = [float(b["volume"]) for b in bars]
    feats = {
        "board_height": consecutive_limit_ups(bars, code),
        "ma_bull": 1 if ma_bull_arrangement(bars) else 0,
    }
    # 涨停日量比 (昨日量 / 前5日均量)
    if len(vols) >= 6:
        avg5 = sum(vols[-6:-1]) / 5
        feats["lu_vol_ratio"] = round(vols[-1] / avg5, 2) if avg5 > 0 else None
    # RSI14
    if len(closes) >= 15:
        gains, losses = [], []
        for k in range(len(closes) - 15, len(closes)):
            dd = closes[k] - closes[k - 1]
            gains.append(max(dd, 0))
            losses.append(max(-dd, 0))
        ag, al = sum(gains) / 14, sum(losses) / 14
        feats["rsi"] = round(100 - 100 / (1 + ag / al), 1) if al > 0 else 100.0
    return feats


# ================================================================
# 三决策辅助 (独立函数, 类方法与 facade 共用)
# ================================================================

def gap_buyable(gap: float) -> bool:
    """D1 开盘 gap 过滤: (-2%, +9%)。"""
    return PARAMS["gap_min"] <= gap <= PARAMS["gap_max"]


def entry_stop(entry_price: float, code: str) -> float:
    """-5% 盘中硬止损价。"""
    return round(entry_price * (1 + PARAMS["stop_pct"] / 100), 3)


def eval_exit_live(row, snap_rows, entry_price: float):
    """盘中/收盘出场判定 (S4+止损)。

    snap_rows: realtime_snapshot 当日序列 (时间升序)。
    返回 (reason, exit_price) 或 (None, None)。
    """
    if not snap_rows or entry_price <= 0:
        return None, None
    th = 0.198 if get_board_type(row["code"]) == "gem_star" else 0.098
    limit_price = round(entry_price * (1 + th), 2)
    break_th = limit_price * PARAMS["break_sell_ratio"]

    touched_limit = False
    for r in snap_rows:
        hi = float(r.get("high") or 0)
        last = float(r.get("last") or 0)
        if hi >= limit_price - 0.001:
            touched_limit = True
        if touched_limit and 0 < last < break_th:
            return "炸板卖出(S4)", last
    return None, None


def eval_exit_day_close(bars, entry_idx: int, entry_price: float, code: str, d1_held_since):
    """收盘出场重放 (D1: 未封板→尾盘卖; 封板→持有到到期/追踪)。

    bars: 日K+当日合成bar; entry_idx: 买入日索引; d1_held_since: D1 日期 str。
    返回 (reason, exit_price) 或 (None, None)。
    """
    if bars is None or entry_idx is None or entry_price <= 0:
        return None, None
    th = 0.198 if get_board_type(code) == "gem_star" else 0.098
    limit_price = round(entry_price * (1 + th), 2)
    today_idx = len(bars) - 1
    today = bars[-1]["time"]
    last_bar = bars[-1]

    # 当日(及D1以来)是否封板住
    # 2026-09-29 审计修复 (P1): seg[0] 即买入日 D1 —— 原实现取 seg[1] 当 D1 是差一
    # (注释"seg[0]=买入日, seg[1]=D1"假设买入日是 D0, 与本策略"D1 开盘买入"
    # entry_date=bars[i+1] 自相矛盾): D2 被当 D1 判封板, 封板延续单在 D2
    # 被"S4未封板尾盘卖(补)"强平 (应走追踪/到期链)。
    seg = bars[entry_idx:today_idx + 1]
    if not seg:
        return None, None
    d1_bar = seg[0]
    # 持有超过到期天数 (从 D1 算起) → 到期卖。
    # 2026-09-29 审计修复 (P2): 原先用自然日 (跨周末提前到期), hold_days_max 是
    # 交易日口径 —— 改为 seg 根数 (= D1 起的交易日数, 与回测 run_limit_seal 同口径)。
    held_days = len(seg)
    if held_days > PARAMS["hold_days_max"]:
        return f"到期{PARAMS['hold_days_max']}天", last_bar["close"]

    d1_touched = float(d1_bar["high"]) >= limit_price - 0.001
    # D1 封板后炸板/走弱: 追踪止损 (从 D2 起可判)
    if d1_touched and len(seg) >= 2:
        d1_high = max(float(b["high"]) for b in seg)
        ret_from_high = (float(last_bar["close"]) / d1_high - 1) * 100 if d1_high > 0 else 0
        if ret_from_high <= PARAMS["trail_after_limit"]:
            return f"追踪止损{PARAMS['trail_after_limit']}%", last_bar["close"]
        if held_days > PARAMS["hold_days_max"]:
            return f"到期{PARAMS['hold_days_max']}天", last_bar["close"]
        return None, None  # 封板延续 → 继续持有
    # D1 未封板: 理论上应在 D1 尾盘已卖 (S4), 此处兜底 (漏网/停牌复牌等)
    if not d1_touched:
        return "S4未封板尾盘卖(补)", last_bar["close"]
    return None, None


# ================================================================
# 回测出场引擎 (日线近似 S4: 无1m快照, 用 high/close 判定触板/封板)
# ================================================================

def run_backtest_relay3(bars, entry_idx, entry_price, code, params):
    """relay3 日线回测出场 — 2026-09-26 P1-7b: 骨架上收 core.exit_engines.run_limit_seal。

    D1 触板/封板判定 + 封住延续追踪 (S4 日线近似)。行为与历史逐位一致 (含 D1 收盘卖;
    relay3 已停用, 迁移不改语义)。
    """
    from app.market_cn.auto.core.exit_engines import run_limit_seal
    return run_limit_seal(
        bars, entry_idx, entry_price,
        board_type=get_board_type(code),
        break_sell_ratio=params["break_sell_ratio"],
        trail_after_limit=params["trail_after_limit"],
        hold_days_max=params["hold_days_max"],
    )


# ================================================================
# StrategyBase 插件实现
# ================================================================

def _signal_to_legacy_dict(sig: Signal) -> dict:
    """Signal → 旧 relay3_today_d0_signals 的 dict 形态 (facade 兼容层)。"""
    ex = sig.extra or {}
    return {
        "strategy": STRATEGY_KEY,
        "style": "r3",
        "code": sig.code,
        "signal_date": sig.time,
        "signal_price": sig.price,
        "lu_date": ex.get("lu_date"),
        "board_height": ex.get("board_height"),
        "ma_bull": ex.get("ma_bull"),
        "lu_vol_ratio": ex.get("lu_vol_ratio"),
        "rsi": ex.get("rsi"),
        "score": sig.score,
    }


@register
class Relay3Strategy(StrategyBase):
    key = STRATEGY_KEY
    name = STRATEGY_LABEL
    prefilter_anchor = "limit_up"      # U1~U4 锚定最近涨停日 (3板日; Phase 3 顺手修复旧扫描漏过滤)
    entry_style = "r3"
    scan_spec = ScanSpec(kind="daily_close", after_events=("daily_1d", "lhb"))
    default_params = dict(PARAMS)

    # ---- 信号判定 ----
    def scan_signals(self, bars, code, *, as_of=None, ctx=None, **params):
        """昨日恰3连板 + MA多头 → Signal。

        as_of=k: 只用 bars[:k+1] 判定 (回测防未来函数); None 与旧 *_today_d0_signals 语义一致。
        """
        p = self.params(params or None)
        if as_of is not None:
            bars = bars[:as_of + 1]
        if not bars or len(bars) < 67:
            return []
        # 排除北交所/ST (ST 由上层过滤, 与 dragon_scan 主循环口径一致)
        if code.startswith(("8", "4", "92")):
            return []
        feats = calc_features(bars, code)
        if feats.get("board_height") != p["board_height"]:
            return []
        if p["ma_bull"] and not feats.get("ma_bull"):
            return []
        last = bars[-1]
        score = 60 + int(min(20, max(0, (feats.get("rsi") or 0) - 50) / 2))  # 60~80 简单质量分
        return [Signal(
            code=code,
            time=last["time"],
            score=score,
            price=float(last["close"]),
            label="3板接力",
            extra={
                "style": "r3",
                "lu_date": last["time"],
                "board_height": feats.get("board_height"),
                "ma_bull": feats.get("ma_bull"),
                "lu_vol_ratio": feats.get("lu_vol_ratio"),
                "rsi": feats.get("rsi"),
            },
        )]

    # ---- D1 竞价处置 (monitor ~09:25) ----
    def entry_decision(self, row, snap=None, **params):
        """gap = (open / prev_close - 1)*100, prev_close 取快照 previousClose, 兜底 signal_price。

        snap=None (快照缺失) → 不可买 (与 monitor 中 open_px<=0 → skip 一致, 不强买)。
        """
        p = self.params(params or None)
        if not snap:
            return EntryDecision(False, "无竞价快照")
        open_px = float(snap.get("open") or snap.get("last") or 0)
        if open_px <= 0:
            return EntryDecision(False, "开盘价缺失")
        prev_close = float(snap.get("previousClose") or row.get("signal_price") or 0)
        if prev_close <= 0:
            return EntryDecision(False, "昨收缺失")
        gap = (open_px / prev_close - 1) * 100
        if p["gap_min"] <= gap <= p["gap_max"]:
            return EntryDecision(True, f"gap={gap:.2f}% 可买")
        return EntryDecision(False, f"gap={gap:.2f}% 越界({p['gap_min']}~{p['gap_max']}%)")

    # ---- 15:00 收盘确认 ----
    def confirm_decision(self, row, snap=None, **params):
        """D1 收盘确认: 封板守住 → holding; 未封板 → 尾盘卖兜底 (S4)。

        snap={"series":[...当日快照序列]}; d1_chg 按 entry_price 基准 (涨停价推算口径)。
        返回 None = 无法判定, monitor 不转移。
        """
        series = (snap or {}).get("series") if isinstance(snap, dict) else None
        if not series:
            return None
        entry = float(row.get("entry_price") or 0)
        if entry <= 0:
            return None
        th = 0.198 if get_board_type(row.get("code", "")) == "gem_star" else 0.098
        limit_price = round(entry * (1 + th), 2)
        sealed = any(float(x.get("high") or 0) >= limit_price - 0.001 for x in series)
        last_px = float(series[-1].get("last") or 0)
        d1_chg = round((last_px / entry - 1) * 100, 2) if last_px > 0 else None
        if sealed and last_px >= limit_price * 0.995:
            return ConfirmDecision(True, "sealed_hold", d1_chg=d1_chg,
                                   detail={"confirm": "sealed_hold"})
        return ConfirmDecision(False, "S4未封板尾盘卖", d1_chg=d1_chg,
                               exit_price=round(last_px, 3) if last_px > 0 else None)

    def quality_key(self, row):
        """3板接力无额外质量分 (旧 else 分支 confirm_chg 口径 → 恒 0, 保持原排序行为)。"""
        return super().quality_key(row)

    def initial_stop(self, code, entry_price):
        """盘中硬止损 -5% (stop_pct)。"""
        return round(entry_price * (1 + self.params()["stop_pct"] / 100), 3)

    # ---- 出场判定 ----
    def exit_decision(self, row, snap=None, **params):
        """snap=None: hold (盘中硬止损兜底在 monitor 主循环);
        snap={"mode":"live","series":[...]}: 盘中炸板判定;
        snap={"mode":"day_close","bars":[...],"entry_idx":int}: 收盘重放 (回测/盘后复盘)。"""
        if not isinstance(snap, dict):
            return ExitDecision("hold")
        entry_price = float(row.get("entry_price") or 0)
        mode = snap.get("mode")
        if mode == "live":
            reason, price = eval_exit_live(row, snap.get("series") or [], entry_price)
        elif mode == "day_close":
            reason, price = eval_exit_day_close(
                snap.get("bars"), snap.get("entry_idx"), entry_price,
                row.get("code"), row.get("entry_date"))
        else:
            return ExitDecision("hold")
        if reason:
            return ExitDecision("exit", reason=reason, price=float(price or 0))
        return ExitDecision("hold")

    # ---- 回测钩子 (日线近似 S4, 2026-09-16 新增) ----
    def backtest_stock(self, bars, code, stock_info=None, use_prefilter=True,
                       probe=None):
        """单股 relay3 全历史日线回测 → trades 列表。

        枚举: i=D0 (恰为board_height连板收盘日) → scan_signals → D1开盘gap过滤
        → run_backtest_relay3 出场模拟。U1~U4 锚定 D0 涨停日。
        注意: 日线近似 S4 炸板按收盘价卖出, 实盘炸板瞬间价通常更高 → 回测偏保守。
        """
        from app.market_cn.auto.core.filters import unified_prefilter
        p = self.params(None)
        n = len(bars)
        if n < 5:
            return []
        trades = []
        for i in range(1, n - 1):  # i=D0, i+1=D1(入场日)
            sigs = self.scan_signals(bars[:i + 1], code)
            if not sigs:
                continue
            sig = sigs[0]
            # U1~U4 预过滤 (锚定 D0 涨停日)
            if use_prefilter:
                ok, _fails = unified_prefilter(bars, i, code, stock_info)
                if not ok:
                    continue
            # D1 开盘 gap 过滤
            entry_price = float(bars[i + 1]["open"])
            if entry_price <= 0:
                continue
            prev_close = float(bars[i]["close"])
            if prev_close <= 0:
                continue
            gap = (entry_price / prev_close - 1) * 100
            if not (p["gap_min"] <= gap <= p["gap_max"]):
                continue
            # 出场模拟
            result = run_backtest_relay3(bars, i + 1, entry_price, code, p)
            if result and result.get("open"):
                result = None          # 开放持仓（数据不足）→ 转末日平仓收尾
            if not result:
                # 2026-10-08 口径分歧 #1 修复：数据结束未平 → **末日收盘平仓**。
                # ⚠️ 行为变更（原为有意为之，已改）：原注释「跳过开放持仓 (数据不足,
                #    回测只统计已平仓)」是记载在案的意图，但它与通用引擎
                #    `base._backtest_stock_legacy`（末日收盘平仓）及 `core/replay`
                #    （REASON_DATA_END）**口径不一致**，且导致历史回测**低估交易数**
                #    （未平仓直接消失、不进统计）。现统一到 base.data_end_close 单一口径。
                #    若需回退旧口径，改这里并重冻 tests/golden/baselines/ + 重出差异报告。
                result = data_end_close(bars, i + 1, entry_price)
            if not result:
                continue
            ex = sig.extra or {}
            trades.append({
                "code": code,
                "board": get_board_type(code),
                "path": self.key,
                "path_label": self.name,
                "signal_date": bars[i]["time"],
                "entry_date": bars[i + 1]["time"],
                "entry_price": round(entry_price, 3),
                "buy_mode": "next_open",
                "d1_gap": round(gap, 2),
                "lu_date": ex.get("lu_date"),
                "board_height": ex.get("board_height"),
                "ma_bull": ex.get("ma_bull"),
                "lu_vol_ratio": ex.get("lu_vol_ratio"),
                "rsi": ex.get("rsi"),
                **result,
            })
        return trades


# ================================================================
# 以下门表 DSL 私有函数由 strategies 重构从 strategy_funcs 迁入（逐字等价）
# ================================================================
def relay3_features(ctx: Ctx) -> dict:
    """relay3 日线特征（逐字镜像 relay3.calc_features，截至决策日 i）。

    门表用 board_height()/ma_bull() 判资格；本函数额外给出**信号展示字段**
    （lu_vol_ratio / rsi），保证与 python 参考版 trades 逐字一致。逻辑单点维护于此。
    """
    i = ctx.i
    closes = _closes_upto(ctx)
    vols = [Ctx._f(ctx.bars[j], "volume") for j in range(i + 1)]
    feats = {"board_height": board_height(ctx), "ma_bull": 1 if ma_bull(ctx) else 0}
    # 涨停日量比 (昨日量 / 前5日均量)
    if len(vols) >= 6:
        avg5 = sum(vols[-6:-1]) / 5
        feats["lu_vol_ratio"] = round(vols[-1] / avg5, 2) if avg5 > 0 else None
    # RSI14 (relay3 口径: 取末尾 15 个收盘的 14 段差分)
    if len(closes) >= 15:
        gains, losses = [], []
        for k in range(len(closes) - 15, len(closes)):
            dd = closes[k] - closes[k - 1]
            gains.append(max(dd, 0))
            losses.append(max(-dd, 0))
        ag, al = sum(gains) / 14, sum(losses) / 14
        feats["rsi"] = round(100 - 100 / (1 + ag / al), 1) if al > 0 else 100.0
    return feats

# ---- exit_modes 注册 (2026-09-26 P1-9 层反转) ----
def _exit_relay3_s4(bars, entry_idx, entry_price, *, code, board_type, params, diag):
    """relay3 S4 日线近似出场 — 供 YAML exit.mode=relay3_s4。"""
    return run_backtest_relay3(bars, entry_idx, entry_price, code, params)


from app.market_cn.auto.core.exit_modes import register_exit as _register_exit
_register_exit("relay3_s4", _exit_relay3_s4)


# ================================================================
# 门表回测编排 (2026-09-28 分层改造: 自 core/runtime/evaluate.py **纯搬运**下沉)
# ----------------------------------------------------------------
# 为什么搬回来: 编排是策略的一部分 (枚举顺序/去重键/展示字段集/入场腿), 放在 core
# 会让"改 g56 口径"变成改架构层, 且 core 反过来惰性 import strategies.* (层反转)。
# 自注册到 core/runtime/flows 注册表 → core 只查表, 未登记即 fail-fast (不再静默落 v1)。
# ⚠ 搬运要求: 签名与语义**逐字不变**; 逐笔等价回归见
#    analysis_output/auto架构分层_20260928.md
# ================================================================

from typing import Any, Dict, List

from app.market_cn.auto.core.entry_modes import resolve_entry
from app.market_cn.auto.core.exit_modes import run_exit
from app.market_cn.auto.core.filters import unified_prefilter
from app.market_cn.auto.core.runtime.flows import register_day_flow

def _backtest_day_flow(bars, code, spec, ev, board_type, stock_info, use_prefilter):
    """门表版 relay3(3板接力) 全历史回测，返回 trades 列表（与 relay3.backtest_stock 逐笔等价）。

    编排逐字镜像 relay3.backtest_stock：逐日 D0 判定（门表: 非北交所 + 恰3连板 + MA多头）
    → U1~U4 锚定 D0 涨停日 → 入场=entry_modes(open, gap -2~9%) → 出场=exit_modes(relay3_s4)。
    参考版 scan_signals 要求 len(bars[:i+1])>=67 → meta.day_start=66 精确复现该下界。
    """
    n = len(bars)
    if n < int(spec.meta.get("day_min_n", 5)):
        return []
    _p = spec.params
    trades: List[Dict[str, Any]] = []

    for i in range(int(spec.meta.get("day_start", 66)), n - 1):
        # D0 逐日判定（门表一次性求所有门，与 relay3.scan_signals 同一逻辑）
        ok, _ = ev.evaluate_all(bars, i, _p)
        if not ok:
            continue

        # U1~U4（锚定 D0 涨停日；relay3 prefilter_anchor='limit_up'）
        if use_prefilter:
            ok, _ = unified_prefilter(bars, i, code, stock_info, spec.market_spec)
            if not ok:
                continue

        # 入场 = entry_modes（open + gap 过滤）
        site, _reason = resolve_entry(spec.entry, bars, i, board_type, _p)
        if site is None:
            continue

        # 出场 = exit_modes（relay3_s4 日线近似；成交语义见 core/exec.py）
        result = run_exit(spec.exit.get("mode", "relay3_s4"), bars=bars,
                          entry_idx=site["entry_idx"], entry_price=site["entry_price"],
                          code=code, board_type=board_type, params=_p, diag=site["diag"])
        if not result or result.get("open"):
            continue  # 参考版跳过开放持仓（数据不足, 只统计已平仓）

        # 信号展示字段（镜像 relay3 calc_features: board_height/ma_bull/lu_vol_ratio/rsi）
        feats = relay3_features(Ctx(bars, i, lu_idx=0, params=_p, board_type=board_type, code=code,
                                    market=spec.market_spec))
        trades.append({
            "code": code,
            "board": get_board_type(code, spec.market_spec),
            "path": spec.key,
            "path_label": spec.meta.get("name", spec.key),
            "signal_date": bars[i]["time"],
            "entry_date": site["entry_date"],
            "entry_price": round(site["entry_price"], 3),
            "buy_mode": "next_open",
            "d1_gap": round(site["diag"]["d1_gap"], 2),
            "lu_date": bars[i]["time"],
            "board_height": feats.get("board_height"),
            "ma_bull": feats.get("ma_bull"),
            "lu_vol_ratio": feats.get("lu_vol_ratio"),
            "rsi": feats.get("rsi"),
            **result,
        })
    return trades


# ================================================================
# 枚举方式 B / day_flow=break（断板接力，D0 确认日 → 次日开盘入场）
# 逐字镜像 break_buy.BreakStrategy.backtest_stock（见 tmp/_break_equivalence.py 验收）
# ================================================================

register_day_flow("relay3", _backtest_day_flow)
