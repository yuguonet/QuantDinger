"""test_trace.py — 门原因通道 TraceSink 单元门禁（改进方案 §2.4，P0）。

验三件事：
  1. TraceSink 收集/JSONL 导出/清空的基本契约（一行一记录，透传 ok）；
  2. dragon evaluate 接线：ctx["_trace"] 存在时门原因进 sink（含落选原因）；
  3. **零行为差异**：带 sink 与不带 sink 的 fold 事件流逐位一致（P0 的核心约束）。

易错点:
  - fuzz 数据产不出信号/门调用 ⇒ [] == [] 假绿；必须用 crafted_bars（有意外板 31
    的落选记录可断言）。
  - 断言落选记录要认 `ok is False` 而非 `reason` 非空（reason 文案可变）。
"""

from __future__ import annotations

import json

from app.market_cn.auto.core.present.contract import DayInput, InsufficientHistory
from app.market_cn.auto.core.trace import TraceSink
from app.market_cn.auto.strategies.dragon_callback import DragonCallbackStrategy

from .test_dragon import CODE, crafted_bars


def _fold(strategy, bars, ctx=None):
    """最小 stateless fold（同 fold_range 折叠序，可注入 ctx）。"""
    state, j = None, 0
    while j < len(bars):
        try:
            state = strategy.init_state(CODE, bars[:j])
            break
        except InsufficientHistory:
            j += 1
    assert state is not None, "seed 失败"
    evs = []
    for k in range(j, len(bars)):
        evs.extend(strategy.evaluate(state, DayInput(CODE, bars[k], ctx), None) or [])
        state = strategy.step(state, bars[k])
    return evs


def test_sink_records_and_jsonl(tmp_path):
    sink = TraceSink(code="600000", strategy="t")
    sink.begin_day("2026-01-05")
    assert sink.gate(False, "门2 未过", cand="2025-12-01") is False   # 透传
    assert sink.gate(True, None) is True
    sink.note("no_signal")
    assert len(sink.records) == 3
    assert sink.records[0] == {"t": "2026-01-05", "ok": False, "reason": "门2 未过",
                               "code": "600000", "cand": "2025-12-01"}
    lines = sink.to_jsonl().strip().splitlines()
    assert [json.loads(x)["reason"] for x in lines] == ["门2 未过", None, None]
    # dump 追加写 + 自动建目录
    p = str(tmp_path / "sub" / "t.jsonl")
    assert sink.dump_jsonl(p) == 3
    assert sink.dump_jsonl(p) == 3
    with open(p, encoding="utf-8") as f:
        assert len(f.read().strip().splitlines()) == 6
    sink.clear()
    assert sink.records == [] and sink.to_jsonl() == ""


def test_dragon_evaluate_writes_trace():
    """ctx['_trace'] 存在 → 门原因进 sink（含落选）；crafted_bars 的意外板必出落选记录。"""
    s = DragonCallbackStrategy()
    bars = crafted_bars()
    sink = TraceSink(code=CODE, strategy=s.key)
    _fold(s, bars, ctx={"_trace": sink})
    assert sink.records, "dragon 门调用未写入 trace（接线失效）"
    assert any(r["ok"] is False for r in sink.records), \
        "无落选记录 —— crafted_bars 的意外板 31 应产生 gate(False, ...)"

def test_trace_sink_zero_behavior_diff():
    """带 sink 与不带 sink 的 fold 事件流逐位一致（P0 核心约束：通道只旁路收集）。"""
    s = DragonCallbackStrategy()
    bars = crafted_bars()
    evs_plain = _fold(s, bars, ctx=None)
    evs_trace = _fold(s, bars, ctx={"_trace": TraceSink(code=CODE)})
    key = lambda e: (e.stage, e.date, sorted(e.payload.items()), e.next_realtime)
    assert [key(e) for e in evs_plain] == [key(e) for e in evs_trace]
