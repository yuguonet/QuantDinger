import router, {
  resetRouter
} from './router'
import store from './store'
import storage from 'store'
import NProgress from 'nprogress' // progress bar
import '@/components/NProgress/nprogress.less' // progress bar custom style
import {
  setDocumentTitle,
  domTitle
} from '@/utils/domUtil'
import {
  ACCESS_TOKEN
} from '@/store/mutation-types'
import { prefValue, setPrefValue } from '@/utils/uiPrefs'
import {
  i18nRender
} from '@/locales'

NProgress.configure({
  showSpinner: false
}) // NProgress Configuration

const allowList = ['login'] // no redirect allowList
const loginRoutePath = '/user/login'
const defaultRoutePath = '/ai-asset-analysis'

/** 是否"空白入口"路径: 打开应用直接落在根路径或默认页 (此时应恢复上次停留栏目) */
function isBareEntry (path) {
  return path === '/' || path === defaultRoutePath
}

/** 上次停留栏目 (无效/未记录/登录页 → null) */
function lastVisitedRoute () {
  const saved = prefValue('nav', 'last', '')
  if (!saved || typeof saved !== 'string') return null
  if (saved === '/' || saved === loginRoutePath) return null
  return saved
}

// 应用本次会话的首次导航标记: "恢复上次栏目"只允许发生在打开应用时,
// 否则从菜单切到默认页(/ai-asset-analysis)会被误判为空白入口而弹回上一页(死循环)
let _bootNavDone = false

router.beforeEach((to, from, next) => {
  NProgress.start() // start progress bar
  const isBootNav = !_bootNavDone
  _bootNavDone = true
  to.meta && typeof to.meta.title !== 'undefined' && setDocumentTitle(`${i18nRender(to.meta.title)} - ${domTitle}`)

  // Check whether we have a token (local-only auth).
  // 处理 token 可能是字符串或对象的情况
  let token = storage.get(ACCESS_TOKEN)
  if (token && typeof token !== 'string') {
    token = token.token || token.value || (typeof token === 'object' ? null : token)
  }
  token = typeof token === 'string' ? token : null

  if (token) {
    // 有 token，允许访问所有页面
    // 如果访问登录页，跳转到上次停留栏目(如有)或默认页面 —— 有效token下完全跳过登录确认
    if (to.path === loginRoutePath) {
      next({ path: lastVisitedRoute() || defaultRoutePath })
      NProgress.done()
    } else {
      // 检查用户信息是否已加载
      if (store.getters.roles.length === 0) {
        store.dispatch('GetInfo')
          .then(res => {
            // 拉取用户信息成功
            // const roles = res && res.role
            // 生成路由
            store.dispatch('GenerateRoutes', { token }).then(() => {
              // 动态添加可访问路由表
              resetRouter() // 重置路由
              store.getters.addRouters.forEach(r => {
                router.addRoute(r)
              })
              // 请求带有 redirect 重定向时，登录自动重定向到该地址
              let redirect = decodeURIComponent(from.query.redirect || to.path)
              if (isBootNav && !from.query.redirect && isBareEntry(to.path)) {
                // 首次进入空白入口: 恢复上次停留栏目 (动态路由尚未注册, 跳过resolve校验)
                const saved = lastVisitedRoute()
                if (saved && saved !== to.path) redirect = saved
              }
              if (to.path === redirect) {
                // hack方法 确保addRoutes已完成 ,set the replace: true so the navigation will not leave a history record
                next({ ...to, replace: true })
              } else {
                // 跳转到目的路由
                next({ path: redirect })
              }
            })
          })
          .catch((err) => {
            // If token is invalid/expired, clear local auth and redirect to login.
            const status = err && err.response && err.response.status
            if (status === 401) {
              store.dispatch('Logout').finally(() => {
                next({ path: loginRoutePath, query: { redirect: to.fullPath } })
                NProgress.done()
              })
              return
            }

            // Do NOT hard-logout on transient failures (backend down, proxy issue, etc).
            // Instead, degrade gracefully with a default role and continue.
            store.commit('SET_ROLES', [{ id: 'default', permissionList: [] }])
            store.dispatch('GenerateRoutes', { token }).then(() => {
              resetRouter()
              store.getters.addRouters.forEach(r => router.addRoute(r))
              next({ ...to, replace: true })
            }).catch(() => {
              next()
            })
          })
      } else {
        // 检查路由是否已初始化
        const addRouters = store.getters.addRouters
        // 如果路由未初始化，先初始化路由
        if (!addRouters || addRouters.length === 0) {
          store.dispatch('GenerateRoutes', { token }).then(() => {
            // 动态添加可访问路由表
            resetRouter() // 重置路由 防止退出重新登录或者 token 过期后页面未刷新，导致的路由重复添加
            store.getters.addRouters.forEach(r => {
              router.addRoute(r)
            })
            // 重新进入当前路由，避免首次刷新空白
            next({ ...to, replace: true })
          }).catch(() => {
            next()
          })
        } else {
          // 仅应用首次导航时恢复上次停留栏目 (此时动态路由已注册, 可校验存在性)。
          // SPA 日常切到默认页不属于空白入口, 否则会把用户弹回上一页造成"页面宕机"
          const saved = lastVisitedRoute()
          if (isBootNav && isBareEntry(to.path) && saved && saved !== to.path && saved !== to.fullPath &&
              router.resolve(saved).matched.length) {
            next({ path: saved, replace: true })
          } else {
            next()
          }
        }
      }
    }
  } else {
    // 没有 token
    if (allowList.includes(to.name)) {
      // 在免登录名单，直接进入
      next()
    } else {
      // 跳转到登录页
      next({ path: loginRoutePath, query: { redirect: to.fullPath } })
      NProgress.done() // if current page is login will not trigger afterEach hook, so manually handle it
    }
  }
})

router.afterEach((to) => {
  // 记录最后停留栏目 (仅登录态; 供下次打开应用时恢复)
  if (storage.get(ACCESS_TOKEN) && to.path && to.path !== loginRoutePath) {
    setPrefValue('nav', 'last', to.fullPath)
  }
  NProgress.done() // finish progress bar
})
