# -*- coding: utf-8 -*-
"""
Dragon Tools — 龙虎榜/涨跌停/热榜。

数据源：market_cn.dragon_limit（HTTP优先 + AkShare兜底，已有多源容灾）
"""
from __future__ import annotations
import json

from log import logger
from typing import Any, Dict, List
from utils.md_format import _batch_execute, _to_md

def get_dragon_tiger(codes: str = "", date: str = "", days: int = 30,
                     detail: bool = False) -> dict:
    """龙虎榜：返回上榜股票的买卖金额、上榜原因（涨幅/跌幅/换手异常等）、日期。

    codes 为空时返回全市场龙虎榜；非空时返回该股票的历史龙虎榜记录。
    2026-09-27 工具归组化：合并原 get_dragon_tiger_detail（detail=True 展开席位明细）。

    Returns:
        统一结构（单/多股一致，2026-09-22 起）：{"count": N, "data": {代码: 单股结果},
        "error": None}；失败 → {"error": "...", "retriable": False}。单股结果字段：{stock_code, count, records:[...]}（records 含个股龙虎榜明细；
        不传代码时 data 为日期汇总 {date, count, stocks:[...]}）。
        detail=True 时单股结果追加 seats{buy,sell} 与 institution{}（席位与机构动向，
        与原 get_dragon_tiger_detail 单股返回同构）。

    Args:
        codes: 逗号分隔的股票代码（可选，空=全市场），如 "600519" 或 "600519,000001"
        date: 查询日期 YYYY-MM-DD，默认最近交易日
        days: 回溯天数，默认30
        detail: 是否展开席位/机构明细（仅单股模式生效；全市场模式忽略）
    """
    def _one(stock_code: str) -> dict:
        from datetime import datetime, timedelta
        from app.market_cn.dragon_limit import get_dragon_tiger as _get

        if stock_code and stock_code.strip():
            if not date:
                _date = datetime.now().strftime("%Y-%m-%d")
            else:
                _date = date
            start_date = (datetime.now() - timedelta(days=max(1, min(days, 365)))).strftime("%Y-%m-%d")
            all_data = _get(start_date, _date)
            code = stock_code.strip().replace(".", "").upper()
            data = [r for r in all_data if str(r.get("stock_code", "")).replace(".", "").upper() == code
                    or stock_code.strip() in str(r.get("code", ""))]
            return {"stock_code": stock_code, "days": days, "count": len(data), "records": data}
        else:
            if not date:
                _date = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
            else:
                _date = date
            data = _get(_date, _date)
            return {"date": _date, "days": 1, "count": len(data), "stocks": data}

    # codes 为空时走全市场逻辑（不经过批量）；detail 仅单股模式生效
    if not codes or not codes.strip():
        return _one("")

    code_list = [c.strip() for c in codes.split(",") if c.strip()][:20]
    if not code_list:
        return {"error": "codes 不能为空", "retriable": False}

    base = _batch_execute(_one, code_list)
    if not detail:
        return base

    # detail=True：逐股追加 seats/institution（委托原 get_dragon_tiger_detail 实现，
    # 不自算第三份；单股等价性 = 原工具单股返回的 seats/institution 子集）
    from tools.finance.signal_tools import get_dragon_tiger_detail as _detail
    data = base.get("data") if isinstance(base, dict) else None
    if not isinstance(data, dict):
        return base
    for code in code_list:
        row = data.get(code)
        if not isinstance(row, dict) or "error" in row:
            continue
        try:
            d = _detail(code, look_back_days=max(1, min(days, 365)))
            # 形状容错：单股扁平 {seats,...} 或批量信封 {data:{code:{seats,...}}}
            # （⚠️ 勿用 "error" 键猜形态——_batch_execute 恒带 error:None，会误判）
            src = None
            if isinstance(d, dict):
                if "seats" in d or "institution" in d:
                    src = d
                elif isinstance(d.get("data"), dict) and d["data"]:
                    src = d["data"].get(code) or next(iter(d["data"].values()))
            if isinstance(src, dict):
                for k in ("seats", "institution"):
                    if k in src:
                        row[k] = src[k]
            else:
                row["detail_error"] = (d.get("error") if isinstance(d, dict) else None) or "明细获取失败"
        except Exception as e:  # 明细拉取失败不拖垮主结果，但显式标注（不静默）
            row["detail_error"] = str(e)
    return base

def get_hot_rank(top_n: int = 30) -> dict:
    """人气榜：返回当日市场关注度最高的股票排名及热度分数。

    Args:
        top_n: 返回前N名，默认30，最大100

    Returns:
        {"count": N, "stocks": [{code, name, rank, hot_score, ...}]} —— dict，stocks 是二级键下的列表
    """
    from app.market_cn.dragon_limit import get_hot_rank as _get
    top_n = min(max(int(top_n or 30), 1), 100)
    data = _get()
    return {"count": len(data[:top_n]), "stocks": data[:top_n]}
def get_limit_pool(date: str = "", pool_type: str = "zt", min_continuous_days: int = 0) -> dict:
    """涨跌停池：返回当日涨停/跌停/炸板股票列表，含封板时间、连板天数。

    Args:
        date: 交易日期 YYYY-MM-DD，默认今天
        pool_type: zt=涨停池, dt=跌停池, broken=炸板池, all=全部（其它值会被忽略，只返回 {date}）
        min_continuous_days: 仅 zt 有效，最少连板天数，0=全部

    Returns:
        {"date": "YYYY-MM-DD", "zt": {"count": N, "stocks": [{code, name, ...}]}}
        —— dict 结构， stocks 列表在二级键下（zt/dt/broken），不要对返回值直接切片/迭代；
        无效 pool_type 或无数据时对应键缺失，取值前用 .get() 并判空。
    """
    from datetime import datetime
    from app.market_cn.dragon_limit import (
        get_zt_pool as _zt, get_dt_pool as _dt, get_broken_board as _broken,
    )

    if not date:
        date = datetime.now().strftime("%Y-%m-%d")

    pool_type = (pool_type or "zt").strip().lower()
    result: Dict[str, Any] = {"date": date}

    if pool_type in ("zt", "all"):
        zt = _zt(date)
        if min_continuous_days > 0:
            zt = [r for r in zt if int(r.get("continuous_zt_days", 0) or 0) >= min_continuous_days]
        result["zt"] = {"count": len(zt), "stocks": zt}

    if pool_type in ("dt", "all"):
        dt = _dt(date)
        result["dt"] = {"count": len(dt), "stocks": dt}

    if pool_type in ("broken", "all"):
        broken = _broken(date)
        result["broken"] = {"count": len(broken), "stocks": broken}

    return result
