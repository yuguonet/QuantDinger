# -*- coding: utf-8 -*-
"""多空研究员 — 同时构建多头和空头论据，综合判断方向。"""
from typing import Any, Dict, List

# 2026-09-28 修复：本模块的 4 个内部分析函数（_analyze_trend/_get_volume_analysis/
# _analyze_pattern/_get_indicator_snapshot）由 analysis_tools.py 内联而来，但内联时
# **漏带了被内联代码所依赖的辅助函数**（_safe_round / _fetch_ohlcv / _calc_macd /
# _calc_rsi / _calc_boll / _calc_kdj / logger / get_realtime_quote），导致这些函数
# 一旦被调用即 NameError（被内层 except 吞掉后只返回 {"error": ...}，静默退化）。
# 按项目"复用优于重定义"约定改为导入单一实现，不在此复制第三份。
from log import logger
from tools.finance._analysis_utils import _fetch_ohlcv, _safe_round
from tools.finance.analysis_tools import (
    _calc_boll, _calc_kdj, _calc_macd, _calc_rsi,
)
from tools.finance.data_tools import get_realtime_quote
from tools.finance.news_search_tools import search_stock_intel, search_policy_intel
def bull_bear_research(codes: str, stock_name: str = "") -> dict:
    """多空研究：对单只股票做技术面+筹码+情报综合分析，返回多空评分和方向判断。

    Args:
        codes: 股票代码，如 "600066"
        stock_name: 股票名称，可选

    Returns:
        dict — 多空综合报告。
        核心键: score(0-100), direction(bullish|bearish|neutral), confidence(float),
        factors(list), analysis(str), hit_rate(float|None), missing_data(list[str]),
        falsifiable_conditions(str), output_data(bull_case/bear_case/verdict 嵌套)。
        factors 同 technical_analysis 格式：list[dict{"name","score","direction"}]，
        因子名带 "多头:" / "空头:" 前缀，按 direction 字段过滤。
        失败 → {"error": str, "retriable": bool}。
    """
        
    # ── 获取数据 ──
    data = {}
    for name, fn in [
        ("realtime_quote", lambda: get_realtime_quote(codes)),
        ("trend", lambda: _analyze_trend(codes)),
        ("volume", lambda: _get_volume_analysis(codes)),
        ("indicator", lambda: _get_indicator_snapshot(codes)),
        ("intel", lambda: search_stock_intel(codes, stock_name or "")),
    ]:
        try:
            data[name] = fn()
        except Exception as e:
            data[name] = {"error": str(e)}

    # ── 构建多头论据 ──
    bull_factors = []
    bull_score = 50
    bull_signals = []

    trend = data.get("trend", {})
    if isinstance(trend, dict) and "error" not in trend:
        trend_score = trend.get("trend_score", 50)
        if trend_score >= 60:
            bull_factors.append(f"趋势偏多({trend_score})")
            bull_signals.append(f"趋势:{trend_score}")
        bull_score = trend_score

    indicator = data.get("indicator", {})
    if isinstance(indicator, dict) and "error" not in indicator:
        rsi = indicator.get("rsi6", 50)
        macd_hist = indicator.get("macd_hist", 0)
        if rsi < 30:
            bull_factors.append(f"RSI{rsi:.0f}超卖")
            bull_signals.append(f"RSI超卖:{rsi:.0f}")
        if macd_hist > 0:
            bull_factors.append("MACD多头")

    volume = data.get("volume", {})
    if isinstance(volume, dict) and "error" not in volume:
        vol_relation = volume.get("vol_price_relation", "")
        if "量价齐升" in vol_relation:
            bull_factors.append("量价齐升")
            bull_signals.append("量价齐升")

    intel = data.get("intel", {})
    if isinstance(intel, dict) and "error" not in intel:
        composite = intel.get("composite_score", 0)
        if composite > 1:
            bull_factors.append(f"情报偏多({composite:.1f})")

    # ── 构建空头论据 ──
    bear_factors = []
    bear_score = 50
    bear_signals = []

    if isinstance(trend, dict) and "error" not in trend:
        trend_score = trend.get("trend_score", 50)
        if trend_score <= 40:
            bear_factors.append(f"趋势偏空({trend_score})")
            bear_signals.append(f"趋势:{trend_score}")
        bear_score = 100 - trend_score

    if isinstance(indicator, dict) and "error" not in indicator:
        rsi = indicator.get("rsi6", 50)
        macd_hist = indicator.get("macd_hist", 0)
        if rsi >= 70:
            bear_factors.append(f"RSI{rsi:.0f}超买")
            bear_signals.append(f"RSI超买:{rsi:.0f}")
        if macd_hist < 0:
            bear_factors.append("MACD空头")

    if isinstance(volume, dict) and "error" not in volume:
        vol_relation = volume.get("vol_price_relation", "")
        if "放量下跌" in vol_relation:
            bear_factors.append("放量下跌")
            bear_signals.append("放量下跌")

    if isinstance(intel, dict) and "error" not in intel:
        composite = intel.get("composite_score", 0)
        if composite < -1:
            bear_factors.append(f"情报偏空({composite:.1f})")

    # ── 综合判断 ──
    # 多头得分 vs 空头得分
    bull_total = bull_score + len(bull_factors) * 5
    bear_total = bear_score + len(bear_factors) * 5

    if bull_total > bear_total + 10:
        verdict = "bullish"
        final_score = min(100, 50 + (bull_total - bear_total))
        direction = "bullish"
    elif bear_total > bull_total + 10:
        verdict = "bearish"
        final_score = max(0, 50 - (bear_total - bull_total))
        direction = "bearish"
    else:
        verdict = "neutral"
        final_score = 50
        direction = "neutral"

    confidence = min(1.0, max(0.3, (len(bull_factors) + len(bear_factors)) / 8))

    # ── A1c 校准命中率（score→P(方向正确)）──
    # 有校准数据时 confidence 直接取 hit_rate（P(方向正确)），无则回退原因子数逻辑。
    try:
        from utils.calibration import apply as _cal_apply
        hit_rate = _cal_apply("bull_bear_research", final_score)
    except Exception:
        hit_rate = None
    if hit_rate is not None:
        confidence = hit_rate

    signal_parts = []
    if bull_signals:
        signal_parts.append(f"多:{','.join(bull_signals[:2])}")
    if bear_signals:
        signal_parts.append(f"空:{','.join(bear_signals[:2])}")
    signal = " | ".join(signal_parts) if signal_parts else "多空均衡"

    factors = []
    for f in bull_factors[:3]:
        factors.append({"name": f"多头:{f}", "score": bull_score, "direction": "bullish"})
    for f in bear_factors[:3]:
        factors.append({"name": f"空头:{f}", "score": bear_score, "direction": "bearish"})

    dir_map = {"bullish": "看多", "bearish": "看空", "neutral": "中性"}
    all_signals = (bull_signals or []) + (bear_signals or [])
    md = f"多空分析 {final_score:.0f}分 {dir_map.get(direction, direction)}"
    if hit_rate is not None:
        md += f" 历史命中率{hit_rate*100:.0f}%"
    if factors:
        md += "\n" + " ".join(f"{f['name']}:{f['score']}" for f in factors[:4])
    if all_signals:
        md += "\n" + " ".join(all_signals[:3])
    md += f"\n{verdict}"
    analysis = md

    # ── A3 缺数据声明 ──
    # data 各数据源若含 "error" 键则视为缺失，统一收集到 missing_data。
    missing_data = [k for k, v in data.items()
                    if isinstance(v, dict) and "error" in v]

    # ── A4 可证伪条件（若 X 发生则本判断失效）──
    _trend = data.get("trend", {}) if isinstance(data.get("trend"), dict) else {}
    _ma5 = _trend.get("ma5")
    _ma20 = _trend.get("ma20")
    _falsifiable = []
    if direction == "bullish":
        if _ma5 and _ma20:
            _falsifiable.append(f"MA5({_ma5:.2f})跌破MA20({_ma20:.2f})")
        _falsifiable.append(f"多空分({final_score:.0f})跌破55")
    elif direction == "bearish":
        if _ma5 and _ma20:
            _falsifiable.append(f"MA5({_ma5:.2f})突破MA20({_ma20:.2f})")
        _falsifiable.append(f"多空分({final_score:.0f})突破45")
    else:
        _falsifiable.append(f"多空分({final_score:.0f})突破60或跌破40")
    falsifiable_conditions = "；".join(_falsifiable) if _falsifiable else "数据不足"

    _r = {
        "score": final_score,
        "direction": direction,
        "confidence": confidence,
        "signal": signal,
        "factors": factors,
        "analysis": analysis,
        "status": "ok",
        # A1a：权重是否来自 qd_agent_weights 校准（透传 _analyze_trend 的 calibrated）
        "calibrated": data.get("trend", {}).get("calibrated", False) if isinstance(data.get("trend"), dict) else False,
        # A1c：score→P(方向正确)，无校准数据时为 None
        "hit_rate": hit_rate,
        # A3：缺失的数据源名列表
        "missing_data": missing_data,
        # A4：可证伪条件
        "falsifiable_conditions": falsifiable_conditions,
        "output_data": {
            "bull_case": {
                "score": bull_score,
                "factors": bull_factors,
                "signals": bull_signals,
            },
            "bear_case": {
                "score": bear_score,
                "factors": bear_factors,
                "signals": bear_signals,
            },
            "verdict": verdict,
            "data": data,
        },
    }
    return _r
# ── 内联自 analysis_tools.py ──

def _analyze_trend(codes: str) -> Dict[str, Any]:
    """技术趋势（内部复用）：同 analysis_tools.analyze_trend，仅供 bull_bear_research 内部调用，外部请用 analyze_trend。

    Args:
        codes: 多股用逗号分隔"
    """
    code_list = [c.strip() for c in codes.split(",") if c.strip()][:20]
    if not code_list:
        return {"error": "codes 不能为空", "retriable": False}

    def _one(codes: str) -> Dict[str, Any]:
        try:
            data = _fetch_ohlcv(codes, 120)
            closes = data["close"]
            if len(closes) < 5:
                return {"error": "K线数据不足（至少需要5根）", "retriable": True}

            latest = closes[-1]
            prev = closes[-2] if len(closes) >= 2 else latest

            # ── 均线 ──
            ma5 = _safe_round(sum(closes[-5:]) / 5)
            ma10 = _safe_round(sum(closes[-10:]) / 10) if len(closes) >= 10 else ma5
            ma20 = _safe_round(sum(closes[-20:]) / 20) if len(closes) >= 20 else ma10
            ma60 = _safe_round(sum(closes[-60:]) / 60) if len(closes) >= 60 else _safe_round(sum(closes) / len(closes))
            ma120 = _safe_round(sum(closes[-120:]) / 120) if len(closes) >= 120 else ma60

            # 均线排列评分（0-100）
            ma_score = 50
            if ma5 > ma10 > ma20 > ma60:
                ma_desc = "强多头排列"
                ma_score = 90
            elif ma5 > ma10 > ma20:
                ma_desc = "多头排列"
                ma_score = 75
            elif ma5 > ma20:
                ma_desc = "弱势多头"
                ma_score = 60
            elif ma5 < ma10 < ma20 < ma60:
                ma_desc = "强空头排列"
                ma_score = 10
            elif ma5 < ma10 < ma20:
                ma_desc = "空头排列"
                ma_score = 25
            elif ma5 < ma20:
                ma_desc = "弱势空头"
                ma_score = 40
            else:
                ma_desc = "均线缠绕/震荡"
                ma_score = 50

            # 乖离率
            bias_ma5 = _safe_round((latest - ma5) / ma5 * 100, 2) if ma5 else 0
            bias_ma20 = _safe_round((latest - ma20) / ma20 * 100, 2) if ma20 else 0

            # ── MACD ──
            macd_result = _calc_macd(closes)
            macd_score = 50
            if isinstance(macd_result, dict) and "error" not in macd_result:
                if macd_result.get("dif", 0) > macd_result.get("dea", 0):
                    macd_score = 70 if macd_result.get("macd", 0) > 0 else 60
                else:
                    macd_score = 30 if macd_result.get("macd", 0) < 0 else 40
                if "金叉" in str(macd_result.get("signals", [])):
                    macd_score += 15
                elif "死叉" in str(macd_result.get("signals", [])):
                    macd_score -= 15

            # ── RSI ──
            rsi_result = _calc_rsi(closes, [6, 12, 24])
            rsi_score = 50
            if isinstance(rsi_result, dict) and "error" not in rsi_result:
                rsi6 = rsi_result.get("rsi6", 50)
                if rsi6 >= 70:
                    rsi_score = 25
                elif rsi6 <= 30:
                    rsi_score = 75
                else:
                    rsi_score = int(rsi6)

            # ── 布林带 ──
            boll_result = _calc_boll(closes)
            boll_score = 50
            if isinstance(boll_result, dict) and "error" not in boll_result:
                pos = boll_result.get("position_pct", 50)
                if pos >= 80:
                    boll_score = 30
                elif pos <= 20:
                    boll_score = 70
                else:
                    boll_score = int(50 + (50 - pos) * 0.4)

            # ── KDJ ──
            kdj_result = _calc_kdj(data["high"], data["low"], closes)
            kdj_score = 50
            if isinstance(kdj_result, dict) and "error" not in kdj_result:
                j = kdj_result.get("j", 50)
                if j >= 100:
                    kdj_score = 25
                elif j <= 0:
                    kdj_score = 75
                elif "金叉" in str(kdj_result.get("signals", [])):
                    kdj_score = 70
                elif "死叉" in str(kdj_result.get("signals", [])):
                    kdj_score = 30

            # ── 综合评分 ──
            # A1a 因子权重接线（2026-09-26）：五维权重优先从 qd_agent_weights 取校准值，
            # 无数据回退启发式常量 + calibrated=false。
            # 注意：当前 factors 输出名是"多头:xxx"/"空头:xxx"，与维度名(ma/macd/...)不匹配，
            # 故 get_factor_weights 暂返回空 → 走回退分支。A1b 统一 factors 命名后自动生效。
            _BB_DEFAULT_WEIGHTS = {"ma": 0.30, "macd": 0.25, "rsi": 0.20,
                                   "boll": 0.15, "kdj": 0.10}
            try:
                from chain.store import get_factor_weights
                _bb_calibrated = get_factor_weights("bull_bear_research")
            except Exception:
                _bb_calibrated = {}
            if _bb_calibrated:
                _bb_w = _bb_calibrated
                _bb_calibrated_flag = True
            else:
                _bb_w = _BB_DEFAULT_WEIGHTS
                _bb_calibrated_flag = False

            total_score = int(
                ma_score * _bb_w.get("ma", 0.30) +
                macd_score * _bb_w.get("macd", 0.25) +
                rsi_score * _bb_w.get("rsi", 0.20) +
                boll_score * _bb_w.get("boll", 0.15) +
                kdj_score * _bb_w.get("kdj", 0.10)
            )
            total_score = max(0, min(100, total_score))

            if total_score >= 75:
                overall = "看多"
                buy_signal = "多指标共振看多"
                signal_score = total_score
            elif total_score >= 60:
                overall = "偏多"
                buy_signal = "偏多但需确认"
                signal_score = total_score
            elif total_score <= 25:
                overall = "看空"
                buy_signal = "多指标共振看空，建议回避"
                signal_score = total_score
            elif total_score <= 40:
                overall = "偏空"
                buy_signal = "偏空，观望为主"
                signal_score = total_score
            else:
                overall = "震荡"
                buy_signal = "多空分歧，观望"
                signal_score = total_score

            all_signals = []
            if isinstance(macd_result, dict):
                all_signals.extend(macd_result.get("signals", []))
            if isinstance(rsi_result, dict):
                all_signals.extend(rsi_result.get("signals", []))
            if isinstance(boll_result, dict):
                all_signals.extend(boll_result.get("signals", []))
            if isinstance(kdj_result, dict):
                all_signals.extend(kdj_result.get("signals", []))

            change_pct = _safe_round((latest - prev) / prev * 100, 2) if prev else 0

            return {
                "codes": codes,
                "latest_close": _safe_round(latest),
                "change_pct": change_pct,
                "ma5": ma5, "ma10": ma10, "ma20": ma20, "ma60": ma60, "ma120": ma120,
                "ma_alignment": ma_desc,
                "bias_ma5": bias_ma5, "bias_ma20": bias_ma20,
                "macd": macd_result,
                "rsi": rsi_result,
                "boll": boll_result,
                "kdj": kdj_result,
                "trend_score": total_score,
                "trend": overall,
                "buy_signal": buy_signal,
                "signal_score": signal_score,
                "all_signals": all_signals,
                "data_points": len(closes),
                # A1a：权重是否来自 qd_agent_weights 校准
                "calibrated": _bb_calibrated_flag,
            }
        except Exception as e:
            logger.error("_analyze_trend(%s) failed: %s", codes, e)
            return {"error": str(e)}

    if len(code_list) == 1:
        return _one(code_list[0])

    results = {}
    for code in code_list:
        try:
            results[code] = _one(code)
        except Exception as e:
            results[code] = {"error": str(e)}
    return {"count": len(results), "data": results}

def _get_volume_analysis(codes: str) -> Dict[str, Any]:
    """量能分析：量比、换手率、成交量趋势。

    Args:
        codes: 多股用逗号分隔"
    """
    code_list = [c.strip() for c in codes.split(",") if c.strip()][:20]
    if not code_list:
        return {"error": "codes 不能为空", "retriable": False}

    def _one(codes: str) -> Dict[str, Any]:
        try:
            data = _fetch_ohlcv(codes, 30)
            volumes = data["volume"]
            closes = data["close"]
            if len(volumes) < 5:
                return {"error": "K线数据不足"}

            latest_vol = volumes[-1]
            avg_vol_5 = sum(volumes[-5:]) / 5
            avg_vol_20 = sum(volumes) / len(volumes)

            volume_ratio = _safe_round(latest_vol / avg_vol_5, 2) if avg_vol_5 else 0

            if volume_ratio > 2.0:
                status = "显著放量"
                meaning = "放量，需结合价格方向判断"
            elif volume_ratio > 1.5:
                status = "温和放量"
                meaning = "成交活跃度提升"
            elif volume_ratio < 0.5:
                status = "明显缩量"
                meaning = "缩量，抛压减轻或交投清淡"
            elif volume_ratio < 0.8:
                status = "温和缩量"
                meaning = "成交活跃度下降"
            else:
                status = "平量"
                meaning = "成交量维持常态"

            vol_trend = "数据不足"
            if len(volumes) >= 6:
                recent_avg = sum(volumes[-3:]) / 3
                earlier_avg = sum(volumes[-6:-3]) / 3
                vol_trend = "上升" if recent_avg > earlier_avg * 1.1 else ("下降" if recent_avg < earlier_avg * 0.9 else "平稳")

            vol_price_relation = "数据不足"
            if len(closes) >= 2 and latest_vol > 0:
                price_change = closes[-1] - closes[-2]
                if price_change > 0 and volume_ratio > 1.3:
                    vol_price_relation = "量价齐升（健康上涨）"
                elif price_change > 0 and volume_ratio < 0.7:
                    vol_price_relation = "缩量上涨（上涨乏力，需警惕）"
                elif price_change < 0 and volume_ratio > 1.3:
                    vol_price_relation = "放量下跌（恐慌抛售）"
                elif price_change < 0 and volume_ratio < 0.7:
                    vol_price_relation = "缩量下跌（下跌动能减弱）"
                else:
                    vol_price_relation = "量价配合一般"

            return {
                "codes": codes,
                "latest_volume": _safe_round(latest_vol, 0),
                "avg_volume_5d": _safe_round(avg_vol_5, 0),
                "avg_volume_20d": _safe_round(avg_vol_20, 0),
                "volume_ratio": volume_ratio,
                "volume_status": status,
                "volume_meaning": meaning,
                "volume_trend": vol_trend,
                "vol_price_relation": vol_price_relation,
            }
        except Exception as e:
            logger.error("_get_volume_analysis(%s) failed: %s", codes, e)
            return {"error": str(e)}

    if len(code_list) == 1:
        return _one(code_list[0])

    results = {}
    for code in code_list:
        try:
            results[code] = _one(code)
        except Exception as e:
            results[code] = {"error": str(e)}
    return {"count": len(results), "data": results}

def _analyze_pattern(codes: str) -> Dict[str, Any]:
    """识别K线形态（增强版）：锤子线、十字星、吞没、早晨/晚星、三连阳/阴、长上影/下影、缺口等。

    Args:
        codes: 多股用逗号分隔"
    """
    code_list = [c.strip() for c in codes.split(",") if c.strip()][:20]
    if not code_list:
        return {"error": "codes 不能为空", "retriable": False}

    def _one(codes: str) -> Dict[str, Any]:
        try:
            data = _fetch_ohlcv(codes, 10)
            if len(data["close"]) < 3:
                return {"error": "K线数据不足"}

            patterns = []
            o, h, l, c = data["open"], data["high"], data["low"], data["close"]
            n = len(c)

            lo, lh, ll, lc = o[-1], h[-1], l[-1], c[-1]
            body = abs(lc - lo)
            candle_range = lh - ll if lh > ll else 0.001
            upper_shadow = lh - max(lo, lc)
            lower_shadow = min(lo, lc) - ll

            if body > 0 and candle_range > 0:
                if lower_shadow >= 2 * body and upper_shadow <= body * 0.3:
                    patterns.append("锤子线（底部反转信号）")
                elif upper_shadow >= 2 * body and lower_shadow <= body * 0.3:
                    patterns.append("倒锤子线（顶部反转信号）")

            if body <= candle_range * 0.1:
                if upper_shadow > candle_range * 0.3 and lower_shadow > candle_range * 0.3:
                    patterns.append("长腿十字星（强烈犹豫信号）")
                elif upper_shadow > candle_range * 0.4 and lower_shadow < candle_range * 0.1:
                    patterns.append("墓碑线（顶部反转）")
                elif lower_shadow > candle_range * 0.4 and upper_shadow < candle_range * 0.1:
                    patterns.append("蜻蜓线（底部反转）")
                else:
                    patterns.append("十字星（犹豫信号）")

            if upper_shadow > body * 2 and upper_shadow > lower_shadow * 2:
                patterns.append("长上影线（上方压力大）")

            if lower_shadow > body * 2 and lower_shadow > upper_shadow * 2:
                patterns.append("长下影线（下方支撑强）")

            if body > candle_range * 0.85:
                if lc > lo:
                    patterns.append("光头光脚大阳线（强势）")
                else:
                    patterns.append("光头光脚大阴线（弱势）")

            if n >= 2:
                po, pc = o[-2], c[-2]
                prev_body = abs(pc - po)
                if prev_body > 0 and body > prev_body:
                    if pc < po and lc > lo and lo <= pc and lc >= po:
                        patterns.append("看涨吞没（底部反转）")
                    elif pc > po and lc < lo and lo >= pc and lc <= po:
                        patterns.append("看跌吞没（顶部反转）")

            if n >= 3:
                o1, c1 = o[-3], c[-3]
                o2, c2 = o[-2], c[-2]
                o3, c3 = o[-1], c[-1]
                body1 = abs(c1 - o1)
                body2 = abs(c2 - o2)
                body3 = abs(c3 - o3)

                if (c1 < o1 and body1 > 0 and
                        body2 < body1 * 0.3 and
                        c3 > o3 and body3 > 0 and
                        c3 > (o1 + c1) / 2):
                    patterns.append("早晨之星（底部反转，看多）")

                if (c1 > o1 and body1 > 0 and
                        body2 < body1 * 0.3 and
                        c3 < o3 and body3 > 0 and
                        c3 < (o1 + c1) / 2):
                    patterns.append("黄昏之星（顶部反转，看空）")

                if c1 > o1 and c2 > o2 and c3 > o3:
                    if body3 > body2 > body1:
                        patterns.append("三连阳递增（强势看多）")
                    else:
                        patterns.append("三连阳（多头排列）")

                if c1 < o1 and c2 < o2 and c3 < o3:
                    if body3 > body2 > body1:
                        patterns.append("三连阴递增（强势看空）")
                    else:
                        patterns.append("三连阴（空头排列）")

                if (c1 > o1 and c2 > o2 and c3 > o3 and
                        c2 > c1 and c3 > c2 and
                        o2 > o1 and o3 > o2):
                    patterns.append("红三兵（强烈看多）")

                if (c1 < o1 and c2 < o2 and c3 < o3 and
                        c2 < c1 and c3 < c2 and
                        o2 < o1 and o3 < o2):
                    patterns.append("黑三鸦（强烈看空）")

            if n >= 2:
                prev_high = h[-2]
                prev_low = l[-2]
                if l[-1] > prev_high:
                    gap_size = _safe_round((l[-1] - prev_high) / prev_high * 100, 2)
                    patterns.append(f"向上跳空缺口（幅度{gap_size}%）")
                elif h[-1] < prev_low:
                    gap_size = _safe_round((prev_low - h[-1]) / prev_low * 100, 2)
                    patterns.append(f"向下跳空缺口（幅度{gap_size}%）")

            if not patterns:
                patterns.append("无明显特殊形态")

            return {
                "codes": codes,
                "latest_candle": {"open": _safe_round(lo), "high": _safe_round(lh),
                                  "low": _safe_round(ll), "close": _safe_round(lc)},
                "body_size": _safe_round(body),
                "upper_shadow": _safe_round(upper_shadow),
                "lower_shadow": _safe_round(lower_shadow),
                "patterns": patterns,
                "pattern_count": len([p for p in patterns if "无明显" not in p]),
            }
        except Exception as e:
            logger.error("_analyze_pattern(%s) failed: %s", codes, e)
            return {"error": str(e)}

    if len(code_list) == 1:
        return _one(code_list[0])

    results = {}
    for code in code_list:
        try:
            results[code] = _one(code)
        except Exception as e:
            results[code] = {"error": str(e)}
    return {"count": len(results), "data": results}

def _get_chip_distribution(codes: str, lookback_days: int = 120) -> Dict[str, Any]:
    """筹码分布分析 — 委托给 chip_distribution.get_chip_distribution。"""
    from tools.finance.chip_distribution import get_chip_distribution
    return get_chip_distribution(codes, lookback_days=lookback_days)

def _get_indicator_snapshot(codes: str) -> Dict[str, Any]:
    """单次获取多个技术指标快照（MACD、RSI、BOLL、KDJ等）。

    Args:
        codes: 多股用逗号分隔"
    """
    code_list = [c.strip() for c in codes.split(",") if c.strip()][:20]
    if not code_list:
        return {"error": "codes 不能为空", "retriable": False}

    def _one(codes: str) -> Dict[str, Any]:
        try:
            data = _fetch_ohlcv(codes, 120)
            closes = data["close"]
            if len(closes) < 10:
                return {"error": "K线数据不足（至少需要10根）", "retriable": True}

            result = {"codes": codes, "latest_close": _safe_round(closes[-1])}

            for p in [5, 10, 20, 60, 120]:
                if len(closes) >= p:
                    result[f"ma{p}"] = _safe_round(sum(closes[-p:]) / p)

            macd = _calc_macd(closes)
            if "error" not in macd:
                result["macd"] = macd

            rsi = _calc_rsi(closes, [6, 12, 24])
            if "error" not in rsi:
                result["rsi"] = rsi

            boll = _calc_boll(closes)
            if "error" not in boll:
                result["boll"] = boll

            kdj = _calc_kdj(data["high"], data["low"], closes)
            if "error" not in kdj:
                result["kdj"] = kdj

            if len(data["volume"]) >= 5:
                vol = data["volume"][-1]
                avg5 = sum(data["volume"][-5:]) / 5
                result["volume_ratio"] = _safe_round(vol / avg5, 2) if avg5 else 0

            return result
        except Exception as e:
            logger.error("_get_indicator_snapshot(%s) failed: %s", codes, e)
            return {"error": str(e)}

    if len(code_list) == 1:
        return _one(code_list[0])

    results = {}
    for code in code_list:
        try:
            results[code] = _one(code)
        except Exception as e:
            results[code] = {"error": str(e)}
    return {"count": len(results), "data": results}
