# -*- coding: utf-8 -*-
"""
Data tools — real-time quotes, K-lines, stock info, market indices.
Wraps DataSourceFactory into OpenAI-function-callable tools.
"""
from __future__ import annotations

import json
import os
from log import logger
from typing import Any, Dict, List, Optional

from tools.finance._analysis_utils import _get_ds
from utils.md_format import _batch_execute, _to_md

# ── 指数行情 / 市场概览 ──────────────────────────────────────

def get_market_indices() -> dict:
    """指数行情：返回上证/深证/创业板/科创/北证五大指数的价格、涨跌幅、成交量。

    Returns:
        {"count": N, "indices": [{code, name, price, change_percent, ...}]} —— dict，
        指数列表在二级键 indices（list）；失败 → {"error": ...}
    """
    from app.market_cn.index import get_index_realtime as _get
    try:
        data = _get()
        return {"count": len(data), "indices": data}
    except Exception as e:
        logger.warning("get_market_indices failed: %s", e)
        return {"error": str(e)}

def get_market_overview() -> dict:
    """市场概览：返回市场情绪指数、主力资金流向、指数涨跌概况。

    2026-09-14 移除北向资金字段（与 get_northbound_flow 摘除同因）：上游同花顺
    hexin 实时接口数据源残缺（实测 sgt 仅 13% 完整度，接口自判"北向数据不完整"）
    ——北向实时披露已停，属数据源性死亡而非临时故障。留在聚合里，每次调用都要
    白等一个必死请求，还诱导模型每轮写"北向资金：未明确返回"。日级历史
    （get_northbound_daily）不受影响。

    注意字段语义：up_count/down_count 是**两大指数（上证/深成）的涨跌抽样**，
    不是全市场涨跌家数——全市场维度请用 get_market_indices 自行汇总。

    Returns:
        dict: {up_count, down_count(两大指数抽样涨跌家数), emotion(0-100情绪),
        main_net_yi(主力净流亿元), main_pct}。单源失败则该键缺失，无 error 键
    """
    result = {}

    # 指数行情 → 涨跌概况（仅两大指数抽样，非全市场）
    try:
        from app.market_cn.index import get_index_realtime
        indices = get_index_realtime(["000001", "399001"])
        up = sum(1 for i in (indices or []) if i.get("change_percent", 0) > 0)
        down = sum(1 for i in (indices or []) if i.get("change_percent", 0) < 0)
        result["up_count"] = up
        result["down_count"] = down
    except Exception:
        pass

    # 情绪指数
    try:
        from app.market_cn.fear_greed_index import fear_greed_index
        fg = fear_greed_index()
        result["emotion"] = int(fg.get("composite_score", 50))
    except Exception:
        pass

    # 主力资金流
    try:
        from app.market_cn.index import get_market_fund_flow_realtime
        mf = get_market_fund_flow_realtime()
        result["main_net_yi"] = round(mf.get("main_net", 0) / 1e8, 2)
        result["main_pct"] = round(mf.get("main_pct", 0), 2)
    except Exception:
        pass

    return result

# ── Tool functions ────────────────────────────────────────────

def resolve_stock(keyword: str, market: str = "CNStock", limit: int = 10) -> Dict[str, Any]:
    """股票名称/代码双向解析。输入名称返回代码，输入代码返回名称，支持模糊搜索。

    Args:
        keyword: 搜索关键词（中文名称、代码、简拼等）
        market: 市场，默认 CNStock
        limit: 返回数量上限，默认10

    Returns:
        单只 → {"code": "...", "name": "...", "market": "..."}
        多只 → {"count": N, "data": [{"code": "...", ...}, ...]}
        失败 → {"error": "...", "retriable": false}
    """
    keyword = (keyword or "").strip()
    if not keyword:
        return {"error": "搜索关键词不能为空", "retriable": False}

    limit = min(max(limit, 1), 50)
    try:
        from app.utils.basicinfo_db import get_stock_basic_db
        matches = get_stock_basic_db().search_stocks(keyword, limit=limit)
        items = [
            {"code": m["symbol"], "name": m.get("name", ""), "market": m.get("market_cn", market)}
            for m in matches
        ]
        if len(items) == 1:
            return items[0]
        return {"count": len(items), "data": items}
    except Exception as e:
        logger.error("resolve_stock(%s) failed: %s", keyword, e)
        return {"error": str(e), "retriable": False}


def get_realtime_quote(codes: str) -> Dict[str, Any]:
    """实时行情：价格、涨跌幅、成交量、换手率、量比、PE、PB、总市值等。

    Args:
        codes: 多股用逗号分隔

    Returns:
        统一结构（单/多代码一致，2026-09-24 起）：{"count": N, "data": {代码: 行情dict},
        "error": None}；行情dict 字段：{stock_code, last, changePercent, volume, name,
        high, low, open, previousClose, time} + 涨跌停价 {limit_up, limit_down}
        （来自腾讯源增补，供涨跌停判定）；失败 → {"error": "...", "retriable": False}
    """
    # 归一化：剥离市场后缀（.SZ/.SH）与市场前缀（sh/sz），与 get_tickers 的
    # symbol 键对齐（get_tickers 返回的 symbol 是纯代码，如 "300497"）。
    # 若不归一化，.SZ 后缀输入会查不到 → 误报"未获取到行情"（2026-09-22 修复）。
    code_list = [c.strip() for c in codes.split(",") if c.strip()][:20]
    if not code_list:
        return {"error": "codes 不能为空", "retriable": False}
    code_list = [_strip_prefix(c) for c in code_list]

    ds = _get_ds("CNStock")

    # 批量接口：一次 coordinate_tickers 拉全部
    try:
        tickers = ds.get_tickers(code_list)
    except Exception as e:
        logger.error("get_realtime_quote batch failed: %s", e)
        tickers = []

    # 按 symbol 索引
    ticker_map: Dict[str, Dict] = {}
    for t in tickers:
        sym = t.get("symbol", "")
        if sym:
            ticker_map[sym] = t

    results: Dict[str, Any] = {}
    for code in code_list:
        t = ticker_map.get(code)
        if t:
            results[code] = {"stock_code": code, "market": "CNStock", **t}
        else:
            results[code] = {"error": "未获取到行情", "stock_code": code}

    # 2026-09-24：并入统一三键契约（与 _batch_execute 系一致，消除单/多二义性）；
    # 并增补涨跌停价（get_tickers 无此字段，模型做创业板 20% 判定需要）——
    # 一次批量腾讯调用补全，失败不阻塞主结果（limit_up 缺省 None）。
    try:
        raw_q = _tencent_quote_raw(code_list)
        for code in code_list:
            tq = raw_q.get(code) or {}
            item = results.get(code)
            if isinstance(item, dict) and "error" not in item:
                item.setdefault("limit_up", tq.get("limit_up"))
                item.setdefault("limit_down", tq.get("limit_down"))
    except Exception as e:
        logger.debug("get_realtime_quote 涨跌停增补跳过: %s", e)
    return {"count": len(results), "data": results, "error": None}

def agent_get_kline(codes, timeframe: str = "1D", days: int = 30, adj: str = "qfq") -> Dict[str, Any]:
    """K线数据：返回统一结构的 OHLCV 序列，支持 A 股，1D/1W 走本地库直连。

    ⚠ 仅在需要原始数据或自定义计算时调用。趋势/指标/形态/量价/筹码分析已内置K线获取，不要重复调用。

    Returns:
        {"count": N, "data": {代码: [{"t","o","h","l","c","v"}, ...]}}；
        失败 → {"error": "...", "retriable": bool}（error 键恒参与，成功时为 None）
        注意：无论单代码还是多代码，data 都是"代码 → K线列表"的映射，取单只用 data[codes]。

    Args:
        codes: 股票代码，字符串（如 "603466"）或代码列表均可，多股逗号分隔
        timeframe: 1m/5m/15m/30m/1H/4H/1D/1W，默认 1D
        days: 天数，默认 30，最大 250
        adj: 复权口径 qfq(前复权,默认)/hfq(后复权)/none(不复权)。返回 data 各 bar 含 adj 标注。

    2026-09-25：补 adj——底层本就做 qfq，分析/回测口径不可比的缺口在工具层未暴露。
    """
    # codes 容错：模型可能传 list / list[tuple] / 数字 / 带前后缀串
    if isinstance(codes, (list, tuple)):
        _parts = []
        for c in codes:
            if isinstance(c, (list, tuple)) and c:
                c = c[0]
            _parts.append(str(c))
        codes = ",".join(_parts)
    else:
        codes = str(codes)

    raw_codes = [c.strip() for c in codes.split(",") if c.strip()][:20]
    # 查询用裸码（DB/远端按裸码），返回键用原始入参码（模型视角一致）——
    # 2026-09-22 修复：入参 '600519.SH' strip 后用裸码做返回键，模型按
    # data['600519.SH'] 取值落空，指标全缺（07:19 轮红字根因）。
    code_list = [_strip_prefix(c) for c in raw_codes]
    if not code_list:
        return {"error": "codes 不能为空", "retriable": False}

    valid_timeframes = {"1m", "5m", "15m", "30m", "1H", "4H", "1D", "1W"}
    if timeframe not in valid_timeframes:
        return {"error": f"无效周期: {timeframe}，可选: {','.join(sorted(valid_timeframes))}", "retriable": False}
    _days = min(max(int(days), 1), 250)

    # 直连 CNStockDataSource（cn_stock.py）：1D/1W 本地 DB + TTL 快路径，
    # 盘中分钟线走远端。不再经 coordinator 二次包装。
    from app.data_sources.cn_stock import CNStockDataSource

    def _fetch(stock_code: str) -> list:
        try:
            ds = CNStockDataSource()
            bars = ds.get_kline(stock_code, timeframe, _days) or []
            # ds.get_kline 内部已 unadj→qfq；adj 要求 hfq/none 时再换算（单一事实源 adjustment）
            _adj = (adj or "qfq").lower()
            if _adj in ("none", "raw", "unadj"):
                try:
                    from app.data_sources.provider.adjustment import reverse_fwd_adjust
                    bars = reverse_fwd_adjust(bars, stock_code) or bars
                except Exception as _adj_err:
                    logger.warning("agent_get_kline adj=none 转换失败(%s): %s", stock_code, _adj_err)
            elif _adj == "hfq":
                try:
                    from app.data_sources.provider.adjustment import (
                        reverse_fwd_adjust, unadj_to_hfq,
                    )
                    raw = reverse_fwd_adjust(bars, stock_code) or bars
                    bars = unadj_to_hfq(raw, stock_code) or raw
                except Exception as _adj_err:
                    logger.warning("agent_get_kline adj=hfq 转换失败(%s): %s", stock_code, _adj_err)
            return bars
        except Exception as e:
            logger.error("agent_get_kline.get_kline(%s, %s, %d) failed: %s",
                         stock_code, timeframe, _days, e)
            return []

    def _ts_to_date(ts) -> str:
        try:
            from datetime import datetime
            return datetime.fromtimestamp(int(ts)).strftime("%m-%d")
        except Exception:
            return str(ts)

    results: Dict[str, Any] = {}
    for raw, code in zip(raw_codes, code_list):
        klines = _fetch(code)
        results[raw] = [{
            "t": k.get("date") or _ts_to_date(k.get("time", 0)),
            "o": round(k.get("open", 0), 2),
            "h": round(k.get("high", 0), 2),
            "l": round(k.get("low", 0), 2),
            "c": round(k.get("close", 0), 2),
            "v": k.get("volume", 0),
        } for k in klines]

    # 统一形态：单/多代码都是 {count, data: {code: [...]}}，error 键恒在
    # （2026-09-21 修复：旧版单代码返回裸 list、多代码返回 dict 的二义性导致
    #  模型拿 list 当 dict 切片 → TypeError "string indices must be integers"，
    #  连续两次触发熔断，是 step 爆炸的主要推手之一）
    return {"count": len(results), "data": results, "adj": (adj or "qfq").lower(), "error": None}

# ── 核心字段集（Agent 日常分析最常用的 ~15 个字段） ──────────────────────
_STOCK_INFO_CORE_FIELDS = {
    "stock_code", "name", "industry", "concepts",
    "price", "change_pct",
    "pe_ratio", "pe_ttm", "pe_static", "pb_ratio",
    "market_cap", "mcap_yi", "float_market_cap", "float_mcap_yi",
    "roe", "eps", "bvps",
    "total_shares", "circ_shares",
    "turnover_pct", "vol_ratio",
    "list_date", "main_business",
    "source", "market_cn",
}
def _filter_stock_info(info: Dict[str, Any], detail: bool = False) -> Dict[str, Any]:
    """过滤股票信息，去除 None 值；非 detail 模式只保留核心字段。"""
    if not isinstance(info, dict):
        return info
    # error 直接透传，不过滤
    if "error" in info:
        return info
    if detail:
        return {k: v for k, v in info.items() if v is not None}
    return {k: v for k, v in info.items() if v is not None and k in _STOCK_INFO_CORE_FIELDS}

def get_stock_info(codes: str, detail: bool = False) -> Dict[str, Any]:
    """股票基本信息（精简模式，节省 token）。

    默认返回核心字段：名称、行业、价格、PE/PB、市值、ROE、EPS、股本等。
    数据量小，Agent 直接评估更靠谱，不出评分。
    如需完整财务数据（利润表/资产负债表/现金流/股东/杜邦），设置 detail=true。

    Returns:
        单代码 → 扁平 dict（核心字段 name/price/pe_ratio/mcap_yi 等，detail=true 时50+字段）；
        多代码 → {"count": N, "data": {代码: dict}}；失败 → {"error": ...}

    Args:
        codes: 多股用逗号分隔
        detail: false=精简（默认），true=完整（50+字段）
    """
    code_list = [c.strip() for c in codes.split(",") if c.strip()][:20]
    if not code_list:
        return {"error": "codes 不能为空", "retriable": False}

    # 缓存检查已移除：basicinfo_db 本地快读 + HTTP 5s 竞赛替代

    def _one(stock_code: str) -> Dict[str, Any]:
        from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeout
        from app.data_sources.normalizer import strip_market_prefix

        sym = strip_market_prefix(stock_code)

        # ── 1) basicinfo_db 本地快读（毫秒级）──
        db_result: Dict[str, Any] = {}
        try:
            from app.utils.basicinfo_db import get_stock_basic_db
            db = get_stock_basic_db()
            stock = db.get_stock(sym)
            if stock:
                db_result = {"stock_code": sym}
                for fld in ("name", "industry", "total_shares", "circ_shares",
                            "market_cn", "list_date"):
                    val = stock.get(fld)
                    if val is not None and val != "":
                        db_result[fld] = val
                concepts_str = stock.get("concepts", "")
                if concepts_str:
                    db_result["concepts"] = [c.strip() for c in concepts_str.split(",") if c.strip()]
                db_result["source"] = "basicinfo_db"
        except Exception as e:
            logger.warning("get_stock_info(%s) basicinfo_db failed: %s", stock_code, e)

        # ── 2) HTTP 实时拉取（5s 超时竞赛）──
        def _http_fetch() -> Dict[str, Any]:
            # 数据源原生
            try:
                ds = _get_ds("CNStock")
                if hasattr(ds, "get_stock_info"):
                    info = ds.get_stock_info(stock_code)
                    if isinstance(info, dict) and not info.get("error"):
                        return info
                    elif isinstance(info, str):
                        try:
                            parsed = json.loads(info)
                            if isinstance(parsed, dict):
                                return parsed
                        except (ValueError, TypeError):
                            pass
            except (NotImplementedError, Exception) as e:
                logger.debug("get_stock_info(%s) datasource failed: %s", stock_code, e)

            # cn_stock_info 兜底
            try:
                from app.utils.cn_stock_info import get_cn_stock_info
                info = get_cn_stock_info(stock_code)
                if info and not info.get("error"):
                    return info
            except Exception as e:
                logger.debug("get_stock_info(%s) cn_stock_info failed: %s", stock_code, e)
            return {}

        # 2026-09-26: DB 不再存 pe_ratio/pb_ratio，HTTP 竞赛仅用于 DB 未命中时兜底
        # DB 命中（有 name）→ 跳过 20s 大竞赛，实时估值由腾讯 3s 补全负责
        # DB 未命中 → 走完整 HTTP 竞赛兜底
        _needs_http = not db_result or not db_result.get("name")
        _http_timeout = int(os.getenv("STOCK_INFO_HTTP_TIMEOUT", "20"))

        http_result: Dict[str, Any] = {}
        if _needs_http:
            _pool = ThreadPoolExecutor(max_workers=1)
            try:
                future = _pool.submit(_http_fetch)
                http_result = future.result(timeout=_http_timeout)
            except FuturesTimeout:
                logger.info("get_stock_info(%s) HTTP %ds 超时，使用 basicinfo_db", stock_code, _http_timeout)
            except Exception as e:
                logger.debug("get_stock_info(%s) HTTP fetch error: %s", stock_code, e)
            finally:
                _pool.shutdown(wait=False)

        # ── 3) 合并：basicinfo_db 为底，HTTP 补充新字段 ──
        result = {**db_result, **{k: v for k, v in http_result.items() if v is not None}}

        if not result:
            return {"error": f"无法获取 {stock_code} 的基本面信息", "retriable": False}

        if http_result:
            result["source"] = "http"
        # else: 保持 basicinfo_db source

        # ── 4) 腾讯实时估值补全（3s 超时保护）──
        try:
            def _tencent_fetch():
                return _tencent_quote_raw([sym])
            _tpool = ThreadPoolExecutor(max_workers=1)
            try:
                tq = _tpool.submit(_tencent_fetch).result(timeout=3)
            finally:
                _tpool.shutdown(wait=False)
            q = tq.get(sym)
            if q:
                result.setdefault("price", q.get("price"))
                result.setdefault("change_pct", q.get("change_pct"))
                if q.get("pe_ttm"):
                    result["pe_ttm"] = q["pe_ttm"]
                if q.get("pe_static"):
                    result["pe_static"] = q["pe_static"]
                if q.get("pb"):
                    result["pb"] = q["pb"]
                if q.get("mcap_yi"):
                    result["mcap_yi"] = q["mcap_yi"]
                if q.get("float_mcap_yi"):
                    result["float_mcap_yi"] = q["float_mcap_yi"]
                if q.get("turnover_pct") is not None:
                    result["turnover_pct"] = q["turnover_pct"]
                if q.get("vol_ratio") is not None:
                    result["vol_ratio"] = q["vol_ratio"]
                if q.get("amplitude_pct") is not None:
                    result["amplitude_pct"] = q["amplitude_pct"]
                if q.get("amount_wan"):
                    result["amount_wan"] = q["amount_wan"]
                if q.get("limit_up"):
                    result["limit_up"] = q["limit_up"]
                if q.get("limit_down"):
                    result["limit_down"] = q["limit_down"]
        except FuturesTimeout:
            logger.info("get_stock_info(%s) 腾讯估值 3s 超时，跳过补全", stock_code)
        except Exception as e:
            logger.debug("get_stock_info(%s) 腾讯估值补全跳过: %s", stock_code, e)

        # ── 5) ROE / EPS / BVPS 补全 + PE/PB 本地计算 ──────────────
        # 2026-09-21: _sina_finance 0.75s 即含 ROE/EPS/bvps
        # 2026-09-28: EPS/BVPS 不再丢弃——用 price/eps 算 PE、price/bvps 算 PB
        if not result.get("roe") or not result.get("eps") or not result.get("bvps"):
            try:
                def _fin_fetch():
                    from app.utils.cn_stock_info import _sina_finance
                    return _sina_finance(sym) or {}
                _rpool = ThreadPoolExecutor(max_workers=1)
                try:
                    _fin = _rpool.submit(_fin_fetch).result(timeout=4)
                finally:
                    _rpool.shutdown(wait=False)
                if _fin:
                    result.setdefault("roe", _fin.get("roe"))
                    result.setdefault("eps", _fin.get("eps"))
                    result.setdefault("bvps", _fin.get("bvps"))
            except FuturesTimeout:
                logger.debug("get_stock_info(%s) 财务指标补全 4s 超时", stock_code)
            except Exception as e:
                logger.debug("get_stock_info(%s) 财务指标补全跳过: %s", stock_code, e)

        # ── 5b) PE/PB 本地计算（腾讯没给时用 price÷eps/bvps 算）──
        _px = result.get("price")
        if _px and not result.get("pe_ttm") and result.get("eps"):
            if result["eps"] > 0:
                result["pe_ttm"] = round(_px / result["eps"], 2)
        if _px and not result.get("pb") and result.get("bvps"):
            if result["bvps"] > 0:
                result["pb"] = round(_px / result["bvps"], 2)

        # ── 5c) 换手率/总市值 fallback（腾讯没给时用 mootdx 本地算）──
        if not result.get("turnover_pct"):
            try:
                from app.market_cn.tape import get_realtime_turnover
                _tr = get_realtime_turnover(sym)
                if isinstance(_tr, dict) and _tr.get("turnover_rate") is not None:
                    result["turnover_pct"] = _tr["turnover_rate"]
            except Exception as e:
                logger.debug("get_stock_info(%s) 换手率 fallback 跳过: %s", stock_code, e)

        if not result.get("mcap_yi") and _px and result.get("total_shares"):
            # 总市值(亿) = 价格 × 总股本(股) / 1e8
            result["mcap_yi"] = round(_px * result["total_shares"] / 1e8, 2)
        if not result.get("float_mcap_yi") and _px and result.get("circ_shares"):
            # 流通市值(亿) = 价格 × 流通股本(股) / 1e8
            result["float_mcap_yi"] = round(_px * result["circ_shares"] / 1e8, 2)

        return result

    if len(code_list) == 1:
        from tools.base import as_code_envelope
        one = _filter_stock_info(_one(code_list[0]), detail)
        _NUM_KEYS = ("pe_ratio", "pb_ratio", "market_cn", "mcap_yi", "float_mcap_yi",
                     "roe", "price", "change_pct", "pe_ttm", "pe_static", "turnover_pct",
                     "vol_ratio", "total_shares", "circ_shares")
        for _k in _NUM_KEYS:
            if _k in one and one[_k] is not None and not isinstance(one[_k], (int, float)):
                try:
                    one[_k] = float(one[_k])
                except Exception:
                    pass
        return as_code_envelope(code_list[0], one)

    results = {}
    for code in code_list:
        try:
            results[code] = _filter_stock_info(_one(code), detail)
        except Exception as e:
            results[code] = {"error": str(e)}
    return {"count": len(results), "data": results}

# ── 腾讯财经批量行情（内部共用） ──────────────────────────────

def _strip_prefix(s):
    from app.data_sources.normalizer import strip_market_prefix
    return strip_market_prefix(s)

def _tencent_quote_raw(codes: list) -> dict:
    """腾讯财经批量行情原始接口。返回 {code: {全部字段dict}}。"""
    import urllib.request

    prefixed = []
    for c in codes:
        c = _strip_prefix(c)
        # 2026-09-22 修复：旧逻辑把 000/001 开头的深市主板股映射成 sh 前缀
        # （如 000858 五粮液 → sh000858），腾讯对不存在标的返回错位字段，
        # 解析出 price=13765/pb=0 的坏数据。市场前缀统一按 normalizer 规则：
        # 沪市 6/9/5 开头 → sh；北交所 8/4 开头 → bj；其余（深市 0/2/3）→ sz。
        if c.startswith(("6", "9", "5")):
            prefixed.append(f"sh{c}")
        elif c.startswith(("8", "4")):
            prefixed.append(f"bj{c}")
        else:
            prefixed.append(f"sz{c}")

    url = "https://qt.gtimg.cn/q=" + ",".join(prefixed)
    req = urllib.request.Request(url)
    req.add_header("User-Agent", "Mozilla/5.0")
    resp = urllib.request.urlopen(req, timeout=10)
    data = resp.read().decode("gbk")

    result = {}
    for line in data.strip().split(";"):
        if not line.strip() or "=" not in line or '"' not in line:
            continue
        key = line.split("=")[0].split("_")[-1]
        vals = line.split('"')[1].split("~")
        if len(vals) < 53:
            continue
        code = key[2:]
        result[code] = {
            "name":           vals[1],
            "price":          float(vals[3]) if vals[3] else 0,
            "last_close":     float(vals[4]) if vals[4] else 0,
            "open":           float(vals[5]) if vals[5] else 0,
            "buy_vol":        float(vals[6]) if vals[6] else 0,
            "sell_vol":       float(vals[7]) if vals[7] else 0,
            "bid1_price":     float(vals[9]) if vals[9] else 0,
            "bid1_vol":       float(vals[10]) if vals[10] else 0,
            "bid2_price":     float(vals[11]) if vals[11] else 0,
            "bid2_vol":       float(vals[12]) if vals[12] else 0,
            "bid3_price":     float(vals[13]) if vals[13] else 0,
            "bid3_vol":       float(vals[14]) if vals[14] else 0,
            "bid4_price":     float(vals[15]) if vals[15] else 0,
            "bid4_vol":       float(vals[16]) if vals[16] else 0,
            "bid5_price":     float(vals[17]) if vals[17] else 0,
            "bid5_vol":       float(vals[18]) if vals[18] else 0,
            "ask1_price":     float(vals[19]) if vals[19] else 0,
            "ask1_vol":       float(vals[20]) if vals[20] else 0,
            "ask2_price":     float(vals[21]) if vals[21] else 0,
            "ask2_vol":       float(vals[22]) if vals[22] else 0,
            "ask3_price":     float(vals[23]) if vals[23] else 0,
            "ask3_vol":       float(vals[24]) if vals[24] else 0,
            "ask4_price":     float(vals[25]) if vals[25] else 0,
            "ask4_vol":       float(vals[26]) if vals[26] else 0,
            "ask5_price":     float(vals[27]) if vals[27] else 0,
            "ask5_vol":       float(vals[28]) if vals[28] else 0,
            "change_amt":     float(vals[31]) if vals[31] else 0,
            "change_pct":     float(vals[32]) if vals[32] else 0,
            "high":           float(vals[33]) if vals[33] else 0,
            "low":            float(vals[34]) if vals[34] else 0,
            "amount_wan":     float(vals[37]) if vals[37] else 0,
            "turnover_pct":   float(vals[38]) if vals[38] else 0,
            "pe_ttm":         float(vals[39]) if vals[39] else 0,
            "amplitude_pct":  float(vals[43]) if vals[43] else 0,
            "mcap_yi":        float(vals[44]) if vals[44] else 0,
            "float_mcap_yi":  float(vals[45]) if vals[45] else 0,
            "pb":             float(vals[46]) if vals[46] else 0,
            "limit_up":       float(vals[47]) if vals[47] else 0,
            "limit_down":     float(vals[48]) if vals[48] else 0,
            "vol_ratio":      float(vals[49]) if vals[49] else 0,
            "pe_static":      float(vals[52]) if vals[52] else 0,
        }
    return result

# ── 五档盘口 ──────────────────────────────────────────────────

def get_order_book(codes: str) -> dict:
    """五档盘口：返回买卖各5档价格和挂单量、涨跌幅、换手率、PE、市值等。

    Returns:
        统一结构（单/多股一致，2026-09-22 起）：{"count": N, "data": {代码: 单股结果},
        "error": None}；失败 → {"error": "...", "retriable": False}。单股结果字段：{code, name, price, change_percent, bid, ask}，五档在 bid/ask。

    Args:
        codes: 多股用逗号分隔
    """
    code_list = [c.strip() for c in codes.split(",") if c.strip()][:20]
    if not code_list:
        return {"error": "codes 不能为空", "retriable": False}

    def _one(stock_code: str) -> dict:
        code = _strip_prefix(stock_code)
        try:
            from app.market_cn.tape import get_order_book as _get_order_book
            result = _get_order_book(code)
            if "error" in result:
                return {"stock_code": code, "error": result["error"]}
            return result
        except Exception as e:
            logger.warning("get_order_book(%s) failed: %s", code, e)
            return {"stock_code": code, "error": str(e)}

    return _batch_execute(_one, code_list)

# ── 指数/ETF行情 ──────────────────────────────────────────────

def get_index_etf_quote(codes: str) -> dict:
    """指数/ETF行情：返回价格、涨跌幅、成交量，支持上证/深证/创业板/沪深300及对应ETF。

    Returns:
        dict: {total, quotes:[{code, name, price, change_pct, change_amt, high, low,
        amount_wan, open, last_close}]}，行情列表在 quotes；失败→{error}。

    Args:
        codes: 逗号分隔的代码，如 "000001,000300,399006,510050"
               指数：000001(上证) 399001(深证) 000300(沪深300) 399006(创业板)
               ETF：510050(上证50) 510300(沪深300) 159919(沪深300) 512880(证券)
    """
    code_list = [_strip_prefix(c.strip()) for c in codes.split(",") if c.strip()]
    if not code_list:
        return {"error": "请提供至少一个代码"}

    try:
        data = _tencent_quote_raw(code_list)
        results = []
        for code in code_list:
            q = data.get(code)
            if q:
                results.append({
                    "code": code,
                    "name": q["name"],
                    "price": q["price"],
                    "change_pct": q["change_pct"],
                    "change_amt": q["change_amt"],
                    "high": q["high"],
                    "low": q["low"],
                    "amount_wan": q["amount_wan"],
                    "open": q["open"],
                    "last_close": q["last_close"],
                })
            else:
                results.append({"code": code, "error": "未获取到数据"})
        _r = {"total": len(results), "quotes": results}
        return _r
    except Exception as e:
        logger.warning("get_index_etf_quote(%s) failed: %s", codes, e)
        return {"error": str(e)}

# ── 批量估值对比 ──────────────────────────────────────────────

def batch_valuation_compare(codes: str) -> dict:
    """估值对比：返回多只股票的PE/PB/市值/营收并排对比表。

    Returns:
        {"total": N, "stocks": [{code, name, price, pe_ttm, pb, mcap_yi, ...}]，
        "pe_sorted": [按PE升序的 code]}；失败 → {"error": ...}

    Args:
        codes: 逗号分隔的股票代码，如 "600519,000858,688017"
    """
    code_list = [_strip_prefix(c.strip()) for c in codes.split(",") if c.strip()]
    if not code_list:
        return {"error": "请提供至少一个股票代码"}
    if len(code_list) > 20:
        return {"error": "单次最多对比20只股票"}

    try:
        data = _tencent_quote_raw(code_list)
        results = []
        for code in code_list:
            q = data.get(code)
            if q:
                results.append({
                    "code": code,
                    "name": q["name"],
                    "price": q["price"],
                    "change_pct": q["change_pct"],
                    "pe_ttm": q["pe_ttm"],
                    "pb": q["pb"],
                    "mcap_yi": q["mcap_yi"],
                    "float_mcap_yi": q["float_mcap_yi"],
                    "turnover_pct": q["turnover_pct"],
                })
            else:
                results.append({"code": code, "error": "未获取到数据"})

        valid = [r for r in results if r.get("pe_ttm") and r["pe_ttm"] > 0]
        valid.sort(key=lambda x: x["pe_ttm"])

        _r = {
            "total": len(results),
            "stocks": results,
            "pe_sorted": [r["code"] for r in valid],
        }
        return _r
    except Exception as e:
        logger.warning("batch_valuation_compare(%s) failed: %s", codes, e)
        return {"error": str(e)}

# ═══════════════════════════════════════════════════════════════
# 基本面摘要（从 capital_tools.py 合并）
# ═══════════════════════════════════════════════════════════════

def _safe_float(v, default=0.0):
    from app.data_sources.normalizer import safe_float
    return safe_float(v, default)

def _market_prefix(code: str) -> str:
    if code.startswith(("6", "9")):
        return "sh"
    elif code.startswith("8"):
        return "bj"
    return "sz"

def _get_margin_trading(code: str, days: int = 60) -> Dict[str, Any]:
    """融资融券摘要。提取融资余额趋势+近期变化幅度。"""
    from tools.finance.em_utils import em_datacenter
    data = em_datacenter(
        "RPTA_WEB_RZRQ_GGMX",
        filter_str=f'(SCODE="{code}")',
        page_size=days,
        sort_columns="DATE", sort_types="-1",
    )
    if not data:
        return {"signal": "无数据"}

    latest = data[0]
    rz_latest = _safe_float(latest.get("RZYE"))  # 融资余额
    rz_5d_ago = _safe_float(data[4].get("RZYE")) if len(data) > 5 else rz_latest
    rz_change_pct = ((rz_latest / rz_5d_ago - 1) * 100) if rz_5d_ago else 0

    rq_latest = _safe_float(latest.get("RQYE"))  # 融券余额

    signal = "融资净流入" if rz_change_pct > 2 else "融资净流出" if rz_change_pct < -2 else "持平"
    return {
        "rz_balance": round(rz_latest / 1e4, 1),  # 万元
        "rz_5d_change_pct": round(rz_change_pct, 1),
        "rq_balance": round(rq_latest / 1e4, 1),
        "signal": signal,
    }

def _get_block_trades(code: str, page_size: int = 20) -> Dict[str, Any]:
    """大宗交易摘要。提取近期成交笔数、平均溢价率、机构买卖方向。"""
    from tools.finance.em_utils import em_datacenter
    data = em_datacenter(
        "RPT_DATA_BLOCKTRADE",
        filter_str=f'(SECURITY_CODE="{code}")',
        page_size=page_size,
        sort_columns="TRADE_DATE", sort_types="-1",
    )
    if not data:
        return {"signal": "无大宗交易记录"}

    premiums = []
    inst_buy = 0
    inst_sell = 0
    for row in data:
        close = _safe_float(row.get("CLOSE_PRICE"))
        deal_price = _safe_float(row.get("DEAL_PRICE"))
        if close:
            premiums.append((deal_price / close - 1) * 100)
        buyer = str(row.get("BUYER", ""))
        seller = str(row.get("SELLER", ""))
        if "机构" in buyer:
            inst_buy += 1
        if "机构" in seller:
            inst_sell += 1

    avg_premium = sum(premiums) / len(premiums) if premiums else 0
    signal = "溢价成交（正面）" if avg_premium > 5 else "折价成交（负面）" if avg_premium < -5 else "中性"
    return {
        "recent_count": len(data),
        "avg_premium_pct": round(avg_premium, 1),
        "inst_buy": inst_buy,
        "inst_sell": inst_sell,
        "signal": signal,
    }

def _get_holder_count(code: str) -> Dict[str, Any]:
    """股东户数摘要。提取最新户数、环比变化趋势。"""
    from tools.finance.em_utils import em_datacenter
    data = em_datacenter(
        "RPT_HOLDERNUMLATEST",
        filter_str=f'(SECURITY_CODE="{code}")',
        page_size=10,
        sort_columns="END_DATE", sort_types="-1",
    )
    if not data:
        return {"signal": "无数据"}

    latest = data[0]
    latest_count = _safe_float(latest.get("HOLDER_NUM"))
    prev_count = _safe_float(data[1].get("HOLDER_NUM")) if len(data) > 1 else latest_count
    change_pct = ((latest_count / prev_count - 1) * 100) if prev_count else 0
    avg_amount = _safe_float(latest.get("AVG_AMOUNT"))  # 户均持股

    signal = "筹码集中" if change_pct < -5 else "筹码分散" if change_pct > 5 else "持平"
    return {
        "latest_date": str(latest.get("END_DATE", ""))[:10],
        "holder_count": int(latest_count),
        "change_pct": round(change_pct, 1),
        "avg_amount": round(avg_amount, 0),
        "signal": signal,
    }

def _get_dividend_history(code: str) -> Dict[str, Any]:
    """分红送转摘要。提取累计分红次数、连续分红年数、近期派息水平。"""
    from tools.finance.em_utils import em_datacenter
    data = em_datacenter(
        "RPT_SHAREBONUS_DET",
        filter_str=f'(SECURITY_CODE="{code}")',
        page_size=20,
        sort_columns="EX_DIVIDEND_DATE", sort_types="-1",
    )
    if not data:
        return {"signal": "无分红记录"}

    years = set()
    total_bonus = 0.0
    for row in data:
        date_str = str(row.get("EX_DIVIDEND_DATE", ""))[:4]
        if date_str:
            years.add(date_str)
        total_bonus += _safe_float(row.get("PRETAX_BONUS_RMB"))

    return {
        "record_count": len(data),
        "dividend_years": len(years),
        "total_bonus_rmb": round(total_bonus, 3),
        "signal": "持续分红" if len(years) >= 3 else "偶有分红" if years else "无分红",
    }

def _get_financial_statements(code: str) -> Dict[str, Any]:
    """财报关键指标摘要。只提取 Agent 关心的几个数，不返回原始表格。"""
    import requests
    _UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
    prefix = _market_prefix(code)
    symbol = f"{prefix}{code}"

    summary: Dict[str, Any] = {}

    # 2026-09-15：旧视图 vFD_FinancialGuideLine 已被新浪下线（返回 {"__ERROR":0,"__ERRORMSG":"Invalid view go"}），
    # 改用 money.finance.sina.com.cn 新版三表视图（vFD_BalanceSheet / vFD_ProfitStatement）。
    # 新表结构：最大表为数据表，列0=项目名，列1+=报告期（第0行为日期行）。
    import requests
    _UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
    headers = {"User-Agent": _UA, "Referer": "https://finance.sina.com.cn/"}
    code_num = _strip_prefix(code)

    import pandas as pd
    from io import StringIO

    def _fetch_sina_table(path: str):
        try:
            r = requests.get(f"https://money.finance.sina.com.cn/corp/go.php/{path}/stockid/{code_num}/ctrl/part/displaytype/4.phtml",
                             headers=headers, timeout=15)
            r.encoding = "gbk"
            dfs = pd.read_html(StringIO(r.text))
            # 数据表 = 行数最多的那张（导航页表格都是 2~5 行的小表）
            return max(dfs, key=lambda d: d.shape[0]) if dfs else None
        except Exception as e:
            logger.warning("_get_financial_statements(%s) %s 抓取失败: %s", code, path, e)
            return None

    def _latest_value(df, keywords, exclude=None):
        """取最新报告期（列1）中匹配关键词的值。"""
        if df is None or df.shape[1] < 2:
            return None
        exclude = exclude or []
        for _, row in df.iterrows():
            item_name = str(row.iloc[0])
            if any(k in item_name for k in keywords) and not any(x in item_name for x in exclude):
                val = row.iloc[1]
                return val if pd.notna(val) else None
        return None

    # 资产负债表
    try:
        df_bs = _fetch_sina_table('vFD_BalanceSheet')
        summary["total_assets"] = _latest_value(df_bs, ["资产总计", "总资产"])
        summary["total_liabilities"] = _latest_value(df_bs, ["负债合计", "总负债"])
        summary["equity"] = _latest_value(df_bs, ["股东权益合计", "所有者权益合计", "归属母公司"])
        summary["cash"] = _latest_value(df_bs, ["货币资金"])
    except Exception as e:
        logger.warning("_get_financial_statements(%s) 资产负债表失败: %s", code, e)

    # 利润表
    try:
        df_is = _fetch_sina_table('vFD_ProfitStatement')
        summary["revenue"] = _latest_value(df_is, ["营业总收入", "营业收入"])
        summary["net_profit"] = _latest_value(df_is, ["净利润"], exclude=["扣非"])
    except Exception as e:
        logger.warning("_get_financial_statements(%s) 利润表失败: %s", code, e)

    return summary

def get_capital_summary(codes: str) -> dict:
    """基本面摘要：返回营收/利润增速、ROE、PE/PB估值、机构持仓变化等中长线指标。

    一次调用聚合融资融券、大宗交易、股东户数、分红送转、财报三表五大维度数据，
    并生成结构化摘要供中长线持仓决策参考。

    Returns:
        统一结构（单/多股一致，2026-09-22 起）：{"count": N, "data": {代码: 单股结果},
        "error": None}；失败 → {"error": "...", "retriable": False}。单股结果字段：{"summary": {margin, block_trade, holders, dividend, financials,
        overall_signal(中长线偏多/偏空/中性)}}。

    Args:
        codes: 多股用逗号分隔
    """
    code_list = [c.strip() for c in codes.split(",") if c.strip()][:20]
    if not code_list:
        return {"error": "codes 不能为空", "retriable": False}

    def _one(stock_code: str) -> dict:
        code = _strip_prefix(stock_code)

        # ── 并行采集五维数据（单源超时不阻断整体）────────────────────
        def _safe(fn, label):
            try:
                return fn()
            except Exception as e:
                logger.warning("[Capital] %s 超时/失败: %s", label, e)
                return {}

        margin = _safe(lambda: _get_margin_trading(code, days=60), "margin")
        block = _safe(lambda: _get_block_trades(code, page_size=20), "block")
        holders = _safe(lambda: _get_holder_count(code), "holders")
        dividend = _safe(lambda: _get_dividend_history(code), "dividend")
        financials = _safe(lambda: _get_financial_statements(code), "financials")

        # ── 直接组装摘要（子函数已返回浓缩指标，无需二次计算）──
        summary: Dict[str, Any] = {"stock_code": code}

        summary["margin"] = margin
        summary["block_trade"] = block
        summary["holders"] = holders
        summary["dividend"] = dividend
        summary["financials"] = financials

        # ── 综合信号 ─────────────────────────────────────────────
        signals = [
            margin.get("signal", ""),
            block.get("signal", ""),
            holders.get("signal", ""),
            dividend.get("signal", ""),
        ]
        positive = sum(1 for s in signals if "正面" in s or "看多" in s or "集中" in s or "持续" in s or "流入" in s)
        negative = sum(1 for s in signals if "负面" in s or "撤退" in s or "分散" in s or "流出" in s)

        if positive > negative:
            summary["overall_signal"] = "中长线偏多"
        elif negative > positive:
            summary["overall_signal"] = "中长线偏空"
        else:
            summary["overall_signal"] = "中性"

        return {"summary": summary}

    return _batch_execute(_one, code_list)
