# -*- coding: utf-8 -*-
"""
统一 Agent 入口

提供 Flask Blueprint 端点，也可作为 CLI 入口。
"""
from __future__ import annotations

import os
import logging
from types import SimpleNamespace

from constants import get_agent_max_steps
from llm import create_llm, QDSkillAdapter
from memory import (
    LocalMemory,
    PostgresMemory,
)
from qd_service import QDAgentService

logger = logging.getLogger(__name__)

# ---------- 加载 .env（Flask/uvicorn 入口需要显式加载）----------
try:
    from dotenv import load_dotenv
    _dotenv_path = os.path.join(os.path.dirname(__file__), "..", "..", ".env")
    load_dotenv(_dotenv_path, override=False)
except ImportError:
    pass

# ---------- 配置（来自 backend_api_python/.env）----------
VERSION = "1.0.0"
AGENT_ENV = os.getenv("AGENT_ENV", "development")

LLM_PROVIDER     = os.getenv("LLM_PROVIDER", "")
LLM_MODEL        = os.getenv("OPENAI_MODEL", "qwen-plus")
LLM_API_KEY      = os.getenv("OPENAI_API_KEY", "")
LLM_BASE_URL     = os.getenv("OPENAI_BASE_URL")
LLM_TEMPERATURE  = float(os.getenv("AGENT_LLM_TEMPERATURE", "0.1"))
# 可复现采样（2026-09-15）：同 seed 同输入消除采样路径抖动；未设置=不传（默认随机）。
# 注意：MoE 模型/网关负载均衡/实时数据使复现非严格，属"尽量可复现"而非"严格复现"。
_seed_env = os.getenv("AGENT_LLM_SEED", "").strip()
LLM_SEED         = int(_seed_env) if _seed_env else None
LLM_MAX_TOKENS   = int(os.getenv("OPENAI_MAX_TOKENS", "16384"))
MEMORY_MAX_HISTORY = int(os.getenv("AGENT_MEMORY_MAX_HISTORY", "2000"))
MEMORY_BACKEND    = os.getenv("MEMORY_BACKEND", "local").lower()
DATABASE_URL      = os.getenv("DATABASE_URL", "")
# 步数语义对齐（2026-10-01）：AGENT_MAX_STEPS 旧语义 = CodeAgent 代码轮数，
# mimo 语义 = 模型查询次数（一次查询可带多个工具调用）。1 轮 ≈ 2~3 次查询，
# 线性放大 QD_STEP_SCALE（默认 3）；精确控制用 QD_STEP_LIMIT 直接覆盖。
MAX_TOOL_ROUNDS = int(os.getenv("QD_STEP_LIMIT") or max(1, get_agent_max_steps() * int(os.getenv("QD_STEP_SCALE", "3"))))  # 统一常量源 constants.py（审计 B2）
DEFAULT_SESSION_ID = "default"

# ---------- settings 兼容对象（cli.py / flask_app.py 使用）----------
settings = SimpleNamespace(
    version=VERSION,
    env=AGENT_ENV,
    llm=SimpleNamespace(
        provider=LLM_PROVIDER,
        qd_provider=LLM_PROVIDER,
        model=LLM_MODEL,
        api_key=LLM_API_KEY,
        base_url=LLM_BASE_URL,
        temperature=LLM_TEMPERATURE,
        max_tokens=LLM_MAX_TOKENS,
    ),
    memory=SimpleNamespace(max_history=MEMORY_MAX_HISTORY),
)

# ---------- 初始化 ----------
llm = create_llm({
    "provider": LLM_PROVIDER,
    "model": LLM_MODEL,
    "api_key": LLM_API_KEY,
    "base_url": LLM_BASE_URL,
    "temperature": LLM_TEMPERATURE,
    "max_tokens": LLM_MAX_TOKENS,
    "seed": LLM_SEED,
})

if MEMORY_BACKEND == "postgres" and DATABASE_URL:
    memory = PostgresMemory(
        dsn=DATABASE_URL,
        max_messages=MEMORY_MAX_HISTORY,
    )
    logger.info("使用 PostgresMemory: %s", DATABASE_URL.replace("://", "://***@"))
elif MEMORY_BACKEND == "postgres" and not DATABASE_URL:
    logger.warning("MEMORY_BACKEND=postgres 但 DATABASE_URL 未设置，回退 LocalMemory")
    memory = LocalMemory(max_messages=MEMORY_MAX_HISTORY)
else:
    memory = LocalMemory(max_messages=MEMORY_MAX_HISTORY)

# 技能适配器
skills = QDSkillAdapter()

# RAG 检索器
# 三路召回：向量(llama.cpp本地) + PostgreSQL FTS + 关键词 + Reranker精排
RAG_TOP_K = int(os.getenv("RAG_TOP_K", "5"))
RAG_SCORE_THRESHOLD = float(os.getenv("RAG_SCORE_THRESHOLD", "0.5"))
EMBEDDING_PROVIDER = os.getenv("EMBEDDING_PROVIDER", "")  # llamacpp / dashscope / openai
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "")
EMBEDDING_BASE_URL = os.getenv("EMBEDDING_BASE_URL", "")
EMBEDDING_API_KEY = os.getenv("EMBEDDING_API_KEY", "")

# Reranker 配置
RERANKER_PROVIDER = os.getenv("RERANKER_PROVIDER", "")  # local / api
RERANKER_MODEL = os.getenv("RERANKER_MODEL", "BAAI/bge-reranker-v2-m3")
RERANKER_API_URL = os.getenv("RERANKER_API_URL", "")
RERANKER_API_KEY = os.getenv("RERANKER_API_KEY", "")
RERANK_TOP_K = int(os.getenv("RERANK_TOP_K", "20"))  # RRF 后送入 reranker 的数量

# 聊天历史检索开关（.env 中设置 CHAT_HISTORY_SEARCH_ENABLED=true 启用）
CHAT_HISTORY_SEARCH_ENABLED = os.getenv("CHAT_HISTORY_SEARCH_ENABLED", "").lower() in ("true", "1", "yes")

def _build_reranker():
    """构建 Reranker 精排模型。"""
    if not RERANKER_PROVIDER:
        return None
    try:
        from rag.retriever import BGEReranker
        use_api = RERANKER_PROVIDER.lower() == "api"
        reranker = BGEReranker(
            model_path=RERANKER_MODEL,
            use_api=use_api,
            api_url=RERANKER_API_URL,
            api_key=RERANKER_API_KEY,
        )
        logger.info("[RAG] Reranker 已启用: provider=%s model=%s", RERANKER_PROVIDER, RERANKER_MODEL)
        return reranker
    except Exception as e:
        logger.warning("[RAG] Reranker 初始化失败: %s", e)
        return None


def _build_retriever():
    """构建 RAG 检索器。"""
    try:
        from rag import (
            EmbeddingModel, QdrantVectorStore, Retriever,
            KeywordRetriever, MultiRouteRetriever, RetrieverRoute,
        )

        routes = []

        # 路线 1: 向量检索（llama.cpp 本地 Embedding + PostgreSQL 存储）
        if DATABASE_URL and EMBEDDING_PROVIDER:
            try:
                embedding = EmbeddingModel(
                    provider=EMBEDDING_PROVIDER,
                    model=EMBEDDING_MODEL,
                    api_key=EMBEDDING_API_KEY,
                    base_url=EMBEDDING_BASE_URL,
                )
                from rag.pg_vector_store import PgVectorStore
                vector_store = PgVectorStore(
                    dsn=DATABASE_URL,
                    embedding=embedding,
                    score_threshold=RAG_SCORE_THRESHOLD,
                )
                vector_retriever = Retriever(
                    vector_store=vector_store,
                    top_k=RAG_TOP_K,
                    score_threshold=RAG_SCORE_THRESHOLD,
                )
                routes.append(RetrieverRoute("vector", vector_retriever, weight=1.0))
                logger.info("[RAG] 向量检索已启用: provider=%s model=%s", EMBEDDING_PROVIDER, EMBEDDING_MODEL)
            except Exception as e:
                logger.warning("[RAG] 向量检索初始化失败，跳过: %s", e)

        # 路线 2: PostgreSQL 全文搜索（从 qd_analysis_memory）
        if DATABASE_URL:
            try:
                from rag.postgres_fts import PostgresFTSRetriever
                fts_retriever = PostgresFTSRetriever(dsn=DATABASE_URL, top_k=RAG_TOP_K)
                routes.append(RetrieverRoute("fts", fts_retriever, weight=0.8))
                logger.info("[RAG] PostgreSQL FTS 已启用")
            except Exception as e:
                logger.warning("[RAG] PostgreSQL FTS 初始化失败: %s", e)

        # 路线 3: 聊天历史全文检索（PG FTS，需开启总开关）
        if CHAT_HISTORY_SEARCH_ENABLED and MEMORY_BACKEND == "postgres":
            try:
                from rag.retriever import ChatHistoryRetriever
                chat_history_retriever = ChatHistoryRetriever(
                    memory=memory,
                    top_k=RAG_TOP_K,
                    weight=0.4,  # 聊天记录权重低于知识文档，避免噪音干扰
                )
                routes.append(RetrieverRoute("chat_history", chat_history_retriever, weight=0.4))
                logger.info("[RAG] 聊天历史检索已启用 (PG FTS)")
            except Exception as e:
                logger.warning("[RAG] 聊天历史检索初始化失败: %s", e)

        # 路线 4: 关键词召回（从 qd_analysis_memory 加载历史分析）
        try:
            kw_docs = _load_analysis_memory_docs()
            if kw_docs:
                keyword_retriever = KeywordRetriever(documents=kw_docs, top_k=RAG_TOP_K)
                routes.append(RetrieverRoute("keyword", keyword_retriever, weight=0.6))
                logger.info("[RAG] 关键词召回已启用: %d 条文档", len(kw_docs))
        except Exception as e:
            logger.warning("[RAG] 关键词召回初始化失败: %s", e)

        if not routes:
            logger.warning("[RAG] 无可用检索路线，RAG 禁用")
            return None

        # 构建 Reranker
        reranker = _build_reranker()

        # 单路召回直接返回
        if len(routes) == 1 and not reranker:
            return routes[0].retriever

        # 多路召回 + RRF + 精排
        return MultiRouteRetriever(
            routes=routes,
            top_k=RAG_TOP_K,
            reranker=reranker,
            rerank_top_k=RERANK_TOP_K,
        )

    except Exception as e:
        logger.warning("[RAG] 初始化失败: %s", e)
        return None


def _load_analysis_memory_docs() -> list:
    """从 qd_analysis_memory 加载历史分析文档，供关键词召回。"""
    if not DATABASE_URL:
        return []
    conn = None
    try:
        import psycopg2
        conn = psycopg2.connect(DATABASE_URL, connect_timeout=5)
        cur = conn.cursor()
        cur.execute("""
            SELECT summary, decision, symbol, created_at
            FROM qd_analysis_memory
            WHERE summary IS NOT NULL AND summary != ''
            ORDER BY created_at DESC
            LIMIT 500
        """)
        docs = []
        for row in cur.fetchall():
            summary, decision, symbol, created_at = row
            content = f"{decision or ''} {symbol or ''} {summary}"
            docs.append({
                "content": content[:500],
                "metadata": {
                    "source": "analysis_memory",
                    "symbol": symbol or "",
                    "decision": decision or "",
                    "date": str(created_at) if created_at else "",
                },
            })
        cur.close()
        return docs
    except Exception as e:
        logger.debug("[RAG] 加载 analysis_memory 失败: %s", e)
        return []
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass


retriever = _build_retriever()

# 模式：固定 task；执行形态：固定 CodeAgent（AGENT_TYPE 仅作声明校验，2026-09-23）
# ——历史曾有 ToolCallingAgent 双形态设想，现架构仅支持 code（工具=Python 函数，
# 沙箱真 CPython 执行）。AGENT_TYPE 配其它值将在启动时告警并强制按 code 运行。
_agent_type = os.getenv("AGENT_TYPE", "code").strip().lower()
if _agent_type != "code":
    logging.getLogger(__name__).warning(
        "[启动] AGENT_TYPE=%s 不受支持，本系统仅支持 CodeAgent 形态，已按 code 运行", _agent_type)
# 工具架构：
#   - ToolProvider 统一注册（tools/ 通用 + 子目录领域工具），一次扫描两种输出（函数 + schema）
#   - 必选工具（list_tools/search_tools/format_result/web_search）→ smolagents tools=[]
#   - 领域工具 → executor.custom_tools，LLM 通过 search_tools/list_tools 动态发现
#   - 全量工具 schema → planning YAML {{tool_list}}，供 smolagents 内部 planning 选工具
_mode = "task"
logger.info(
    "QuantDinger Agent 启动: %s 模式 | %d 技能 | provider=%s model=%s",
    _mode, len(skills), LLM_PROVIDER, LLM_MODEL,
)

# ---------- 启动自检：工具可用性探测（2026-10-01）----------
# 目的：把"KEY 缺失 ⇒ 工具调不通"这件事在**启动期**说清楚并写进工具地图，
# 而不是让模型在会话中撞墙后再瞎答（web_search 全引擎无 KEY 时，模型曾因
# "prompt 要求必须联网检索"而被逼出编造结论的行为）。
from tools.availability import probe_tools

TOOL_AVAILABILITY = probe_tools()
for _name, _d in sorted(TOOL_AVAILABILITY.items()):
    if _d.get("available"):
        logger.info("[启动自检] 工具可用: %s —— %s", _name, _d.get("reason", ""))
    else:
        logger.warning("[启动自检] 工具不可用: %s —— %s（该能力本进程不可用，已写入工具地图）",
                       _name, _d.get("reason", ""))

# ---------- 启动期工具面预热（2026-10-01 补回）----------
# 旧「启动期预热（NodeContext.init_tools）」随 nodes.py 退役后，工具面扫描变成
# 懒加载：实测冷路径 3.1s（import 76 个工具模块 + 能力层注册）压在**首条用户消息**
# 上——用户等的是这一条，不是启动日志。此处在装配期跑一次 `warmup_tool_face()`，
# 复刻旧系统「启动时筛一次、消息路径不扫」；预热失败不阻断（fail-open，退化回懒加载）。
from qd_agent import warmup_tool_face as _warmup_tool_face
_WARMUP = _warmup_tool_face()
if not _WARMUP.get("done"):
    logging.getLogger(__name__).warning(
        "[启动] 工具面未预热成功（%s），首条消息将懒加载", _WARMUP.get("error", "未知"))

# ---------- Agent 实例（mimoagent 执行核，2026-09-30 一步到位） ----------
# 旧 TaskAgent/graph/nodes/llm 适配层已退役；对外契约不变（chat/run_agent）。
# 技能读取/记忆/RAG 均已工具化（tools/skill_tools、memory_tools、knowledge）；
# 记忆近史 + RAG 命中由 QDAgentService 自动预取（体验与旧注入管线等价）。
agent = QDAgentService(
    memory=memory,
    retriever=retriever,
    skills=skills,
    agent_config={
        "step_limit": MAX_TOOL_ROUNDS,
        # 服务级可用性事实（工具地图会照此标注，避免模型调用必失败的服务）
        "service_availability": {"search_knowledge": retriever is not None},
    },
)

# 注：旧「启动期预热（NodeContext.init_tools）」已随 nodes.py 退役；
# 工具注册改由 QDAgent._build_tool_registry 在会话首建时一次性完成（同样有进程内缓存）。




def run_agent(message: str, session_id: str = "default", timeout: int = 300) -> str:
    """统一同步入口：Flask / CLI / Cron 等所有调用方都走这里。

    内部处理事件循环 + LLM 客户端重置，调用方无需关心 async 细节。

    Args:
        message: 用户消息
        session_id: 会话 ID
        timeout: 超时秒数，0 表示不超时
    """
    import asyncio
    loop = asyncio.new_event_loop()
    try:
        coro = agent.chat(message, session_id=session_id)
        if timeout > 0:
            resp = loop.run_until_complete(asyncio.wait_for(coro, timeout=timeout))
        else:
            resp = loop.run_until_complete(coro)
        return resp.content or ""
    finally:
        # 不再 close 共享 LLM 客户端（审计 P0-3）：全局唯一 OpenAILLM 的 AsyncOpenAI
        # 客户端绑定创建它的 event loop，任务级 close/复用会造成跨 loop 竞态与并发误杀。
        # 连接池随进程存活，进程退出由 OS 回收；v1.3 记录的 "Event loop is closed"
        # 其根源正是跨 loop 复用 + 任务级 close 的组合，close 只会加重而非解决。
        loop.close()


# ---------- 盘后回溯评估 Worker ----------
try:
    # 2026-09-14：worker 只能有一个——此前 `chain.evaluator` 与 `app.agent.chain.evaluator`
    # 是**两个模块实例**（sys.path 双路径导入 + 裸名/全名混用），
    # 各自的 `_eval_thread` 互不可见 ⇒ `is_alive()` 防重入失效 ⇒ 同进程双 worker、
    # 日志双份、每次盘后评估跑两遍。
    # 2026-10-02：根治办法是**只保留一种导入口径**（现统一裸名），不是"选哪个名字"——
    # 只要两种写法并存，换哪个名字都会再长出第二份。护栏：qd_smoke.py::test_29。
    from chain.evaluator import start_eval_worker
    start_eval_worker()
    logger.info("盘后回溯评估 worker 已启动")
except Exception as e:
    logger.warning("eval worker 启动失败: %s", e)
