# chain/ 目录代码审查报告

- 审查日期:2026-10-13
- 范围:`QuantDinger/backend_api_python/app/agent/chain/` 全部 .py 文件
- 声明:只读审查,未修改任何项目文件;结论均基于实际读到的代码,不确定处标注「待确认」

## 一、审查覆盖清单

> 注:任务描述为「25 个 .py 文件」,实际盘点为 **22 个 .py**(无子目录),共 **8015 行**。全部逐行审毕。

| # | 文件 | 行数 | 已审 |
|---|------|-----|------|
| 1 | `__init__.py` | 27 | ✅ |
| 2 | `account_store.py` | 348 | ✅ |
| 3 | `aggregator.py` | 260 | ✅ |
| 4 | `c3p.py` | 398 | ✅ |
| 5 | `calibration.py` | 206 | ✅ |
| 6 | `claims.py` | 407 | ✅ |
| 7 | `collector.py` | 175 | ✅ |
| 8 | `context_frame.py` | 396 | ✅ |
| 9 | `evaluator.py` | 1121 | ✅ |
| 10 | `evidence.py` | 253 | ✅ |
| 11 | `intake.py` | 102 | ✅ |
| 12 | `judge_stats.py` | 118 | ✅ |
| 13 | `kline_feed.py` | 144 | ✅ |
| 14 | `label_spec.py` | 136 | ✅ |
| 15 | `reset.py` | 168 | ✅ |
| 16 | `resolver.py` | 538 | ✅ |
| 17 | `sampler.py` | 295 | ✅ |
| 18 | `schema.py` | 431 | ✅ |
| 19 | `skill_brewer.py` | 702 | ✅ |
| 20 | `store.py` | 1388 | ✅ |
| 21 | `weight_feed.py` | 240 | ✅ |
| 22 | `weight_hints.py` | 162 | ✅ |

**问题统计:高 3 / 中 17 / 低 18,合计 38 条。**

---

## 二、高严重程度(逻辑错误 / 数据破坏 / 假数据入口)(3 条)

### H1. reset.py:94-99 | 逻辑错误·数据超范围销毁
**问题**:`reset_accountability(limit_days=N)` 的文档语义是「>0 只清最近 N 天」,但时间窗过滤只作用于 `qd_agent_decisions`;`qd_agent_claims` / `qd_agent_resolutions` 走 `else` 分支**全表 DELETE**。带 limit_days 执行时会把窗口外历史 claim/resolution 一并销毁,只留 decisions 孤行(claim_count 汇总失真)。
**证据**:
```python
if limit_days and t == "qd_agent_decisions":
    cur.execute("DELETE FROM qd_agent_decisions WHERE created_at > NOW() - ...")
else:
    cur.execute(f"DELETE FROM {t}")   # claims/resolutions 不分窗口,全删
```
**修复方向**:窗口过滤统一作用于三表(claims/resolutions 经 `decision_id → created_at` 联级过滤),或在参数层面把 `limit_days` 与全表清空拆成两个互斥操作并显式校验。根因是「按表循环 + 单表特判」的写法让过滤条件与表的耦合关系隐式化。

### H2. resolver.py:370-372 + account_store.py:176-182 | 逻辑错误·死分支(防幸存者偏差机制失效)
**问题**:退市/长期停牌的「按最差路径计入」(v4 G18)判据 `_fail_n = claim.get("verify_fail_count")` **恒为 0** —— `query_due_claims` 的 SELECT 列表里根本没有 `verify_fail_count` 列,`_fail_n >= _max_retry`(0 ≥ 5)永假,`verdict="delisted"` 分支不可达。G18 修复实际从未生效,幸存者偏差依旧。
**证据**:
```python
# account_store.query_due_claims 的 SELECT(c176 起):
"SELECT c.id, c.decision_id, c.claim_type, c.subject, c.subject_kind, c.horizon, ..."
# ——无 verify_fail_count
# resolver._resolve_finance:
_fail_n = int(claim.get("verify_fail_count") or 0)     # 恒 0
if _fail_n >= _max_retry and _last_kline:               # 永假
```
**修复方向**:取数层与判定层的字段契约脱节 —— 在 `query_due_claims` 补出 `c.verify_fail_count`,或把 delisted 判据下移到 SQL(重试耗尽的行直接带标记返回)。禁止在 resolver 侧再查一次库打补丁。

### H3. intake.py:94 + account_store.py:120-146 + c3p.py:332 | 逻辑错误·claim_id 与 claim 错位配对(假数据)
**问题**:`save_claims` 逐条 INSERT 且中途异常时返回**部分** id 列表;`intake.record_decision` 仍返回全量 `claims` 与部分 `claim_ids`;c3p 按下标 `zip(ids, cl)` 对齐 —— 一旦部分写入失败,claim_id 与 claim 内容张冠李戴,Δp 配对(p_base/condition_key/horizon)记到错误的 claim 上,正是各模块反复强调的「假数据」。
**证据**:
```python
# account_store.save_claims:循环中途 except → return ids(不完整)
ids.append(int(row["id"])) ...
# intake.record_decision:
out.update({"claim_ids": ids, "claims": list(extracted or [])})   # 长度可能不一致
# c3p.run_for_decision:
for cid, c in list(zip(ids, cl))[:max_claims()]:   # 隐式下标契约,无长度校验
```
**修复方向**:根因是「两个平行列表靠下标对齐」的隐式契约 —— `save_claims` 应整体单事务(全成或全空),或直接返回 `[{id, claim}, ...]` 成对结构,消灭 zip。顺带:c3p 应在长度不一致时拒绝处理而不是静默 zip 截断。

---

## 三、中严重程度(17 条)

### M1. schema.py:296 | 逻辑错误·数值
`to_skill_report` 中 `score=self.score or 50.0`:score=0(合法的极低分)被 `or` 当成缺失,静默抬成 50 中性分。
**证据**:`score=self.score or 50.0,`
**修复方向**:`score=self.score if self.score is not None else 50.0`(根因:用真值判断代替 None 判断)。

### M2. schema.py:424-430 | 逻辑错误·语义与文档不符,跨函数口径分叉
`is_direction_correct` docstring 说 `wrong` 只表示「方向相反(bullish→bearish 或 bearish→bullish)」,但代码里 predicted=bullish、actual=neutral(横盘)也返回 `"wrong"` → evaluator 按 `correct=False` 计罚;而 resolver.`verdict_by_rule` 对同一情形给 `partial/noise(0.5)`。同一对(预测,实际)在两条链路一个重罚、一个轻放。
**证据**:`if predicted == actual: return "correct"` / `return "wrong"`(actual=neutral 落入此分支)
**修复方向**:统一三值语义(建议 predicted≠neutral 且 actual=neutral → 独立结果如 `"flat"`,由消费方决定计分),让 evaluator 与 resolver 复用同一函数而不是各自解释。

### M3. evaluator.py:81,291,931 | 冗余·死参数
`_get_actual_return` 的 `market` 参数(及 `evaluate_pending`/`auto_evaluate` 一路透传)在函数体内**零引用**,数据源固定 `CNStockDataSource`。调用方误以为可换市场。
**证据**:`def _get_actual_return(..., market: str = "CNStock", ...)`(体内无 market 引用)
**修复方向**:删参,或按 market 真正分派数据源。三处签名同改,不要留「传了也没用」的参数。

### M4. evaluator.py:161 | 健壮性
K 线规整 `round(k.get("open", 0), 2)`:字段存在但值为 `None` 时 `round(None)` 抛 TypeError,被外层 except 吞掉后**整次取数返回 None** → 一条 eval_failed 计数(5 次后被毒丸永久出队),而根因只是某根 K 线缺 open 字段。
**证据**:`"o": round(k.get("open", 0), 2),`
**修复方向**:`k.get("open") or 0` 并对关键字段(c)缺失整行丢弃;与 kline_feed 的容错口径对齐(同一个数据源两套解析,见 L8)。

### M5. evaluator.py:229-233 | 逻辑错误·缺失值填 0
`with_extremes` 的窗口极值 `float(k.get("h") or 0)`:h/l 缺失被填 0,`max(highs)` 可能算出 `high=0.0` 写入 actual;level claim 的 `touched = lo <= price <= hi` 会被 0 污染(价格恒 >0 时 hi=0 直接判 miss)。与 context_frame「取不到就是 None,绝不填 0」的红线冲突。
**证据**:`highs = [float(k.get("h") or 0) for k in seg ...]`
**修复方向**:缺 h/l 的行从 seg 剔除;全缺时 high/low 置 None,让 `touched` 走 `undecidable` 而不是错判。

### M6. c3p.py:368 | 死代码/冗余
`"degrade_reason": ("" if degraded else "")` —— 两个分支都是空串,降级原因**从不记录**。G20 监控想区分「无 falsifiers / LLM 超时 / JSON 非法」没有依据。
**证据**:`"degrade_reason": ("" if degraded else ""),`
**修复方向**:在各降级点(evidence 为 None / 无 falsifiers / 落盘失败)填真实原因,或删掉这个永远为空的字段。

### M7. c3p.py:195 | 健壮性·假数据入口
`p_base_of` 不校验有限值与 [0,1] 区间:`float(p) if isinstance(p, (int,float))` 会把 NaN 原样返回。NaN 绕过 `if pb is None: continue`,`aggregate` 对 NaN p_base fail-open(p_final=None),但 c3p 仍 `pf = pb`(NaN)并 `record_pair` 落盘 —— 产出 `p_base=None/p_final=None 但 delta_p=0.0` 的垃圾配对。
**证据**:`return float(p) if isinstance(p, (int, float)) else None`
**修复方向**:返回前校验 `math.isfinite(p) and 0 <= p <= 1`,不满足返回 None(走「不记 pair」路径)。

### M8. c3p.py:357 | 逻辑错误·字段语义自相矛盾
`out["condition_key"] = ck` 在循环里被逐条覆盖,最终留存的是**最后一条** claim 的键;而 evidence 是按 `works[0]`(第一条 claim)抽取的。返回值里 evidence 与 condition_key 可能来自不同 claim。
**证据**:`for cid, c, code in works: ck = ...; out["condition_key"] = ck`
**修复方向**:明确「一次决策一个证据、一个条件键」(取 works[0],循环里不覆盖),或返回逐 claim 明细。根因是单值字段装多值数据。

### M9. account_store.py:342-345 | 逻辑错误·统计口径不一致
`stats()` 中 `by_verdict`(resolutions)与 `by_domain`(decisions)不带 `limit_days` 时间窗,而 decisions/claims 两个计数带 30 天窗 —— 该函数注释刚修过 claims 的同款问题,这两处漏了。健康度报表自相矛盾(窗口内 0 条决策,by_domain 却有全量历史)。
**证据**:`cur.execute("SELECT verdict, count(*) ... FROM qd_agent_resolutions GROUP BY verdict")`(无窗口)
**修复方向**:三个分布查询统一带窗口(resolutions/decisions 经 created_at 联级),或函数文档明确「分布是全量口径」。

### M10. reset.py:24 / judge_stats.py:24 / skill_brewer.py:34 / weight_feed.py:25 / weight_hints.py:27 | 健壮性·日志口径分裂
这 5 个文件用 `logging.getLogger(__name__)`(`judge_stats`/`reset` 甚至是 `__import__("logging")`),其余 12 个文件用 `..log.logger`。若 app 日志管道只挂在 `..log` 上,这 5 个模块的 warning/error 不进统一日志(fail-open 的旁路模块恰恰最需要留痕)。
**证据**:`logger = __import__("logging").getLogger(__name__)`
**修复方向**:统一 `from ..log import logger`。

### M11. skill_brewer.py:503,568-570 | 逻辑错误·修订护栏静默失效
`revise_skill` 用 `re.search(r"from root_id=(\d+)")` 解析溯源 root_id,但修订后头部写的是 `origin_root_id={origin}`(c570)——**第二次修订起匹配不到**,`since_id=None`,`get_delta_digest` 退回全量历史(正是审计 A4 刚修掉的「重复强化/漂移」);溯源 origin 也退化成 "?"。
**证据**:首酿头 `from root_id=`(c434)→ 修订头 `origin_root_id=`(c570)→ 读取 `from root_id=(\d+)`(c503)
**修复方向**:统一溯源标记契约(首酿/修订共用一个正则可解析的键),或读取侧同时匹配两种并以 `origin_root_id` 优先。根因:两套 header 格式、一个解析器。

### M12. weight_feed.py:206-212 | 逻辑错误·「只记账」没记账
`feed()` 样本不足分支只发 UPDATE 不 INSERT:新域首见且 n<MIN_SAMPLES 时 `qd_agent_weights` 无对应行,UPDATE 命中 0 行 —— 返回值却写「只记账」,实际什么都没记;攒够 5 条之前样本数无处可查。
**证据**:`if n < MIN_SAMPLES: cur.execute("UPDATE qd_agent_weights SET sample_count=... WHERE layer='domain' AND name=%s")`
**修复方向**:记账与调权共用同一个 upsert(INSERT ... ON CONFLICT DO UPDATE),只在 `weight` 是否更新上分支。

### M13. store.py:962-974(query_brew_ready)/ query_brew_candidates | 逻辑错误·归一只做了一半
两个查询先按**原始**链名 GROUP BY + HAVING + LIMIT,之后才 `_merge_chain_rows` 归一合并:实体码链(stock+analyze+600929)在 SQL 里各自不足 `min_runs`/胜率门槛的,合并后达标也进不来;LIMIT 先行还会让名额被同名族占满,合并后候选数 < limit 且信号排序失真。
**证据**:SQL `GROUP BY t.name ... LIMIT %s` → 之后 `rows = _merge_chain_rows(rows)`
**修复方向**:归一下沉到 SQL(`store._sql_chain_norm` 已存在,evaluator ⑦ 段在用),或去掉 SQL LIMIT 全量归一后再过滤/截断。两处(ready/candidates)同改。

### M14. context_frame.py:67-75 / sampler.py:44-50 | 健壮性·导入期崩溃 + 双轨读 env
模块导入期 `float(os.getenv("QD_CF_VOL_LOW","0.12"))`、`int(os.getenv("QD_SAMPLE_HOT_RANK_N","300"))` 等无容错:env 脏值在 **import 时**抛 ValueError,炸掉整个 chain 包(与 c3p「脏值回落默认,不崩」的承诺相反);且同文件 `_env_f`/`_ratio_hot` 运行期又读一遍同名 env,两套读取路径行为不一。
**证据**:`_VOL_LOW = float(os.getenv("QD_CF_VOL_LOW", "0.12"))` / `_KLINE_DAYS = int(os.getenv("QD_CF_KLINE_DAYS", "30"))`
**修复方向**:全部改运行期读取 + 容错回落(与 c3p 的 `_env_*` 同款),删掉模块常量那份(见 L6 统一后只需一处)。

### M15. evidence.py:92 | 冗余·死参数
`condition_key(subject, frame)` 的 `subject` 参数**完全未参与**计算(只用 frame 的 regime/vol_bucket);c3p 按 `condition_key(code, frame)` 调用,签名暗示「键含标的」而实际不含。
**证据**:`def condition_key(subject: Optional[str], frame: ...)`(体内无 subject 引用)
**修复方向**:删参数,或真正纳入键(后者会扩条件空间,需先过 cell budget)。

### M16. evidence.py:70-81 | 逻辑错误·条件空间漏算 unknown(待确认)
`cell_count()` 按 `_DIM_CARD` 乘积算 9 格(默认两维),但 `condition_key` 取不到值时每维还有 `unknown` 一档 —— 真实取值是每维 4 个,两维实际 16 格 > 预算 12,`assert_cell_budget` 漏报。docstring「含 unknown 兜底 +1 维?不含 —— 见下」中的「见下」没有任何下文,作者自己也没定论。
**证据**:`parts.append(str(v) if v else "unknown")` vs `_DIM_CARD = {"regime": 3, "vol_bucket": 3, ...}`
**修复方向**:cell_count 按「每维基数 + 1(unknown)」计算,或把 unknown 收敛为独立的"未入池"通道不进条件格。**待确认**:unknown 格是否被有意排除在拟合之外。

### M17. evaluator.py:528 | 冗余
`info = adapter.get(name)` 赋值后零引用(注释自述 SkillInfo 无 default_weight);且 `adapter.list_skills()` 在 ① 与 ①b 两处重复调用同一接口。
**证据**:`info = adapter.get(name)` / 下一行 `default_w = 1.0`
**修复方向**:删死变量;list_skills 取一次复用。

---

## 四、低严重程度(18 条)

### L1. `__init__.py:8` | 死引用·文档漂移
docstring 把 `chains.py — 链路定义` 列为核心模块,但全仓不存在 `chains.py`(grep 零命中);「已删除」清单(tool_chains/contract)也已过期。修复:更新模块地图。

### L2. store.py:1070-1115(query_low_weight_tools)/ 758(query_cached_tools)| 死代码
`query_low_weight_tools` 注释自认「死代码实锤……统一清理阶段连同导出项删除」,全仓零生产调用方(仅 `__init__` 导出);`query_cached_tools` 同样仅 `__init__` 导出、零调用,且注释自认与 skill_brewer 双轨待二选一。修复:连同 `__init__` 导出项删除或降级 debug 开关(注释里的计划,一直没执行)。

### L3. store.py load_tree / query_roots | 死代码
全仓无调用方(`_row_to_node` 注释自认「load_tree 暂无调用方」),仅 `__init__` 导出。若为将来的接口预留请标注,否则删除。

### L4. context_frame.py:61 | 死代码
`REQUIRED_FIELDS` 常量全仓零引用(包括本文件)。修复:删除或在 build_frame 里真正用它做缺字段校验。

### L5. aggregator.py:198/213、collector.py:64/79、evidence.py:211/226、context_frame.py:354/383 | 同功能重复实现 + 健壮性
四份同构的「JSONL 读 → 过滤 → 整文件重写」(record_pair/_append_universe/append_evidence/append_frame):语义都是「同 key 覆盖、按月分文件」。且写入非原子(无 tmp+rename)、无锁,两个进程(盘后 worker + 手动补跑)同时写会互相覆盖丢行 —— C 类数据恰恰强调「不可重建」。
**修复方向**:统一 `chain/jsonl_store.py`(append_or_replace + 原子替换 + 文件锁),四个模块只传 key/排序函数。这也是仓库约定「重复 2 处以上生成统一接口」的直接适用场景。

### L6. c3p.py:96 / calibration.py:49 / collector.py:42 / kline_feed.py:37 / app/utils/db_postgres.py:38(_env_int)+ claims.py:117 / resolver.py:47(_env_flag)| 同功能重复实现
`_env_int` 五份、`_env_flag` 两份,且**语义不一致**:collector 版允许 0/负数,其余版要求 >0(`QD_COLLECT_N=0` 会得到空 universe 静默成功)。修复:收敛到一个 `utils/env.py`,把「是否允许 0」做成显式参数。

### L7. 阈值/口径多处复制 | 同功能重复实现
- `resolver._FLAT_PCT = 0.3`(%) 与 `schema.DIRECTION_THRESHOLD = 0.003` 同义两份(注释自认「同口径」却各存一份,单位换算靠人肉);
- `claims.due_date_of` 与 `evaluator._maturity_days` 各写一份 `int(days*1.5)+2` 自然日估算;
- `evidence._P_KEYS` 与 `aggregator._P_KEYS` 整表复制(R1 黑名单双份,「纵深防御」应引用同一常量,否则加一个概率字段名要改两处)。
**修复方向**:全部指向单一常量源(label_spec 已是好样板)。

### L8. 跨目录重复:SkillReport/FactorItem + 三套 K 线取数 | 同功能重复实现
- `skills/market_screener/common.py:50` 的 `SkillReport`/`FactorItem` 与 `chain/schema.py` 逐字段相同(两份 to_dict/from_dict);
- K 线取数三套:`evaluator._get_actual_return` 内联 CNStockDataSource、`kline_feed.daily_bars`、`market_screener.common.fetch_kline` —— kline_feed 模块头自述「3 处重复⇒统一接口」,但 evaluator 并未切换,kline_feed 目前只服务 c3p;且 market_screener 版做了前复权(`unadj_to_qfq`)、evaluator/kline_feed 版未见复权处理,**待确认**:除权日附近的 T+N 收益是否被口径差异污染。
**修复方向**:kline_feed 真正接管 evaluator 的取数(它已同时输出 t/time 两种键,正是为此设计);SkillReport 统一从 chain.schema 导入。

### L9. aggregator.py:213-252 | 健壮性·并发 + 口径不一致
`record_pair` 整文件读改写(非原子、无锁),与 L5 同类;`delta_p` 用 `_as_float(p, default=0.0)` 而 `p_base/p_final` 字段用 `default=None` —— 非数字值时 `p_base=None 但 delta_p=0.0` 自相矛盾。修复:并入统一 jsonl_store;两处 _as_float 用同一 default。

### L10. account_store.py:157-162 | 待确认·语义
`refresh_decision_summary`:claims 全部 unresolvable 时 `pending=0` → `resolve_status='resolved'` —— 与「resolved=已定论」语义不符。待确认是否应单列 'unresolvable'。

### L11. account_store.py:196 | 待确认·边界
视界门 `due_td <= day`:第 N 个交易日**当天**即视为走完。盘后 worker(15:30,数据已同步)场景无害,但白天手动触发会拿到未收盘窗口。修复方向:`due_td < day` 或要求时点 > 收盘时刻。

### L12. weight_hints.py:42-48 | 冗余·死分支
`_threshold()` 的 except ImportError 里重复执行**同一个 import**,失败一次必然再失败,内层 try 是无效重试。修复:直接 `except ImportError: return 0.7`。

### L13. weight_hints.py:126-128 | 逻辑·展示误导
`hint_text` 把 domain 的 **weight**(EMA 值,初值 1.0)当「命中率」以百分比展示:`f"{v:.0%}"` ⇒ 冷启动期恒显示「命中率 100%」。修复:展示 `win_rate` 列或改文案为「权重」。

### L14. judge_stats.py:24 / reset.py:24 | 风格
`logger = __import__("logging").getLogger(__name__)` 写法晦涩(与 M10 同源,统一后自然消失)。

### L15. sampler.py:168-176,262-266 | 冗余 + 契约不符
- 返回 items 缺 docstring 承诺的 `"source"` 字段;
- `pools["cold"]` 的二次过滤(剔除 hot/warm)与前一步 `seen` 去重逻辑**完全重复**(seen 在处理 cold 时已含 hot+warm),是死代码。

### L16. store.py:123-126 | 冗余
`_save_node` 根节点 INSERT 后又单独 `UPDATE ... SET root_id` 一次多余往返;可用 INSERT 时自引用/两步参数消除。

### L17. intake.py:24 / weight_hints.py:52 | 线程安全(轻)
`_POLICY_CACHE`、`_cache` 无锁共享 dict;CPython 下单键赋值原子尚可,但 `_cache.update(got)` 多键更新可被并发读到半新半旧。低危,建议换单键快照对象。

### L18. c3p.py:221-227 / resolver.py:310 | 重复实现(轻)
c3p `_json_obj` 在 `utils.json_parser` 之外仍自留 `re.search(r"\{.*\}")` 兜底,resolver.judge_one 又内联一份同款 JSON 抽取 —— 三处 JSON 抽取路径。可并入 utils.json_parser。

---

## 五、整体评价

**架构层面做得好的地方**(先说清,避免误伤):
- `label_spec.py` 的「唯一真源」收口、`account_store` 的 fail-open 铁律、`aggregator` 的 R1/R2 红线与「无系数不出 β」纪律、`sampler` 的确定性随机与「缺额不重新分配」,都是高质量的工程决策,且大多有测试守卫(tests/test_v5_*)。
- 模块头普遍写明「为什么存在/易错处/红线」,审查效率因此很高。

**结构性问题**(按影响排序):

1. **「JSONL 文件当数据库」的模式被复制了 4 份**(L5/L9):collector/context_frame/evidence/aggregator 各自实现整读-过滤-整写的覆盖式落盘,全部非原子、无锁。这是当前最大的系统性风险 —— 盘后 worker、手动补跑、c3p 收尾钩子可能并发写同一批文件,而这些数据(情境帧、配对样本)的卖点恰是「不可重建」。应立即统一成一个带原子替换的 jsonl_store,而不是继续复制。

2. **取数层与消费层的字段契约靠「约定」不靠「结构」**:H2(query 少查一列 → delisted 死分支)、H3(两个列表下标对齐 → 错位配对)、M3(market 参数传了没人用)是同一类病 —— 函数间传递裸 dict/平行列表,缺字段、错位都静默。修复时应把「claim + id 成对返回」「SQL SELECT 列与消费字段同源定义」做实,而非补列补校验。

3. **同义常量/同名工具函数多处分裂**:`_env_int`×5(语义还不一致)、`_env_flag`×2、`_P_KEYS`×2、`_FLAT_PCT` vs `DIRECTION_THRESHOLD`、自然日估算×2、SkillReport×2、K 线取数×3。项目自己的约定是「重复 2 处以上⇒统一接口」,label_spec 已示范正确做法,其余同类应收敛。注意 evaluator/kline_feed 两套 K 线解析对 None 字段的行为已经分叉(M4/M5 正是分叉的产物)。

4. **死代码存量未清**:`query_low_weight_tools`、`query_cached_tools`、`load_tree`、`query_roots`、`REQUIRED_FIELDS`、`__init__` 的 chains.py 幽灵引用 —— 其中两个是注释里白纸黑字「待删除」挂了一个月以上的。死代码与在用代码同层摆放,是 `update_path_cache` 那类「引用了不存在的函数」事故的温床(该事故已由 evaluator 注释记录)。

5. **统计/观测口径漂移**:stats() 窗口不一致(M9)、judge 观测的「只在非 undecidable 时调 judge」与模块头「语义模糊才请 LLM」的设计声明相反(待确认是否有意)、weight_hints 把权重当命中率展示(L13) —— 观测层的口径错会误导后续决策(这正是本项目反复吃亏的「静默漂移」)。

**总体**:22 个文件的单模块质量普遍不低,注释与守卫测试意识强;但**横向收敛**欠账明显 —— 重复实现(4 份 JSONL、5 份 env 解析、3 份 K 线取数)和**跨层契约**(SQL 列 ↔ 判定字段、下标对齐)是当前缺陷的两大来源。建议下一个迭代只做两件事:① 统一 jsonl_store + env 工具;② 把 H1/H2/H3 的契约类缺陷改为结构性修复(而非补丁),并顺手清掉 L2-L4 的死代码。
