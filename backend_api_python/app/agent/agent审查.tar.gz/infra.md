# infra 组代码审查报告（memory / rag / resolvers / utils / skills）

- 审查日期：2026-10-13
- 审查方式：只读通读 + 全仓 grep 引用判定（未执行任何 git 命令、未改动项目文件）
- 范围：`QuantDinger/backend_api_python/app/agent/` 下 memory/ rag/ resolvers/ utils/ skills/(market_screener、strategy_debug)

---

## 一、审查覆盖清单

| 文件 | 行数 | 已审 |
|---|---|---|
| memory/__init__.py | 11 | ✅ |
| memory/base.py | 58 | ✅ |
| memory/local_memory.py | 55 | ✅ |
| memory/postgres_memory.py | 431 | ✅ |
| memory/redis_memory.py | 117 | ✅ |
| rag/__init__.py | 28 | ✅ |
| rag/embeddings.py | 186 | ✅ |
| rag/pg_vector_store.py | 161 | ✅ |
| rag/postgres_fts.py | 150 | ✅ |
| rag/retriever.py | 516 | ✅ |
| rag/vector_store.py | 188 | ✅ |
| resolvers/__init__.py | 5 | ✅ |
| resolvers/base.py | 55 | ✅ |
| resolvers/bridge.py | 152 | ✅ |
| resolvers/composite.py | 102 | ✅ |
| resolvers/stock.py | 227 | ✅ |
| resolvers/time.py | 427 | ✅ |
| utils/__init__.py | 33 | ✅ |
| utils/budget.py | 213 | ✅ |
| utils/calibration.py | 179 | ✅ |
| utils/case_memory.py | 621 | ✅ |
| utils/grounding.py | 279 | ✅ |
| utils/json_parser.py | 213 | ✅ |
| utils/logger.py | 42 | ✅ |
| utils/mask.py | 46 | ✅ |
| utils/md_format.py | 168 | ✅ |
| utils/prescan.py | 232 | ✅ |
| utils/tracing.py | 774 | ✅ |
| skills/market_screener/__init__.py | 1 | ✅ |
| skills/market_screener/_facts.py | 696 | ✅ |
| skills/market_screener/_helpers.py | 685 | ✅ |
| skills/market_screener/common.py | 780 | ✅ |
| skills/market_screener/run.py | 586 | ✅ |
| skills/strategy_debug/__init__.py | 2 | ✅ |
| skills/strategy_debug/run.py | 137 | ✅ |

**合计 35 个文件、8556 行，100% 覆盖。** 按任务分工，`skills/base.py`（92 行）、`skills/skills_adapter.py` 与 `skills/__init__.py`（16 行，顺带读过）归 core 组，不计入本清单。

---

## 二、高严重度

### H1. rag/pg_vector_store.py:125-131 | 健壮性/安全 | `filter` 的键直接拼进 SQL，构成注入面
- 证据：`conditions.append(f"metadata->>'{key}' = %s")`
- 问题：`similarity_search(query, filter)` 的 filter key 未做白名单/标识符校验，直接 f-string 拼接进 SQL。`Retriever.retrieve(filter=...)` 一路透传，任何上游把用户可控字符串当作 filter key（如从 LLM 输出解析出的过滤条件）即可闭合引号注入任意 SQL。值虽然走 `%s`，键没有。`self.table` 同样以 f-string 拼接（57/66/95/123 行），配置级可控时同理。
- 修复方向（根因）：SQL 结构与数据分离——key 走 `psycopg2.sql.Identifier`/白名单枚举，表名在构造期校验 `^[A-Za-z_][A-Za-z0-9_]*$` 后缓存为 `sql.Identifier`；不要在调用期拼字符串。

### H2. rag/embeddings.py:99 + rag/pg_vector_store.py:91 + rag/vector_store.py:119 | 逻辑错误 | `embed_documents` 过滤空文本导致文本/向量 zip 错位
- 证据：`valid_texts = [t.strip()[:4096] for t in texts if t and t.strip()]`；下游 `for idx, (text, vector) in enumerate(zip(texts, vectors))`
- 问题：`DashScopeEmbedding.embed_documents` 丢弃空白文本后返回的向量数少于入参 `texts`，而 `PgVectorStore.add_texts` / `QdrantVectorStore.add_texts` 仍按 `zip(texts, vectors)` 对齐入库——只要批次中有 1 条空/空白文本，其后所有文档都会存进**上一条文档的向量**，RAG 检索结果与内容静默错配。`OpenAIEmbedding.embed_documents` 又不过滤空文本，两个 provider 行为不一致，问题只在 dashscope 路径暴露。
- 修复方向（根因）：embed_documents 的返回必须与输入一一对应（空文本返回零向量占位或抛出明确异常），或者由调用方先过滤再整体传入；禁止"过滤后返回"这种破坏长度契约的语义。

### H3. resolvers/time.py:237-265 | 逻辑错误 | 时间词重叠匹配 + 插入点取 `m.end(1)`，内联标注插进词中间、重叠双标注
- 证据：`_word_end = m.end(1) + (len(_stem) if _stem else 0) if m.groups() else m.end()`；`weekday_rel` 的 pattern 是 `([上本下])个?(?:星期|周)([一二三四五六日天])`
- 问题（两个叠加）：
  1. `weekday_rel` 的 group(1) 只是「上/本/下」单字，`m.end(1)` 落在「上」之后 → "上周三" 被标成 `上(2026-10-07)周三`；
  2. `seen` 只按 kind 去重，不按 span 去重。"上周三行情" 同时命中 `weekday_rel`、`week_rel`（"上周"）、`weekday_abs`（"周三"）三个 pattern，三段 edit 重叠、逐个插入 → 产出 `上(d1)(range)周三` 类碎句，直接污染送给执行链的 effective_input。
  另注：`days_after` 词干表写死 `"天后"`，遇到 "3天之后" 时 `+len(stem)` 同样错位（插成 `3天之(date)后`）。
- 修复方向（根因）：内联锚点应取**整个匹配**（`m.end()`）而非 group(1)；edits 在生成阶段做 span 去重（重叠时保留最长匹配），区间词干改从 match 文本本身取尾缀而不是查 `_RANGE_STEMS` 长度。加一条 "上周三/3天之后/下周" 的单测锁住。

### H4. market_screener/run.py:313-333、465-477 + _helpers.py:491-501、562-568 | 健壮性 | `as_completed(timeout=…)` / `ex.map(timeout=…)` 的超时是假的
- 证据：`with ThreadPoolExecutor(max_workers=...) as ex: for fut in as_completed(futs, timeout=...)` ；外层 `except Exception: missing.append(f"并发分析中断: …")`
- 问题：`with` 退出时 `Executor.shutdown(wait=True)` 会**等全部线程结束**。超时异常抛出后，真正挂死的外部源（注释明说"龙虎榜/板块/资金偶发挂起，不能拖死整轮选股"）依旧把调用线程钉死，`_INSPECT_DEADLINE_S=15` 与 `_FETCH_TIMEOUT_S=20` 形同虚设；而 missing 里"未在时限内返回"的记录在挂起恢复后还会迟到写入。`profile_candidates` 的 fallback 串行路径（`for c in pool: _fetch(c)`）更无任何时限。
- 修复方向（根因）：并发模型与超时契约要一致——要么 `shutdown(wait=False, cancel_futures=True)` + 不回收挂起线程（daemon 线程池/独立进程隔离外部 IO），要么给底层 fetch（HTTP/DB）自身设超时。补丁式"再包一层计时线程"不解决问题。

### H5. utils/tracing.py:535-541 | 逻辑错误/静默丢数据 | `finish()` 在 success 但 `final_answer` 为空时**什么都不落库**
- 证据：
  ```python
  if status == "success":
      if final_answer:
          self._finished_root_id = self._write_qd_agent_traces(final_answer)
  else:
      err = str((response or {}).get("error") or "")
      self._finished_root_id = self._write_qd_agent_traces(final_answer or "", status="failed", error=err)
  ```
- 问题：`if final_answer:` 没有 else。成功 run 拿到空 final_answer（LLM 空回复/被截断）→ `qd_agent_traces` 一条都不写、返回 None、无任何日志——A6 审计"错误 run 也留痕"的意图只覆盖了 status="error" 分支，success-空答案成了新的排查黑洞。
- 修复方向（根因）：落库条件按"run 是否发生"而不是"答案文本是否非空"；空答案应落 `status='failed', error='empty_final_answer'` 一行留痕，或至少 warning。

---

## 三、中严重度

### M1. memory/redis_memory.py（全文件 117 行）| 死代码 | 三后端之一完全未接线
- 证据：全仓 grep `RedisMemory|redis_memory` 仅命中自身与 `memory/__init__.py` 的导出；`agent.py:75-84` 的选型只有 `postgres` / 其余一律 `LocalMemory`，无 redis 分支
- 问题：`RedisMemory` 被 __init__ 导出、local_memory.py 注释还宣称"生产环境请使用 RedisMemory"，但工厂从不创建它；其 `ttl_seconds/redis_prefix/max_history` 兼容参数也随之无人使用。误导运维按注释选型。
- 修复方向：要么在 `agent.py` 增加 `MEMORY_BACKEND == "redis"` 的真实选型（并进集成测试），要么整文件删除、注释同步更正；不允许"导出了但接不上"的第三态。

### M2. memory/redis_memory.py:76-83 | 健壮性/并发 | rpush/ltrim/expire 三步非原子，失败可留下**无 TTL 的 key**
- 证据：`await self._client.rpush(key, message)` → `ltrim` → `expire`
- 问题：三步之间若连接中断，消息已入 list 但 `expire` 未执行 → 该 key 永不过期，与"TTL 自动过期"承诺相反，长期运行内存只增不减；并发 add 时 ltrim/expire 交错也可能裁错窗口。
- 修复方向：用 pipeline(transaction=True) 把三步合成原子操作；或改 Lua/`EXPIRE` 前置。这是接口语义问题，不是加 try/except 能解决的。

### M3. memory/postgres_memory.py:34-48 vs rag/postgres_fts.py:175-191 | 同功能重复实现 | `_tokenize_chinese` 逐字复制
- 证据：两边注释还互相指认"与 postgres_fts.py 的实现保持一致"——靠人肉保持一致
- 问题：中文 2-gram 分词器在同一包里复制两份；连同 rag/retriever.py `_tokenize`（30）、utils/case_memory.py `_lex_tokens`（216）、utils/prescan.py `_terms`（146），**全仓共 5 份 CJK 2-gram 分词实现**，规则互有出入（是否含单字、ASCII 最小词长 2 还是 3）。FTS 检索词面口径一旦漂移，tsquery 与索引侧 gram 对不上，召回静默变差。
- 修复方向：抽 `app/agent/rag/tokenize.py`（或 utils）单一实现，5 处全部引用；postgres_memory 的 FTS 写入与 postgres_fts 的查询必须共用同一函数（这是正确性要求，不是 DRY 洁癖）。

### M4. rag/pg_vector_store.py:77-107、109-161 + rag/postgres_fts.py:257-311 | 健壮性 | 异常路径连接泄漏；async 接口内跑阻塞同步 DB
- 证据：`conn = psycopg2.connect(...)` 后仅在正常路径 `conn.close()`；`except Exception as e: logger...; return []`
- 问题：`add_texts/similarity_search/retrieve` 中任一 execute 抛错，conn 不 close（无 try/finally），连接池/PG 侧连接泄漏；且这些是 `async def`，内部却直接跑同步 psycopg2 + 全表余弦（2000 行载入 Python），阻塞事件循环。对照 memory/postgres_memory.py 已用 `run_in_executor` + `_raw_cursor` 规范处理，rag 两个 store 是同一问题的旧写法。
- 修复方向：连接生命周期走 contextmanager（参照 case_memory._get_conn 的形态但要保证 finally close/rollback）；DB 访问统一经一个线程池适配层，PgVectorStore 与 PostgresFTSRetriever 不再各自 `psycopg2.connect`。

### M5. resolvers/time.py:91-98 | 逻辑错误 | 交易日推算失败时静默按 `n*1.4` 个自然日估算
- 证据：`except Exception: step = timedelta(days=max(1, round(n * 1.4))); return (dt + step ...).strftime(...)`
- 问题：模块自己的契约是"不猜、无法准确判断就反问"，但日历挂掉时却用 1.4 倍系数**猜**出一个"交易日"喂给后续分析，且无任何 warning——节假日/长假期间误差可达一周。`_finish` 的 `except: return today`（125-130）同型。
- 修复方向（根因）：日历不可用属于基础设施故障，应当显式失败（返回 None → 触发澄清或缺失标注），而不是伪造日期；1.4 这种魔法系数没有任何口径依据。

### M6. resolvers/bridge.py:124-131、183-188 | 冗余/死分支 | try/except 两支是**完全相同**的 import
- 证据：
  ```python
  try:
      from .composite import CompositeResolver
      ...
  except ImportError:  # 直跑（app/agent 在 sys.path）时的裸导入
      from .composite import CompositeResolver
      ...
  ```
- 问题：except 分支的"裸导入"与 try 一字不差（第二处 `from ..domain_registry import entity_to_domain` 同样），原意的降级路径根本没写。真出 ImportError 时 except 里再抛一次同样的错，排障信息反而被掩盖。
- 修复方向：要么写出真正的备用导入路径（如 `from app.agent.resolvers.composite import ...`），要么删掉 except。当前形态属于"看起来有容错"的假防御。

### M7. resolvers/composite.py:299-307 | 逻辑错误 | `_merge` 用 `effective_input[len(user_input):]` 抠增量，隐含"前缀=原句"假设
- 证据：`extras.append(r.effective_input[len(user_input):].lstrip("，, "))`
- 问题：只校验了 `!= user_input`，没校验 `startswith(user_input)`。子解析器一旦对输入做了改写（time 的内联标注就是把日期插进句中，其 effective_input 不是"原句+尾缀"形态），切片会从句子中段硬切，merged 文本含半句话垃圾。
- 修复方向：增量传递用结构化字段（ResolveResult 增加 `suffix`/`annotations` 槽），不要从渲染后的字符串反向抠语义。

### M8. utils/tracing.py:586-624 + utils/mask.py | 健壮性/敏感信息 | 脱敏覆盖不一致：JSONL 有 mask，eval 侧车与 DB 写入没有
- 证据：`_write_jsonl` 里 `json.dumps(_mask(record))`；`_write_eval_dump` 的 `"corpus": "\n".join(parts)[:_EVAL_CORPUS_MAX]` 原样落盘
- 问题：eval dump 的 corpus 是**工具原始载荷**（`_tool_calls.result`），恰是 sk- key/Bearer/手机号最可能出现的载体；同样，`qd_agent_traces.analysis/input_params`、`qd_agent_cases` 入库文本均未过 mask。mask.py 自述"覆盖 JSONL 与 log，不止 DB"，实际 DB 与 eval 侧车都是裸的。
- 修复方向：脱敏点收敛到**所有出口**的同一层（写文件/写库前统一 `mask_obj`），而不是每个 writer 自觉调用；否则新增出口必然再漏。

### M9. utils/tracing.py:140-240、705-710 | 冗余 | 同一份 final_answer 被完整解析 JSON 6~7 次
- 证据：`_extract_score/_extract_direction/_extract_action/_extract_signal/_extract_confidence/_extract_timeframe/_extract_stock_from_answer` 每个都调 `_extract_from_json(answer)` → `extract_decision` → `extract_json`（含多轮正则 + 括号平衡扫描）
- 问题：`_write_qd_agent_traces` 逐字段调用这 7 个函数，同一长文本重复走完整解析管线 7 次；长答案（analysis[:2000] 之外全文）下是纯浪费，也放大了 ReDoS 面。
- 修复方向：入口解析一次 `extract_decision(answer)`，各提取函数改为消费 dict。

### M10. utils/__init__.py:33 | 死代码/接口谎言 | `__all__` 声明了未导入的 `extract_json`/`extract_decision`
- 证据：文件只 `from .json_parser import safe_parse_json`，但 `__all__ = [... "extract_json", "extract_decision", ...]`
- 问题：`from app.agent.utils import *` 会直接 AttributeError；两个名字的消费方（trace_collector、c3p）都从 json_parser 直连导入。`detect_market`（8-30 行）同样只有定义、零调用，且与 `app/data_sources/market_detector.detect_market`、`backtest._detect_market_fallback`、注释自述的 `basicinfo_db._detect_market` 是**第 4 份市场判定实现**。
- 修复方向：__all__ 与实际导出保持同源（或干脆去掉 __all__）；detect_market 合并进 domain_registry/market_detector 单一实现后删除本处副本。

### M11. utils/budget.py:44-94、181-213 | 死代码 | 日配额记账线（③）与 smolagents 用量提取整段零消费方
- 证据：grep `add_day_usage|get_day_usage|reset_day_usage|day_token_quota|tokens_from_agent|tool_calls_from_agent` 在 budget.py 之外**零命中**；qd_budgeting 只用 `check_budget/budget_wrapup_hint`
- 问题：`_DAY_USAGE` 记账、日切 rollover、`tokens_from_agent/tool_calls_from_agent`（引用已退役的 smolagents，永远 import 失败返回 0）全部无人调用；`check_budget(day_tokens=…)` 的第三条预算线永远不会被喂数。文件头宣称"三条预算线"实际只有一条半在工作。
- 修复方向：按现状删掉未接线的记账 API 与 smolagents 提取（或接上 mimoagent 的等价 step 记录）；预算面板文档同步改为真实生效的线数，避免"声明了没接线"复发。

### M12. utils/tracing.py:308-774 + trace_collector.py | 同功能重复实现 | 两套 qd_agent_traces 写入侧并存
- 证据：trace_collector.py 头注释自认"两条链并存，改任一侧都要回读另一侧"；grep 显示 `AgentTraceRecorder` 在生产代码**零构造**（仅 utils/__init__ 导出、tests 引 `_repro_meta`），现役写入侧是 `qd_aftercare → TraceCollector`
- 问题：774 行的 AgentTraceRecorder（事件采集/结构化提取/EvalNode 组装/save_tree）与 TraceCollector 的 `_extract_direction_from_text`/`_extract_stock_code_from_query` 等是两份独立演进的同功能实现（方向词表、股票代码提取规则已各不相同——trace_collector 注释实测 direction 69% 是兜底 neutral 正是两套口径之痛）。AgentTraceRecorder 疑似死代码，但 `tests/evals/runner.py --live` 依赖它写的 AGENT_EVAL_DUMP 侧车——**待确认**评测链路是否还在用。
- 修复方向（统一接口建议）：定一个 `TraceWriter` 协议（record/set_*/finish → EvalNode 树 → chain.store.save_tree），结构化字段提取（score/direction/action/stock）收敛为单一模块由两个前端共享；确认评测侧车迁移后删除 AgentTraceRecorder，只留 `_repro_meta`（挪去 chain/evidence 侧）。

### M13. utils/calibration.py vs chain/calibration.py | 同功能重复实现（同名不同物）| 两个 "calibration" 各说各话
- 证据：utils/calibration.py —— "评分校准…hit_rate 单一事实源"，sklearn isotonic、写 `qd_agent_weights(layer='calibration')`；chain/calibration.py —— "条件校准与层级池化"，logit β₀、`cal1` 系数。消费方：technical_analysis/bull_bear_research 用前者，c3p 用后者
- 问题：两模块同名、都宣称自己是校准的单一事实源，但一个校准 score→hit_rate、一个校准 p_base→p_final，字段/存储/过期语义完全不同。任何人想改"校准"都要先考古哪份是哪份；`app/services/ai_calibration.py` 还有第三处"calibration"命名。
- 修复方向（统一接口建议）：至少改名分层（如 `score_calibration.py` vs `conditional_calibration.py`），文档里互相引用；若最终口径是"hit_rate 从 β 校准链出"，应让 utils/calibration 成为 chain/calibration 的薄适配而非平行实现。

### M14. utils/calibration.py:244-251、350-351 | 健壮性 | `.db` 回退路径不存在；行访问方式与全仓约定冲突
- 证据：`except ImportError: from .db import get_db_connection`（app/agent/utils/ 下**没有 db.py**）；`scores = [float(r[0]) for r in rows]`
- 问题：① fallback 是死分支且指向不存在的模块；② fit_score_map 按**位置**解包行，而 case_memory.py:594 明确记录"RealDictRow 不支持整数下标（r[0] 会 KeyError）"、store.py 也注明已改按列名取——若该结论成立，`fit_score_map` 的 350-351 行会在 try 之外抛 KeyError 直接炸掉调用方（此处无 try 包裹）。两说法矛盾，**待确认**（本环境未安装 psycopg2，无法运行验证）。
- 修复方向：删除死 fallback；行访问统一按列名（`r["score"]`），与 store/case_memory 同口径。

### M15. skills/market_screener/common.py:24-91 | 同功能重复实现 | `FactorItem`/`SkillReport` 与 chain/schema.py 整段双写
- 证据：`class FactorItem`/`class SkillReport` 在 chain/schema.py:68/98 与 market_screener/common.py:24/50 各一份，字段几乎相同
- 问题：chain/schema.py 的 SkillReport 是全链标准结构（store/evaluator/indicator_tools 都用它），market_screener 又自建一份只服务 `build_report`，两份的 to_dict/from_dict 各自演化；run.py 拿 `report.output_data` 还要 `hasattr` 探测。
- 修复方向（统一接口建议）：market_screener 直接复用 `chain.schema.SkillReport/FactorItem`，common.py 保留渲染层（SkillResult.__str__）即可；数据结构只留一个家。

### M16. skills/strategy_debug/run.py:27-52 | 并发安全 | `redirect_stdout/stderr` + `sys.argv` 全局改写，非线程安全
- 证据：`with redirect_stdout(buf), redirect_stderr(buf): code = int(fn(argv) or 0)`；`_run_capture_argv0` 里 `sys.argv = ["debug"] + argv`
- 问题：redirect 与 sys.argv 都是进程级全局；工具若被并发调用（market_screener 已经用 ThreadPoolExecutor 并发取数，说明执行侧允许并发工具），两个 skill 调用会互相截获对方 stdout、argv 串台。
- 修复方向（根因）：底层 CLI（app.market_cn.auto.tools.*）应提供可注入输出流/argv 的入口；在那之前给 `_run_capture` 加进程内互斥（threading.Lock）并把"串行化"写进契约，而不是裸跑。

### M17. skills/market_screener/common.py:672 | 逻辑错误 | `last_zt_date` 语义写错（且全仓无人读）
- 证据：`"last_zt_date": max(records[0]["date"], date)`
- 问题：取 `max(最近一次涨停日, 传入的分析日)`——分析日通常=今天 ≥ 涨停日，于是 last_zt_date 恒等于"今天"，字段名在撒谎；grep 显示该字段目前零消费方（死字段+错值双重问题）。
- 修复方向：要么删字段，要么改成 `max(r["date"] for r in records)` 并在 dragon_pullback 明细里真的用它（龙回头距今几天本是有用的客观量）。

### M18. utils/mask.py:91-109 | 健壮性/敏感信息 | 脱敏规则有系统性盲区
- 证据：`_PATTERNS[3].sub(lambda m: m.group(1)[:3] + "****" + m.group(1)[-2:], out)`；key-value 规则值限定 `[^\s,;\"']{6,}`
- 问题：① 手机号保留前 3 后 2（可回溯定位到人，脱敏强度弱于身份证的全掩）；② 值长度 <6 的 `password=abc`、带引号含空格的 secret、JWT 长串（无 bearer 前缀、无 key= 前缀）都漏；③ 邮箱/银行卡无规则。作为"保守白名单"可以接受，但模块注释"覆盖 JSONL 与 log"给人已完备的错觉。
- 修复方向：明确脱敏等级契约（哪些形态必掩/哪些尽力而为）写进模块头；对 `token|key|secret` 键名做**键驱动**脱敏（不管值形态），比值形态正则可靠。

### M19. utils/json_parser.py:173-203、284-314 | 逻辑边界 | safe_parse_json 的括号平衡兜底只试第一个 `{`
- 证据：Step 3 记下 `obj_start = text.find("{")`；Step 5 只 `_extract_json_from_offset(text, obj_start)`；`_extract_json_from_offset` 内 `except JSONDecodeError: break`
- 问题：首个平衡 `{…}` 块若不是合法 JSON（正文里带花括号的伪代码），Step 5 直接放弃，而 `extract_json` 的同名 helper 是"逐个 `{` 重试"——同一个 helper 两种用法，容错差一档。畸形输入（LLM 在 JSON 前写了 `{示例}`）下解析率低于自家 extract_json。
- 修复方向：safe_parse_json 复用 extract_json 的逐 offset 重试策略（或统一成一条管线，两条解析管线本身也是重复实现）。

### M20. utils/grounding.py:38 vs 144 | 冗余/一致性 | 两套数字正则口径不一
- 证据：`_NUM_RE = re.compile(r"\d+(?:\.\d+)?")`（check_grounding 用）；`_NUM_FULL_RE` 带千分位/单位/百分号（extract_numbers 用）
- 问题：check_grounding 用 `_NUM_RE` 切 token，"1,234.5" 被切成 ["1","234.5"]，再送 `_grounded_count` 里的 `numbers_match` 归一匹配——千分位数字的可溯源判定靠"234.5 是 1,234.5 的子串"侥幸命中，格式换成 "12 345.6" 或全角逗号即误判为编造 → 触发重写循环（该模块注释自述误杀会触发 §7.19 重写死循环）。
- 修复方向：check_grounding 的 token 抽取统一走 `_NUM_FULL_RE`（同一 matcher 保证 count 与 match 同口径），两套正则合并为一处登记。

---

## 四、低严重度

### L1. memory/postgres_memory.py:18+21 | 冗余 | `from typing import Optional` 连续导入两次
- 证据：第 18 行与第 21 行同一条 import。修复：删一处。

### L2. memory/postgres_memory.py:76 | 冗余 | `dsn` 形参收下不用
- 证据：`dsn: str = "",  # 保留参数，实际由 app.utils.db 从 DATABASE_URL 读取`。修复：删除或显式校验 dsn 与实际连接一致性，避免调用方误以为可以传别的库。

### L3. memory/postgres_memory.py:51-61、139-143 | 健壮性 | `conn._conn` 私有穿透 + information_schema 不限定 schema
- 证据：`pg_conn = conn._conn`；`"SELECT 1 FROM information_schema.columns WHERE table_name = %s ..."`。多 schema 同名表会误判列存在。修复：db 层提供"裸 cursor"的正式出口；列检查加 `table_schema = current_schema()`。

### L4. memory/postgres_memory.py:152-156 | 冗余计算 | 每次进程初始化全表回填 tsvector
- 证据：`UPDATE {} SET fts_vector = to_tsvector(...) WHERE fts_vector IS NULL`。表大时启动变慢且无索引支撑该谓词。修复：回填改为一次性迁移/后台任务，或对 `fts_vector IS NULL` 建部分索引。

### L5. memory/postgres_memory.py:285-352 | 死代码 | `count_messages/list_sessions/get_stats` 零调用
- 证据：grep 仅命中定义处。修复：删除或接到运维接口（stats 本来适合 /health）。

### L6. memory/base.py:13、postgres_memory/redis_memory | 健壮性 | `MemoryMessage.role: Literal[...]` 与实现脱节
- 证据：Redis/PG 后端从存储读回的 role 不经校验直接构造。修复：构造时校验/归一（非法 role 归 user），或把类型放宽为 str。

### L7. rag/embeddings.py:75-76 vs 99 | 逻辑不一致 | 单条截断 2048、批量截断 4096
- 证据：`if len(text) > 2048: text = text[:2048]` vs `t.strip()[:4096]`。同一段文本单条/批量走不同截断 → 向量不可比。修复：截断上限统一为模型上限的单一常量。

### L8. rag/embeddings.py:82、107 | 并发安全 | `dashscope.api_key = self.api_key` 写进程全局
- 证据：每次调用覆盖全局 api_key。多实例/多租户并发时互相覆盖。修复：用 per-request 的 api_key 参数（dashscope 支持 `api_key=` 入参）或单例持有。

### L9. rag/retriever.py:129-136 | 逻辑边界 | `format_context` 的 `break` 截断 + 计数失真
- 证据：`if total_len + len(part) > max_length: break`；`logger.info("相关性硬拦截：%d → %d", dropped + kept, kept)`
- 问题：超出 max_length 的高分文档被静默丢弃且不计数；日志里"总分母"不含被 break 的条数。修复：截断单独计数 `truncated` 并入日志；上限内按 score 而非输入顺序取（当前 docs 已按分排序则是等价的，**待确认**所有调用方都传已排序列表）。

### L10. rag/retriever.py:386-388 | 逻辑边界 | rerank API 返回缺 index 时默认 `0`
- 证据：`idx = item.get("index", item.get("document_index", 0))`。字段缺失时 docs[0] 被重复塞进结果而非报错。修复：缺 index 直接跳过/报错，不做猜测。

### L11. rag/retriever.py:218-227 | 冗余 | `ChatHistoryRetriever.weight` 存而不用
- 证据：`self.weight = weight` 无任何读取点；权重实际由 `RetrieverRoute(name, retriever, weight=0.4)` 承载（agent.py:176）。修复：删参数，权重单一来源=RetrieverRoute。

### L12. rag/vector_store.py:68-82 | 资源管理 | 每次调用新建 QdrantClient，从不 close
- 证据：`_get_client()` 在 add_texts/similarity_search 各调一次。修复：构造期持有一个 client（线程安全），或 with 管理生命周期。

### L13. rag/pg_vector_store.py:26 vs rag/vector_store.py:16 | 冗余 | PgVectorStore 不继承 VectorStoreBase
- 证据：两处 `add_texts/similarity_search` 签名一致但无继承关系，Retriever 类型注解是 VectorStoreBase。修复：PgVectorStore 实现同一 ABC，把契约钉死。

### L14. resolvers/stock.py:64-71 | 死代码 | `_expand_stock_query` 构造 `entity_desc` 后未使用
- 证据：`entity_desc = ",".join(entity_parts)` 后函数直接返回 `f"{expanded}，{default_params}"`。docstring 示例格式与实际返回也不一致。修复：删变量或（更正 docstring）真正把实体摘要放进返回。

### L15. resolvers/stock.py:114-117 | 冗余/资源 | 每次解析新建 ThreadPoolExecutor
- 证据：`with _cf.ThreadPoolExecutor(max_workers=1) as _pool:` 在 `_resolve_async` 内部，一次 resolve 最多建 4~6 个池。修复：模块级共享线程池（bridge 已是进程级单例 resolver，池同理）。

### L16. resolvers/stock.py:121-127、166-171 | 异常吞掉 | DB 异常与"无匹配"不可区分
- 证据：`except Exception: return []`；随后 `if not cands: continue`。DB 故障时"该标的不存在"，既不解析也不反问。bridge 顶层注释把 fail-open 当设计，但本模块的契约是"解析不出就反问"。修复（根因）：区分 `search_error` 与 `no_match`，错误时至少 warning + 按无实体返回并留痕。**待确认**产品是否接受故障期静默。

### L17. resolvers/time.py:152-164 vs 370-378 | 冗余 | 「下周X」日期计算两处手写
- 证据：`_detect_anomaly` 内 `next_mon = ... ; d = _next_weekday_after(...)` 与 `_resolve_one.weekday_rel` 的 "下" 分支同构。修复：抽 `_weekday_of_week(rel, wd, today)` 单一函数。

### L18. resolvers/time.py:122-127 等 | 时间/时区 | 全链 naive `datetime.now()`，无时区口径
- 证据：`_today()`、`_finish()`、budget._today、tracing `date.today()`、market_screener `_today_str()/select_strategy()` 全部取服务器本地时间。容器 TZ 非 Asia/Shanghai 时（K8s 默认 UTC）"今天/昨天/交易日"全体偏移一天，且无任何日志暴露时区。修复：单一 `now_cn()` 出口（zoneinfo Asia/Shanghai），各处禁止裸 datetime.now() 做业务日期。（app/utils/trading_calendar.py 已是交易日单一事实源，业务日期口径也应并入。）

### L19. utils/logger.py:54-70 | 并发安全 | get_logger 的 check-then-add 竞态
- 证据：`if logger.handlers: return logger` … `logger.addHandler(handler)`。两线程同时首次获取同名 logger 可能各挂一个 handler → 双份日志。修复：`logging.getLogger` 配置集中到一次性的 dictConfig，或加锁。

### L20. utils/logger.py vs app/utils/logger.py | 同功能重复实现 | 两份 get_logger
- 证据：prescan.py 用 `from app.utils.logger import get_logger`，json_parser 用相对 `.logger`；log.py 注释"与 app/utils/logger.py 写入同一个文件"。修复：合并为一份（agent 内外引用同一模块）。

### L21. utils/prescan.py:15、59-65 | 死代码 | `import importlib` 未用；`_return_hint` 零引用
- 证据：grep 全仓无 `_return_hint` 调用；prescan_skill_funcs 用的是 ast Return 提取。修复：删除。

### L22. utils/md_format.py:118-125 | 健壮性 | `_to_tsv` 值含 tab/换行时破坏 TSV 结构
- 证据：`vals.append(str(v) if v is not None else "")`。工具输出被 LLM 按列解析时错列。修复：对值做 `\t/\n` 转义（或统一改 JSON 输出）。

### L23. utils/grounding.py:71 | 逻辑边界 | `BANNED_PHRASES` 有错别字项
- 证据：`"稳簿不赔"`（应为"稳赚不赔"；因"稳赚"已在表内暂未漏拦截）。修复：更正词条。

### L24. utils/grounding.py:247 | 逻辑边界 | 噪声过滤 `len(n.lstrip("0.")) >= 2` 误杀 0.5 级小数
- 证据："0.5".lstrip("0.") → "5"（长度 1 被当噪声剔除）。基金净值/收益率类文本里的 0.xx 不参与溯源统计。修复：按有效数字位数判断，不用 lstrip 技巧。

### L25. utils/grounding.py:253-254 | 冗余计算 | ungrounded 列表里 `value_in_corpus(n, corpus)` 未传 corpus_vals
- 证据：`[n for n in nums if not (n in corpus or value_in_corpus(n, corpus))]`——每个候选重复全语料数值抽取。修复：传入已算好的 cvals。

### L26. utils/json_parser.py:152、207 | 冗余/健壮性 | 非 str 入参直接 AttributeError；`_JSON_PATTERNS[0]` 与 Step 2 正则重复
- 证据：`if not text or not text.strip()`（dict 入参炸）；`r'```json\s*\n?(.*?)\n?\s*```'` 在 162 与 207 两处。修复：入口 `isinstance(text, str)` 防御 + 正则常量化单份。

### L27. utils/case_memory.py:354-357、425-438 | 冗余计算/一致性 | 每次检索全表扫 2000 行做 Python 余弦；去重用词面、召回用向量
- 证据：`SELECT ... ORDER BY created_at DESC LIMIT %s (CASE_SCAN_LIMIT,)` 后逐行 `_cosine`；近重复判 `_lex_sim(...) > CASE_DUP_SIM`。量涨后延迟线性劣化；两套相似度对"重复"的定义不一致。修复：embedding 落库时建向量索引（或至少按 tag/时间粗筛），去重复用与召回同一 sim。

### L28. utils/tracing.py:472、526-527 | 逻辑边界/一致性 | falsy 工具结果被记成空串；panel 写失败完全静默
- 证据：`"result": str(result)[:2000] if result else ""`（0/False/[] 丢失）；panel.jsonl 的 `except Exception: pass`（对比 eval dump 的 warning）。修复：`result is not None` 判断；所有旁路写失败统一 warning。

### L29. utils/tracing.py:295-304 | 待确认 | `.git` 取版本路径 `parents[3]`（= backend_api_python/）
- 证据：`_git = Path(__file__).resolve().parents[3] / ".git"`。本 checkout 下 backend_api_python/.git 与 QuantDinger/.git 均不存在 → code_version 恒 "unknown"。**待确认**部署形态是否在 backend_api_python 独立建仓。修复：向上逐级探测 .git 目录，探测不到时在 meta 里标 `no-vcs` 而不是 unknown。

### L30. skills/market_screener/common.py:13 | 死代码 | `import sys` 在 2026-10-13 P5 移除 sys.path 注入后不再使用
- 证据：文件内 sys 仅出现在注释。修复：删 import。

### L31. skills/market_screener/common.py:457-473 | 异常吞掉 | `fetch_kline` 全量吞异常返回 []
- 证据：`except Exception: return []`。DB 挂了与"该股无数据"同形，只能靠上游 missing 文案区分。修复：至少 debug 日志带 code/reason（对照 _facts.intraday_bars 有 `logger.debug`，同文件两种风格）。

### L32. skills/market_screener/_helpers.py:474 | 冗余 | `candidates[: max(limit * 2, limit)]` 恒等于 `limit*2`
- 证据：`max(limit * 2, limit)`。修复：写 `limit * 2` 并注明"画像窗口=2×limit"的理由。

### L33. skills/market_screener/_helpers.py:34-45、284-294 | 时间/健壮性 | `select_strategy` 无视节假日；`_MKT_KLINES_CACHE` 进程级永不失效
- 证据：`if now.weekday() >= 5: return "post_market"`（节假日工作日照样判 intraday）；`_MKT_KLINES_CACHE["data"]` 无 TTL。长驻进程里 120 日市场 K 线缓存越跑越旧。修复：时段判断走 trading_calendar.is_trading_day；缓存加时间戳按日失效。

### L34. skills/market_screener/_helpers.py:396-431 | 死代码 | `enrich_predictive` 标注"请勿在新代码中调用"，生产零调用（仅测试契约）
- 证据：grep 生产代码无调用方。修复：随测试一起迁移或删除，避免"兼容层"变永久双轨。

### L35. skills/market_screener/_facts.py:548-551 | 逻辑边界 | `_put` 合并把 `0` 当"缺失"覆盖
- 证据：`if k != "source" and pool[code].get(k) in (None, "", 0): pool[code][k] = v`。change_pct 恰为 0.0 的真实值会被后到来源覆盖。修复：只把 None/"" 当缺失。

### L36. skills/market_screener/run.py:339-373 | 冗余 | `_bars` 清理两遍
- 证据：raw 循环里 `r.pop("_bars", None)`，build_report 后 analyzed 再 pop 一次。修复：留一处（build_report 输出侧）。

### L37. memory/local_memory.py + redis_memory.py + postgres_memory.py | 冗余 | 三个后端各带一套"兼容参数别名"
- 证据：`max_history`/`ttl_seconds`/`redis_prefix` 皆为"兼容旧示例/配置项"的第二名字。修复：统一构造签名（选型层做参数映射），后端只留一套参数名，消除 `max_history if ... else max_messages` 分支。

---

## 五、按类别的重复实现汇总（类别 4 专项）

| 功能 | 实现 A | 实现 B（+C/D/E） | 统一建议 |
|---|---|---|---|
| 中文 CJK 2-gram 分词 | rag/postgres_fts._tokenize_chinese | memory/postgres_memory._tokenize_chinese（逐字复制）、rag/retriever._tokenize、utils/case_memory._lex_tokens、utils/prescan._terms（共 5 份） | 单一 `tokenize_cjk()`，FTS 写入/查询必须同源 |
| 余弦相似度 | rag/pg_vector_store._cosine_similarity | utils/case_memory._cosine | 单一 `mathx.cosine()` |
| SkillReport/FactorItem | chain/schema.py | skills/market_screener/common.py | 复用 chain.schema |
| qd_agent_traces 写入 | trace_collector.TraceCollector（现役） | utils/tracing.AgentTraceRecorder（疑似死） | TraceWriter 协议 + 共享字段提取；删旧 |
| 校准 | utils/calibration（score→hit_rate） | chain/calibration（条件 β₀）、app/services/ai_calibration | 改名分层 + 明确谁消费谁 |
| get_logger | app/agent/utils/logger.py | app/utils/logger.py | 合并一份 |
| detect_market | utils/__init__.detect_market（死） | app/data_sources/market_detector、backtest._detect_market_fallback、basicinfo_db._detect_market | 收敛到 market_detector |
| JSON 提取管线 | utils/json_parser.safe_parse_json | utils/json_parser.extract_json（同文件双管线） | 合并一条，另一个做别名 |
| 数字抽取 | grounding._NUM_RE | grounding._NUM_FULL_RE | 合并（见 M20） |
| 业务日期/时区 | resolvers/time（datetime.now） | budget._today、tracing date.today、market_screener _today_str/select_strategy | 单一 `now_cn()`（见 L18） |
| 记忆后端滑窗裁剪 | local（list 切片） | redis（ltrim）、postgres（DELETE…OFFSET） | 语义差异可接受，但签名/别名应统一（见 L37） |

---

## 六、整体评价

**总体质量高于平均水平**：模块头部普遍带"为什么这么改"的事故考古注释（2026-10-02 sys.path 事故、A6 落库断链、B4 否定语境、C2 语料收窄），澄清契约（"不确定就反问而不是猜"）在 resolvers 层是真实落地的设计而不是口号，case_memory/grounding 的 fail-open 且**必留痕**纪律执行得比较一致。主要问题集中在四类：

1. **并发/超时形同虚设**（H4、M2、M16、L19）：多处"超时/线程隔离"只包了壳，`with ThreadPoolExecutor` 的 shutdown(wait=True) 让所有 deadline 失效；全局态（sys.argv、redirect_stdout、dashscope.api_key、日志 handler）在并发工具调用下会串台。这是本组最需要系统性修的面。
2. **同功能多实现的沉淀**：CJK 分词 5 份、SkillReport 2 份、traces 写入 2 份、calibration 同名 2 份——多数是历史链路（smolagents→mimo）迁移时"新链没删旧链"的产物，且有几处已经靠注释里"与 XX 保持一致"的人肉纪律维持正确性（postgres_memory 的 FTS 分词一漂移，检索就静默变差）。建议把上表的统一接口作为一次专项，而不是逐处顺手改。
3. **死代码面不小**：RedisMemory 整文件、budget 的日配额线与 smolagents 提取、postgres_memory 三个统计方法、prescan._return_hint、AgentTraceRecorder 主体（**待确认**评测侧车依赖）——约 1000+ 行"看起来在工作"的代码。本仓注释文化好，但死代码+好注释=更强的误导。
4. **静默降级的边界要重新划线**：fail-open（不阻断主链）是对的，但 H5（success 空答案不落库）、M5（日历挂了按 1.4 倍系数猜交易日）、L16（DB 故障=查无此股）越过了"降级"进入"编造"——和 grounding 模块自己立的"不许编造"红线冲突。凡是降级后**产出的数据看起来像真数据**的路径，都应该改成显式缺失标注。

最优先修复顺序建议：H1 → H2 → H3 → H4 → H5 → M4 → M8/M12（脱敏与写入侧收敛一起做）。
