# 工具层代码审查报告 — app/agent/tools/（含 finance/、knowledge/）

- 审查日期：2026-10-13
- 范围：`QuantDinger/backend_api_python/app/agent/tools/` 全部 34 个 .py（共 11,453 行），只读审查
- 方法：逐文件通读 + ast 静态扫描（注册候选/同名碰撞/摘除表对照）+ 全项目 grep 引用核对（死代码/重复实现定位）
- 声明：未修改任何项目文件；未执行 git 命令；临时脚本在 `.openclaw/tmp/scan_tools.py`

---

## 一、审查覆盖清单（34/34 全部已审）

### tools/ 顶层（14 个）
| 文件 | 行数 | 已审 |
|---|---|---|
| `__init__.py` | 9 | ✅ |
| `_availability.py` | 123 | ✅ |
| `_base.py` | 201 | ✅ |
| `_fn_adapter.py` | 107 | ✅ |
| `_pagination.py` | 444 | ✅ |
| `_provider.py` | 561 | ✅ |
| `_schema_gen.py` | 186 | ✅ |
| `_serialize.py` | 215 | ✅ |
| `capability_tools.py` | 113 | ✅ |
| `format_utils.py` | 159 | ✅ |
| `memory_tools.py` | 60 | ✅ |
| `skill_tools.py` | 134 | ✅ |
| `tool_discovery.py` | 178 | ✅ |
| `web_search_tools.py` | 574 | ✅ |

### tools/finance/（21 个）
| 文件 | 行数 | 已审 |
|---|---|---|
| `__init__.py` | 2 | ✅ |
| `_analysis_utils.py` | 193 | ✅ |
| `_em_utils.py` | 54 | ✅ |
| `_screener_config.py` | 65 | ✅ |
| `analysis_tools.py` | 2127 | ✅ |
| `backtest_tools.py` | 187 | ✅ |
| `bull_bear_research.py` | 722 | ✅ |
| `chip_distribution.py` | 247 | ✅ |
| `data_tools.py` | 982 | ✅ |
| `domain_meta.py` | 129 | ✅ |
| `dragon_tools.py` | 150 | ✅ |
| `fund_flow_tools.py` | 190 | ✅ |
| `index_tools.py` | 195 | ✅ |
| `indicator_tools.py` | 782 | ✅ |
| `kline_tools.py` | 66 | ✅ |
| `news_search_tools.py` | 215 | ✅ |
| `screener_tools.py` | 511 | ✅ |
| `sector_analysis_tools.py` | 395 | ✅ |
| `signal_tools.py` | 363 | ✅ |
| `technical_analysis.py` | 397 | ✅ |
| `trading_tools.py` | 256 | ✅ |

### tools/knowledge/（3 个）
| 文件 | 行数 | 已审 |
|---|---|---|
| `__init__.py` | 6 | ✅ |
| `domain_meta.py` | 13 | ✅ |
| `knowledge_tools.py` | 142 | ✅ |

**注册面核对（ast 静态扫描）**：可注册候选 = 顶层 12 个（format_utils/web_search_tools 走 `_MUST_HAVE` 元工具通道）+ finance 48 个 + knowledge 1 个，其中 20 个在 `_SUPERSEDED_BY_MERGE` 摘除注册（实现保留，有文档化理由，不计死代码）；**跨模块同名 0 个**（无注册表覆盖风险）；`_SUPERSEDED_BY_MERGE` 的 20 个 key 与定义位置全部对得上，无"摘了名但函数不存在"的空转条目。

---

## 二、高严重度（6）

### H1 | indicator_tools.py:550-556 | 逻辑错误（管线整体失效）
`_evaluate_indicator` 调 `run_indicator_signal` 时**漏传必填的 `stock_code`**，且把批量参数 `codes=` 传了进去：
```python
sig = run_indicator_signal(
    indicator_id=indicator_id,
    codes=codes,        # ← 应为 stock_code=codes；codes 非空会进批量分支
    ...)
if not sig.get("success"): return None   # 批量分支返回 {count,data}，无 success 键
```
后果：① 缺 `stock_code` 必填参数 → TypeError 直接抛出；② 即便补上，`codes=` 走批量分支返回 `{count,data}`，`sig.get("success")` 恒为 None 仍 return None，还埋着「批量→indicator_analysis→_evaluate_indicator→批量」的递归环。`indicator_analysis`（及 run_indicator_signal 的批量模式）对每个指标都拿不到评估结果 → 恒走"指标执行无结果"中性分支或 error 占位。**指标策略研判整条链路静默失效。**
修复方向（根因）：run_indicator_signal 的"单股/批量"双形态合并时把入参语义混了。应抽出无形态的单股执行内核 `_run_one(indicator_id, stock_code, ...)`，单股/批量/`_evaluate_indicator` 三个入口都调它，消除互调与递归。

### H2 | indicator_tools.py:421,464 | 逻辑错误（评分公式数学错误）
```python
total_score = 50.0
...
total_score += score * conf      # score 是 0-100 强度分
total_weight += conf
...
final_score = max(0, min(100, total_score / total_weight))
```
`(50 + Σ score·conf) / Σ conf` 不是加权平均。单个买入信号（score=60, conf=0.3）→ (50+18)/0.3 ≈ 226 → clamp 100；单个卖出信号同理打到 0。**任何单信号都输出极端分**，50 的"观望基准"被混进分子又除以权重。
修复方向：`final_score = Σ(score·conf)/Σconf`（conf 总和为 0 时才回 50），或显式做「先验 50 与信号加权分的贝叶斯融合」，两者的数学含义要在注释里写清。

### H3 | analysis_tools.py:1469 | 逻辑错误（死分支，形态永不触发）
乌云盖顶判定用了当日自身高低点：
```python
if (pc2 > po2 and
        lo > lh and      # ← 当日开盘 > 当日最高，对合法K线恒 False
        lc < po and ...)
    patterns.append("乌云盖顶（顶部反转）")
```
`lo=o[-1]`、`lh=h[-1]`。开盘永远 ≤ 最高，条件恒 False。注释写"高开"，本意应是比较与**前一根**的关系（如 `lo > pc2` 或 `lo > max(po2,pc2)`）。
修复方向：改判定对象（前根实体上沿/收盘），并补一条该形态的回归测试用例（含标准乌云盖顶样例）。

### H4 | analysis_tools.py:1480 | 逻辑错误（死分支，条件自相矛盾）
刺透形态：
```python
if (pc2 < po2 and          # 前阴线 ⇒ (po2+pc2)/2 < po2
        lo < pl2 and
        lc > po2 and       # 收盘高于前开
        lc < (po2 + pc2) / 2 and   # 收盘又低于中点(<po2) → 与上一行互斥
```
两条件互斥，恒 False，形态永不触发。注释"收盘深入前一根实体一半以上（从下方）"的正解是 `po2 > lc > (po2+pc2)/2`。
修复方向：按经典定义改区间方向；与 H3 同批补回归用例。

### H5 | technical_analysis.py:143,157,313,191 | 逻辑错误（生产/消费字段契约漂移，4 处死分支）
`_algo_analyze` 读取的字段与各生产工具的 Returns 契约对不上：
| 消费处 | 取键 | 生产者实际 | 后果 |
|---|---|---|---|
| :143 | `volume.get("turnover_rate",0)` | get_volume_analysis 无此键 | 恒 0，换手分支死，factor 显示"换手0.0%"误导 |
| :157 | `vol_trend == "递增"/"递减"` | 返回 "上升"/"下降"/"平稳" | 两分支恒不命中 |
| :313 | `rsi_dict.get("rsi") or .get("value")` | rsi dict 键为 rsi6/12/24 | 可证伪条件的 RSI 项恒不生成 |
| :191 | `chip.get("profit_ratio",50)` 当 0-100 用 | chip_distribution 返回 **0-1 小数**（:138 `round(profit_ratio,4)`） | 获利盘修正分支恒不触发，筹码因子永远 50 |

修复方向：字段/单位口径以各工具 Returns 契约为单一真源（抽共享常量/TypedDict + 契约测试），**禁止**在消费端加默认值把缺口盖住——这正是漂移长期不被发现的原因。

### H6 | bull_bear_research.py:64-65,98-99 | 逻辑错误（多空论据恒不触发）
```python
rsi = indicator.get("rsi6", 50)          # _get_indicator_snapshot 返回 {rsi:{rsi6..}, macd:{..}}
macd_hist = indicator.get("macd_hist", 0)  # 该键不存在（macd 是嵌套 dict，无 macd_hist）
```
RSI 超买/超卖、MACD 多头/空头四条论据全部吃默认值 → 永不触发。`bull_bear_research` 实际只靠 trend_score + 量价关系 + 情报在打分，"多空研究员"的核心动量论据是摆设。
修复方向：随 H1/M1 一并收敛字段契约（从嵌套结构取值：`indicator["rsi"]["rsi6"]`、`indicator["macd"]["macd"]`），或让快照工具直出扁平键，二选一，全链路统一。

---

## 三、中严重度（19）

### M1 | bull_bear_research.py:228-672 | 重复实现 + 注释与事实不符
文件头（:4-11）声称"4 个内部分析函数…改为导入单一实现，不在此复制第三份"，但文件里 `_analyze_trend`(228)/`_get_volume_analysis`(430)/`_analyze_pattern`(516)/`_get_indicator_snapshot`(664) 四份内联副本**仍在**，与 analysis_tools.py 的同名功能大段重复（K线形态识别更是逐行复制）。且 `_analyze_pattern` 是旧版（缺乌云盖顶/刺透/三法/弃婴段）。
更糟：两份 `_analyze_trend` 的 RSI 计分**方向相反**——analysis_tools 用 `rsi_score = int(100 - rsi6)`（逆向/均值回归），bull_bear 用 `rsi_score = int(rsi6)`（动量），而 bull_bear 顶层又按逆向解读（`rsi<30` 看多）。同一工具内自相矛盾。
修复方向：删 4 副本、直接调 analysis_tools 实现（`technical_analysis._call_tools` 已是这么做的先例）；统一 RSI 语义并在 `_calc_rsi` 处写明口径。
另：`_analyze_pattern`(516) 与 `_get_chip_distribution`(659) 在本文件内**无任何调用者**（死代码）；`from .news_search_tools import search_policy_intel`(15) 未使用。

### M2 | technical_analysis.py:12-46（_call_tools）+ bull_bear_research.py:42-50 | 冗余（同票 5 次取数、指标重复计算）
`technical_analysis` 对同一只票串行调 analyze_trend(120根) + get_indicator_snapshot(120根) + get_volume_analysis(30根) + analyze_pattern(10根) + get_chip_distribution(120根) ⇒ 同一标的 K 线拉 5 次；MACD/RSI/BOLL/KDJ 在 analyze_trend 与 snapshot 里各算一遍。bull_bear_research 同病（trend+indicator+volume 三拉三算）。
修复方向：一次 `_fetch_ohlcv(code,120)` + 一次指标计算，结果分发给各组装器；`_call_tools` 改为「取数→算指标→组装」三层。

### M3 | data_tools.py:231-271 | 逻辑错误（复权口径谎报）
`agent_get_kline` 的 adj 换算失败时只 warning 并**回退 qfq 数据**，返回信封仍标注请求口径：
```python
except Exception as _adj_err:
    logger.warning("agent_get_kline adj=none 转换失败(%s): %s", ...)
...
return {..., "adj": (adj or "qfq").lower(), "error": None}
```
请求 hfq/none 拿到的可能是 qfq 数据但 `adj:"hfq"`——口径标错会污染分析/回测可比性（这正是加 adj 参数要解决的问题）。
修复方向：换算失败 = 该 code 返回 error（或 `adj:"qfq"` 实际口径 + 显式 `adj_fallback:true`），不能静默谎报。

### M4 | trading_tools.py:208-234 | 健壮性/权限（越权读取）
`get_strategy_trades(strategy_id, user_id=1, limit)` 的 `user_id` **形参从未使用**，SQL 只按 `strategy_id` 过滤：
```python
"SELECT ... FROM qd_strategy_trades WHERE strategy_id = %s ORDER BY id DESC LIMIT %s"
```
同文件其他工具都做 `get_strategy(strategy_id, user_id=...)` 归属校验，唯独交易明细漏掉 ⇒ 知道 strategy_id 即可读任意用户的交易记录。
修复方向：查询前做归属校验或 SQL 加 `AND user_id = %s`（与其他工具同口径）。

### M5 | dragon_tools.py:38-44 | 逻辑错误（日期窗口倒挂）
指定 `date` 为历史日时：`start_date = now - days`、`_date = date`：
```python
start_date = (datetime.now() - timedelta(days=...)).strftime(...)
all_data = _get(start_date, _date)   # date 早于 start_date 时区间倒挂 → 恒空
```
查询 `date=2026-01-01, days=30` → `_get("2026-09-13","2026-01-01")` 永远空且不报错。
修复方向：窗口应从 `date` 起算（`start = date - days`）；空区间的返回要能区分"无数据"与"参数错误"。

### M6 | _pagination.py:334-444（全文件 444 行） | 死代码 + 潜伏 NameError
全项目 grep 无任何调用方（`paginated/paginate_result/paginate_text/get_page/get_text_page/get_cache_summary/page_tool` 全部零引用）⇒ **整模块死代码**。且文件尾 `@reg_tool`(420)/`page_tool`(432) 因4空格缩进被顶层注释"接"进了 `paginated()` 的函数体（`return decorator`(415) 之后的注释行不闭合缩进块）——`page_tool` 实为 `paginated` 的嵌套函数，`reg_tool` 也从未 import，一旦有人调 `paginated()` 立即 NameError。`from ..log import logger`(28) 未使用。
修复方向：确认无用后整文件删除（或迁入现行 ToolProvider 注册体系并修正作用域）；「翻页」需求若仍存在，应在 `_serialize._strip_nulls` 截断(300 行)之外提供统一方案而不是留两套半成品。

### M7 | analysis_tools.py:921-974 | 逻辑/冗余（评分重复计数 + 缺中性档）
`_detect_resonance` 已把乖离率(维度6, ±8/±4)与背离(维度4, ±10/±4)计入 `score_adjustment`，`analyze_trend` 随后又对同一 `bias_ma20`/背离**再**做 ±10/±5 与 ±10/±8 修正（921-960）⇒ 双重计数。另外趋势分档：
```python
elif total_score >= 55: overall, strength = "偏多", "中"
elif total_score >= 45: overall, strength = "偏多", "中"   # 相邻分支同值
```
45-54 分（低于中性 50）被判"偏多"，且没有"中性/震荡"档。
修复方向：修正来源只能在一个层级（共振表**或**外层修正，二选一）；分档以 50 为对称中心补中性档、合并同值分支。

### M8 | analysis_tools.py:872-896, 282-291 | 冗余（重复计算）
背离检测手工重算 `_ema(closes,12/26)` 全序列 + 内联重写 RSI6 Wilder 循环（`_calc_macd/_calc_rsi` 内部已算过，同文件第三份）；`_calc_atr` 把 Wilder 平滑循环跑两遍（`atr_val` 与 `temp_atr` 各一遍，只差取尾部 5 值）。
修复方向：`_calc_macd` 直接返回序列、`_calc_rsi` 返回序列版 API；ATR 趋势从一趟平滑的历史里取值。

### M9 | data_tools.py:134 | 逻辑错误（返回键契约不一致）
`get_realtime_quote` 对入参做 `code_list = [_strip_prefix(c) for c in code_list]` 后**用裸码做返回键**。`agent_get_kline` 在 2026-09-22 专门修过同型问题（"入参 '600519.SH' 返回键落空 → 指标全缺"），但 quote 侧仍是裸码键，模型按 `data['600519.SH']` 取值会 KeyError。
修复方向：统一「返回键=原始入参码、查询用裸码」（同 agent_get_kline），或在文档/信封里强制键归一并让所有工具一致。

### M10 | _analysis_utils.py:42-55；data_tools.py:258-264 | 健壮性（None/过滤口径）
`_fetch_closes` 过滤 falsy close（`if k.get("close")`）而 `_fetch_ohlcv` 不过滤、且 `float(k.get("open", 0))` 遇 key 存在值为 None 时抛 TypeError——两个取数 helper 的窗口长度可能不一致（过滤行数不同 ⇒ 窗口错位），None 值无防护。`agent_get_kline` 的 `round(k.get("open", 0), 2)`（258-264）同样对 None 抛 TypeError 且该段无 try。
修复方向：取数层统一「拒绝 None/0 垃圾行 + 异常显式」的一套规则，两个 helper 共用同一清洗函数，禁止各自过滤。

### M11 | indicator_tools.py:267,282 | 健壮性（NaN→True 误报信号）
`buy_series = executed_df["buy"].astype(bool)`：pandas 中 NaN→True。指标脚本若以 NaN 初始化信号列（常见写法），整列都会被判成买/卖信号。**待确认**：需对照 `app/services/indicator_analyzer` 与用户指标代码的信号列约定。
修复方向：信号列判真改为 `series.fillna(False).astype(bool)` 或 `series == True`，并在沙箱执行契约里明确信号列取值域。

### M12 | screener_tools.py:345-349, 452-456 | 逻辑错误（条件丢失 + 语义误导）
`build_keyword_from_filters` 资产负债率分支只覆盖「min+max」「仅 max」，**仅设 min 时条件静默丢失**：
```python
if da_min is not None and da_max is not None: ...
elif da_max is not None: ...
# da_min 单独设置 → 什么都不生成
```
另 `limited_lift_filter` 生成关键词"限价上涨6月/1年"——该开关的语义是**限售解禁**（对照 domain_meta 的 lockup 域、`get_lockup_expiry`），"限价上涨"是错误翻译，会把错误关键词喂给东财智能选股。
修复方向：补齐 min-only 分支；解禁关键词改为"限售解禁6月内/1年内"（以东财选股的原生口径为准）。

### M13 | sector_analysis_tools.py:322-351 | 健壮性（永久负缓存 + 假"线程安全"）
`_board_name_cache` 注释写"线程安全存储"但无锁；`_build_board_name_cache` 某板型拉取失败时写入 `{}`，而入口 `if _board_name_cache: return` 视非空 dict 为已建好 ⇒ **一次瞬时网络失败即永久缓存空映射**，`_resolve_board_code` 此后永远解析不到 BK 代码、`get_sector_stocks` 静默返回空。
修复方向：区分"未建/建好/建失败"，失败可重试（如带 TTL 或失败标记）；加锁或用单次初始化事件。

### M14 | memory_tools.py:34,51；_fn_adapter.py:84 | 健壮性（asyncio.run 事件循环冲突）
`remember/recall` 与 `FnToolAdapter.execute` 用 `asyncio.run(...)` 同步化异步调用；若调用发生在已有事件循环的线程（mimoagent 异步执行核），`asyncio.run` 抛 RuntimeError 被宽 except 吞成"工具执行失败"。`knowledge_tools._run_sync`（检测 running loop + 线程兜底）是本仓库的正确示范。**待确认**：mimoagent 对同步工具的实际调用线程模型。
修复方向：统一复用 `_run_sync` 模式（建议挪到 `_fn_adapter` 或公共 util），memory_tools 不要自带第二种同步化。

### M15 | news_search_tools.py:143 | 逻辑存疑（参数语义）
`search_sector_intel` 把板块关键词同时当 symbol 和 market 传下去：`_get_news(market, market)`（`fetch_financial_news(lang="all", market=market, symbol=market, name="")`）。market 形参语义应是市场代码（CNStock/HKStock…）。**待确认** `fetch_financial_news` 对非法 market 的容错行为；若它按 market 过滤数据源，板块检索会拿错源。
修复方向：`_get_news(symbol=market, market="CNStock")`，板块名走 symbol/name 通道。

### M16 | data_tools.py:730-737 vs 516-525；data_tools._strip_prefix vs signal_tools._strip_prefix | 重复实现（代码/市场前缀解析 3 份且不一致）
`_market_prefix`（6/9→sh、8→bj、其余→sz）与 `_tencent_quote_raw` 内联前缀规则（6/9/**5**→sh、8/**4**→bj、其余→sz）不一致：5 开头（沪基金/沪B）与 4 开头（北证）在 `_market_prefix` 下被错分 sz；两处各自实现，`_strip_prefix` 又在 data_tools 与 signal_tools 各包一层 `normalizer.strip_market_prefix`。
修复方向：市场前缀/剥离只留 `app.data_sources.normalizer` 一份，全部调用点改直连；补 5/4 开头的用例。

### M17 | 重复实现总账（类别 4 核心结论）| 重复实现
指标计算在**全项目 8 处**独立实现，公式/口径（如 RSI 周期、ATR 平滑、BOLL 标准差分母）无统一真源：
1. `tools/finance/analysis_tools.py`（_calc_macd/_rsi/_kdj/_boll/_atr/_mfi/_cmf/_hist_volatility/_detect_divergence）
2. `tools/finance/_analysis_utils.py`（_calc_obv）
3. `app/services/ext_params/kline_derived.py`（_calc_atr/_calc_obv）
4. `app/services/market_data_collector.py`（_calc_rsi/_calc_macd/_calc_atr_wilder/_calc_bollinger）
5. `app/utils/indicators.py`（calc_macd，另有 RSI/KDJ 等）
6. `app/watchlist/predict.py`（_ema）
7. **根目录 `QuantDinger/daily_prescan.py`**（_calc_rsi/_calc_kdj）
8. `QuantDinger/test_dragon_v2.py`（calc_macd）

其余重复面：
- K线 bar 归一化（t/o/h/l/c/v + 长键双写）：`kline_tools.py:31-44` ≈ `index_tools.py:188-198`（含 `float(o or cl)` 同款 0 值语义缺陷）
- 量比/量价关系判定：`analysis_tools.get_volume_analysis._one` ≈ 其 `_one_with_vr`(1304-1343，还二次 `_fetch_closes`) ≈ `bull_bear_research._get_volume_analysis`
- 盘中判定 `570 <= t < 900`：analysis_tools 4 处（1217/1301/1610/1627）
- 东财搜索包装：`screener_tools._em_search`（未用）/`_call_eastmoney_api` ≈ `market_cn/dragon_limit._em_search`
- 结果格式化双体系：`format_utils.format_result`（元工具）与 `_serialize`（ToolResult.to_str），两者数值格式（万/亿 vs 原值）、error 呈现、截断策略各不相同
- 腾讯实时量比（`_fetch_realtime_volume_ratio`，搜狐源）与 `_tencent_quote_raw` 的 `vol_ratio`(vals[49]) 是两个量比来源，口径未对齐

**统一接口建议**：
1. 指标计算收敛为唯一内核（建议扩展 `app/utils/indicators.py`：输入 `list[bar]`/ndarray，输出带序列的指标对象），tools 层、services 层、根目录脚本全部改调它，删 7 份副本；
2. 取数+bar 归一化收敛到 `_analysis_utils`（`fetch_bars(code, days, adj)` 一个入口），kline_tools/index_tools 只做信封；
3. 「量比/量价关系」「盘中判定」各收敛为一个 helper；
4. 前缀解析统一走 `data_sources.normalizer`；
5. 格式化二选一：`_serialize` 为唯一出口，`format_result` 要么基于它重写、要么退役。

### M18 | _em_utils.py:19,33-47 | 健壮性（限流竞态 + 静默截断 + 错误不可辨）
`_last_call` 全局变量做 1s 限流，check-sleep-set 无锁（多线程并发调用会互相穿插）；`pageNumber` 恒为 "1"、`pageSize` 默认 50，**无翻页**——`get_lockup_expiry`(15 条/20 条)、`get_dragon_tiger_detail`(50 条) 等超过即静默截断；任何异常（HTTP 错、JSON 解析错）都 `return []`，与"确实没有数据"不可区分，调用方直接当空结果用。
修复方向：限流用锁/单调时钟；封装层返回 `(rows, error)` 或抛异常让调用方决定；分页要么支持、要么在 docstring 明示上限。

### M19 | web_search_tools.py:213,421 + _unified_search 签名 | 冗余（承诺落空 + 死参数）
`_tavily_search` 注释"逗号分隔可轮换"，实际恒取 `_TAVILY_API_KEYS[0]`，多 KEY 从不轮换；`_unified_search(query, count, freshness, engines, language)` 的 `engines`/`language` 全链路未用（`_ENGINES` 循环只传 `query,count,freshness`，searxng 的 engines/language 参数永远吃默认）；缓存键 `f"{query}|{count}|{freshness}"` 也因此与这两个参数脱钩。
修复方向：要么实现轮换/引擎过滤，要么删参数与注释，不要留"看起来支持"的接口。

---

## 四、低严重度（12 组）

### L1 | _fn_adapter.py:24-27；tool_discovery.py:25-27 | 死分支
两处 `try: from ._base import ... except ImportError: from ._base import ...` —— 两个分支**完全相同**，fallback 是死代码（历史迁移遗留）。要么删 try，要么把 fallback 改成真正不同的导入路径并注明适用场景。

### L2 | _base.py:166 | 潜伏错误（写法与注释声称相反）
```python
parameters: dict = field(default_factory=dict)   # Tool 是普通 ABC，不是 dataclass
```
非 dataclass 类里这就是一个 `dataclasses.Field` 对象当类属性；子类不覆盖 `parameters` 时 `self.parameters or {...}` 取到 truthy 的 Field 实例 → schema 错。注释声称已修掉旧的 `if False else {}` 写法，实际换了个坑。目前全项目没有 `Tool` 子类（`Tool`/`safe_execute`/`get_function_schema` 均无消费方，近乎死代码），风险未爆。修复：`parameters: dict = {}`（类属性字典只读约定）或干脆删掉未使用的 ABC。

### L3 | 死代码清单 | 死代码
- `analysis_tools.py:32` `_sma` —— 全项目零引用
- `chip_distribution.py:162` `_format_chip_markdown` —— 零引用
- `sector_analysis_tools.py:77` `_merge_em_rows` —— 零引用（`get_hot_sectors` 已改不富化，函数留滞）
- `screener_tools.py:24` `_em_search` —— 零引用
- `bull_bear_research.py:516/659` `_analyze_pattern`、`_get_chip_distribution` —— 模块内无调用者
- `news_search_tools.py:16-17` `_search_cache`/`_CACHE_TTL` —— 声明了缓存但从未读写（注释"60s 内直接返回"未实现）
- `analysis_tools.py:2126` 尾注释"── OpenAI tool declarations ──"下无内容（遗留空段落）
- 未使用 import：`json`（fund_flow/dragon/news/trading）、`_to_md`（fund_flow/dragon/news/trading/backtest）、`search_policy_intel`（bull_bear:15）、`concentration` 变量（technical_analysis:191 取后未用）、`Optional/List`（trading_tools）
- `indicator_tools.py:52-58` `_list_indicators_impl` 连续两个 docstring（第二个是无作用字符串表达式）
- `data_tools.py:857-867` `_get_financial_statements` 内 `import requests` 与 `_UA` 重复定义两遍，`symbol = f"{prefix}{code}"`(860) 计算后从未使用
- `data_tools.py:370` `except (NotImplementedError, Exception)` —— Exception 已覆盖，元组冗余

### L4 | memory_tools.py:59；_serialize.py:32 | 边界值
`recall(count=0)` → `items[-0:]` 即 `items[:]`，返回全部条数（与 count 语义相反）；count 无上限校验。`_scalar` 对 NaN/Inf 的 `int(v)` 会抛 ValueError/OverflowError → `ToolResult.to_str()` 崩（金融计算产出 NaN 并不罕见，`_safe_round` 防了 NaN 但序列化层没防）。
修复：`items[-count:] if count else []`；`_scalar` 先 `math.isfinite` 判定。

### L5 | analysis_tools.py:1490,1505；_analysis_utils.py:107-109 | 边界/窗口
上升/下降三法用**当日** `candle_range`（最后一根K线振幅）作为第一根K线实体的"大"判据——窗口错位，应比较首根自身或区间内均幅；`_calc_obv` 的 `obv_slope == 0` 判为"下降"（应有"走平"）；`_calc_atr` 的 `atr_recent` 在 `len(tr_list)-5 < period` 时取不满 5 点，趋势判定样本不足仍给"扩大/收缩"。

### L6 | data_tools.py:751；495-498 | 边界值/冗余
`_get_margin_trading` 的 `if len(data) > 5 else rz_latest` 是 off-by-one（恰 5 条时 `data[4]` 存在却取不到，5 日变化恒 0）；`get_stock_info` 单码路径的 `_NUM_KEYS` 含 `"market_cn"` 做 float 强转（市场名字符串，永远转失败走 pass，白试）。

### L7 | _provider.py:443,245,435-447 | 冗余/注释失实
`search()` 降级分支注释"2~4 字滑窗"实际只做 3-gram（`w[i:i+3]`）；`terms = list({w[i:i+3] ...})` set→list 顺序不稳定（结果排序随之抖动）；`except NameError`（245）兜底不可能触发（`_TOOL_MODULE_IMPORT_FAILURES` 是模块级定义）；两段匹配循环各自重复计算 `inspect.getdoc` 截断串。

### L8 | signal_tools.py:86-105 等 | 冗余
`get_hot_stocks_with_reason` 先为每行构造 8 字段 dict（close/turnover/amount/dde_net 等）再重建 4 字段 compact 列表，前一半字段白算（注释自认"精简字段"，但没删上游构造）；`import json`（dragon_tools:8 等）未用（见 L3）。

### L9 | web_search_tools.py:88-108,300-340 | 健壮性（低）
`_deduplicate` 用 `标题归一化|域名` 做键：空标题 + 同域名的两条不同结果会被误合并；`_filter_by_date` 对解析不了的日期一律保留（有意保守，注释已写）；`_search_cache` 无锁（CPython GIL 下基本无害，注明即可）。

### L10 | screener_tools.get_screener_presets + _screener_config.py | 维护性
筛选条件清单在 `_screener_config.py`、`get_screener_presets` 的展示字典、前端 `FilterPanel.vue` 三处人工同步（文件头注释自认"与前端完全一致"但无任何一致性校验）。建议加一条契约测试比对三处键集合。

### L11 | technical_analysis.py:288 | 冗余（小）
`md = f"{stock_code}({stock_code}) ..."` 同一代码打印两遍（疑似原本想放股票名）；`factors[:4]`/`signals[:3]`/`signals[:5]` 多处魔法截断数不一致（无碍，建议常量化）。

### L12 | 待确认项汇总
- `capability_tools.call_capability`：`for mod_path, fn_name, timeout_s, max_chars in (loader.load_admitted() or [])` 假定 admission 行是 4 元组，若 loader 返回 dict 会未捕获解包异常（需对照 `capabilities/loader.load_admitted` 的真实返回）。
- `indicator_tools` 批量执行 `safe_exec_with_validation(timeout=30)` 每指标一次、`_evaluate_indicator` 对同一指标跑 `analyze_indicator` + `run_indicator_signal` **两次沙箱执行**（冗余 + 慢，依赖 H1 修复后确认）。
- `index_tools._has_good` 用 `price > 10` 判"真价"，而头注释说脏数据特征恰是"假价 11.3"——阈值与案例矛盾，真实区分逻辑存疑。
- `_schema_gen._python_type_to_json` 不识别 PEP 604 联合（`int | None` 会退化成 "string"）；`origin is type(None)` 分支实际不可达。当前工具签名未用 `X | None`，暂无实际影响。

---

## 五、整体评价

**架构层面**：tools 层的分层设计（`_base→_provider→_schema_gen→_serialize` 单向依赖、目录即契约的扫描注册、元工具/注册表两通道、`_SUPERSEDED_BY_MERGE` 摘名留实现）是清晰且有大量事故复盘注释支撑的，注册面静态核对干净：**无跨模块同名覆盖、摘除表 20 条全部对得上实现**。真正的问题不在"注册"，而在**注册之后的工具函数体内部**：

1. **同功能多实现是本目录最大的债**。指标计算全项目 8 份、K线 bar 归一化 2 份、量比/量价判定 3 份、盘中判定 4 处、市场前缀解析 3 份、结果格式化 2 套。`technical_analysis`、`bull_bear_research` 本质是 analysis_tools 的两个"聚合视图"，却各自演化出不同的字段名（rsi6/macd_hist/turnover_rate/vol_trend 递增vs上升）、不同的 RSI 评分方向、不同的输出信封——本次 6 个高危里有 2 个（H5/H6）纯粹是这种漂移的产物。**建议把「指标内核 + 取数 + 字段契约」抽成 finance/ 内的单一底座（类似 chip_distribution 已经做的"数学进 services、tools 只组装"），聚合层只准组装、不准重算、不准自造键名，并给 Returns 契约加测试**。

2. **死代码与半成品在积累**：`_pagination.py` 整个 444 行模块（含嵌套错位的 `page_tool` + 未导入的 `reg_tool`）、bull_bear 的 4 份内联副本与其注释声明相反、`_sma`/`_merge_em_rows`/`_format_chip_markdown`/`_em_search`/`_search_cache` 等零引用件、多处空的 "OpenAI tool declarations" 段落。它们不只是占地方：H3/H4/H6 这类"条件恒 False / 键名对不上"的**活死代码**（写在执行路径上但永不生效）比纯死代码更危险——功能看起来存在，实际从不工作，且无报错。

3. **健壮性总体中上**：超时大多有（requests timeout、ThreadPoolExecutor 竞赛、子进程击杀），错误也基本不裸吞；但「失败=空结果」的软失败模式（em_datacenter 返回 []、`_board_name_cache` 负缓存、adj 转换回退谎报、dragon 日期倒挂返回空）会让下游把"取数失败"当"无数据"用，金融场景里这比抛错更糟。建议统一「空结果 vs 失败」的可辨识信封（项目已有 `{"error":..., "retriable":...}` 约定，缺的是把它当纪律执行）。

4. **安全/权限**：`get_strategy_trades` 的用户归属校验缺失（M4）是本目录唯一的越权面，建议顺手做一次"所有带 user_id 的工具是否都过归属校验"的专项核对。

问题统计：**高 6 / 中 19 / 低 12 组（约 30+ 条目）**；其中类别分布：逻辑错误 ≈ 15、冗余 ≈ 10、死代码 ≈ 8、重复实现 ≈ 8 组、健壮性 ≈ 12。
