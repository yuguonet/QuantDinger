# QuantDinger agent 核心 + 调度 代码审查报告

- 审查对象：`QuantDinger/backend_api_python/app/agent/` 顶层核心 + `capabilities/` + `preselect/` + `cron/` + `audit/` + `scripts/`
- 审查方式：只读（未修改任何项目文件；未执行任何 git 命令）
- 日期：2026-10-13 · 委派方：主会话 · 审查人：review_core 子代理
- 结论概要：**已审 41 个文件（全部覆盖），共 47 项问题（高 6 / 中 21 / 低 20）**

---

## 一、审查覆盖清单

| 文件 | 行数 | 已审 | 备注 |
|---|---|---|---|
| agent.py | 365 | ✅ | 全文 |
| cli.py | 307 | ✅ | 全文 |
| constants.py | 50 | ✅ | 全文 |
| domain_registry.py | 246 | ✅ | 全文 |
| flask_app.py | 288 | ✅ | 全文 |
| llm.py | 317 | ✅ | 全文 |
| log.py | 72 | ✅ | 全文 |
| message_queue.py | 237 | ✅ | 全文 |
| mimo_boot.py | 65 | ✅ | 全文 |
| modpath.py | 78 | ✅ | 全文 |
| qd_aftercare.py | 233 | ✅ | 全文 |
| qd_agent.py | 313 | ✅ | 全文 |
| qd_budgeting.py | 60 | ✅ | 全文 |
| qd_config.py | 259 | ✅ | 全文 |
| qd_grounding.py | 46 | ✅ | 全文 |
| qd_guards.py | 92 | ✅ | 全文 |
| qd_hooks.py | 68 | ✅ | 全文 |
| qd_preselect.py | 290 | ✅ | 全文 |
| qd_service.py | 515 | ✅ | 全文 |
| qd_tool_face.py | 325 | ✅ | 全文 |
| skills_adapter.py | 471 | ✅ | 全文 |
| trace_collector.py | 506 | ✅ | 全文 |
| capabilities/__init__.py | 21 | ✅ | 全文 |
| capabilities/func_overlap.py | 303 | ✅ | 全文 |
| capabilities/loader.py | 315 | ✅ | 全文 |
| capabilities/scanner.py | 231 | ✅ | 全文 |
| preselect/__init__.py | 67 | ✅ | 全文 |
| preselect/preselect_cooc.py | 503 | ✅ | 全文 |
| preselect/preselect_stats.py | 206 | ✅ | 全文 |
| preselect/tool_preselect.py | 853 | ✅ | 全文 |
| cron/__init__.py | 13 | ✅ | 全文 |
| cron/cron_tools.py | 353 | ✅ | 全文 |
| cron/cron_worker.py | 468 | ✅ | 全文 |
| cron/guards.py | 135 | ✅ | 全文 |
| audit/__init__.py | 1 | ✅ | 全文 |
| audit/trace_adapter.py | 105 | ✅ | 全文 |
| scripts/qd_bench.py | 633 | ✅ | 全文 |
| scripts/qd_dispatch_ab.py | 306 | ✅ | 全文 |
| scripts/qd_prompt_eval.py | 477 | ✅ | 全文 |
| scripts/qd_smoke.py | 2518 | ✅ | 主体全文 + 尾部（test_28~40）抽样/结构审 |
| scripts/skill_run.py | 119 | ✅ | 全文 |
| scripts/weekly_panel.py | 92 | ✅ | 全文 |

合计 12,922 行。死代码/重复实现判定辅以全仓 grep 引用核查（结论中给出）。

---

## 二、高严重度

### H1 · message_queue.py:150-237 + cli.py:118-124 | 逻辑错误/并发
**问题**：worker 使用手工创建的 `Future()`，从不调用 `set_running_or_notify_cancel()`，Future 永远停在 PENDING 态 ⇒ 运行中的任务也可被 `cancel()` 成功（cli 超时分支就会 cancel）。随后 worker 调 `set_result` 抛 `InvalidStateError`，进入 except 分支后 `future.set_exception(e)` 对已取消 Future **再次抛 InvalidStateError 且无人捕获** ⇒ `_worker_loop` 线程永久死亡。每触发一次就永久少一个 worker（4 次后队列只能靠 submit 的 5s 满载报错）。
**证据**：
```python
resp = loop.run_until_complete(asyncio.wait_for(_run_with_events(), timeout=task["timeout"]))
future.set_result(resp.content or "")        # ← future 已被 cancel 时抛 InvalidStateError
...
future.set_exception(e)                      # ← except 块内二次抛，杀死 worker 线程
```
**修复方向（根因）**：worker 取出任务后立刻 `if not future.set_running_or_notify_cancel(): continue`（让 cancel 对运行中任务返回 False）；所有 `set_*` 前先判终态。禁止在 except 内对不可写 Future 再写。

### H2 · message_queue.py:205-215 + qd_hooks.py | 逻辑错误/生命周期
**问题**：`asyncio.wait_for` 超时只放弃等待，`to_thread` 里的 `_run_sync` 仍在跑（本仓注释自己写明"杀不掉线程"）；但 `finally: unregister_run_hooks(_sid)` 已把该会话的 probes/step_checks/event_cb 注销 ⇒ 孤儿 run 的中断探针全部失效：`request_stop`（Web /stop、CLI Ctrl+C）对它**完全无效**，它会继续烧 token、继续写记忆/决策库。
**证据**：
```python
resp = loop.run_until_complete(asyncio.wait_for(_run_with_events(), timeout=task["timeout"]))
...
finally:
    _ta_mod.unregister_run_hooks(_sid)   # ← 孤儿线程还在跑，钩子已被拔掉
```
**修复方向**：超时/取消必须传递到线程边界——超时即置停止位（`request_stop(session_id)`）并保留钩子直到线程真正结束；或将 agent 一轮执行改为可协作中止的 Task 抽象（stop-generation 代际计数）。

### H3 · cli.py:155、185 | 逻辑错误（功能性 Bug）
**问题**：`_import_agent()` 返回 4 元组，但 `_print_info()` / `_list_skills()` 按 5 个名字解包 ⇒ `--info` 与 `--list-skills` 必然 `ValueError: not enough values to unpack`，CLI 两个子命令全坏。
**证据**：
```python
return agent, settings, skills, DEFAULT_SESSION_ID        # 4 个
_, settings, skills, _, _ = _import_agent()               # 5 个 ← 崩
_, _, skills, _, _ = _import_agent()                      # 5 个 ← 崩
```
**修复方向**：`_import_agent` 返回 NamedTuple（或统一解包形态），并在 qd_smoke 增加"CLI 三个子命令可执行"的断言（当前 smoke 未覆盖 cli.py）。

### H4 · cron_worker.py:161-215 | 逻辑错误（错误调度）
**问题**：两处调度语义错误，都会造成**真实执行**：
1. `_next_cron_single` 的"每天固定时间"分支（`parts[1] != "*"`）只查时/分/星期，**不查月份**（也不查日）⇒ `"0 9 * 1 *"`（仅 1 月）变成全年每天 9:00 触发；
2. 解析失败/永不匹配（如 `0 0 31 2 *`）一律回退 `after + 1min/1day`，而 Timer 到点**无条件执行任务** ⇒ 一个无效 cron 表达式 = 每分钟（或每天）真实跑一遍 agent 任务。
**证据**：
```python
return _next_cron_single(cron_expr.strip(), after, max_search_days) or (after + timedelta(minutes=1))
...
if dt.hour in hours_f and dt.minute in minutes_f and py_wday in weekdays_f:   # 无月份/日期校验
    return dt
```
**修复方向**：`next_cron_time` 对"不存在的触发点"必须返回"永不调度"语义（而不是 +1min）；三类分支（月/日/分钟）字段校验保持全量一致；到点执行前再做一次 `cron_matches` 级别的时间复核。

### H5 · flask_app.py:274-276 | 健壮性/安全（越权停止）
**问题**：`/stop` 把**未加命名空间前缀**的 session_id 原样投递 `request_stop`。而 chat/task 的会话键形如 `user:<id>:<sid>`，任何调用方（含匿名，`_resolve_user_ns` 失败即 `anon:<ip>`）只要直接传别人的完整键 `"user:2:xxx"` 就能停掉他人任务；传 cron 共享键还能停掉定时任务。所谓"兼容前端两种情形"实际是把鉴权键与原始键混用。
**证据**：
```python
request_stop(session_id)                           # 原样（前端已带命名空间）← 越权入口
request_stop(f"{_resolve_user_ns()}:{session_id}") # 补前缀
```
**修复方向**：停止指令只接受"本人命名空间 + 本地 sid"（服务端拼键），或校验传入键的 `user:<id>` 前缀与 token 一致后才放行；`request_stop` 增加调用来源校验而不是幂等盲收。[待确认：是否有 app 级鉴权中间件覆盖该路由，但即便有，用户间互停仍成立]

### H6 · log.py:17-72 | 健壮性/日志泄露（脱敏控制失效）
**问题**：`_MaskFilter` 挂在 `logging.getLogger("app.agent")` 上，但 Python logging 的 **logger filter 只对该 logger 直接发出的记录生效**，子 logger（`logging.getLogger(__name__)`）传播到父级时不经过父 logger 的 filter。全包几乎都是后者（grep 仅 `trace_collector.py` 用 `from .log import logger`）⇒ 文件头承诺的"输出经 MASK 脱敏（常设 6）"实际覆盖不到 5%，api_key/手机号等照旧进 `logs/app.log`。另外 docstring 宣称支持的 `from log import logger` 裸名用法全仓零使用（且真那么用会因 `.utils.mask` 相对导入失败而静默不脱敏）。
**证据**：
```python
logger = logging.getLogger("app.agent")
logger.addFilter(_MaskFilter())      # ← 子 logger 的记录不走这里
```
**修复方向**：脱敏挂到 handler 层（`RotatingFileHandler.addFilter` / StreamHandler）或 root logger；顺带删除失效的裸名导入承诺。安全控制必须在唯一汇聚点生效，不能指望调用方自觉。

---

## 三、中严重度

### M1 · message_queue.py:216-237 + cli.py:96-125 | 逻辑错误
任务级超时异常（3.11+ `asyncio.TimeoutError` 与 `concurrent.futures.TimeoutError` 同为内建 `TimeoutError`）会从 `future.result(0.5)` 抛出，被 `except concurrent_futures_timeout.TimeoutError: pass` 当成"轮询超时"⇒ 已失败的任务被空转轮询到 deadline 才收尾（且文案误报"超过 Ns 未完成"）。证据：`content = future.result(timeout=0.5) / except concurrent_futures_timeout.TimeoutError: pass`。修复：轮询前先 `if future.done(): future.result()` 直接取终态，区分"等待超时"与"future 携带异常"。

### M2 · message_queue.py:86-92, 157 | 并发
`clear_stop` 在任务开跑瞬间清停止位：用户在任务**入队后、开跑前**（队列积压时常见）发出的停止请求被静默吞掉。证据：`clear_stop(str(task["session_id"]))  # 新任务开始，清掉残留停止位`。修复：停止位带"预约"语义（按 session+代际计数或入队时间比较），任务开始只清"上一代"的位。

### M3 · qd_service.py:306、381 | 并发/生命周期
worker 线程内每条消息 `asyncio.run(...)` 2~3 次（memory.get_history / retriever.retrieve / memory.add ×2），每次新建再销毁 event loop；PostgresMemory(asyncpg) 连接池绑定旧 loop 会反复报 "Event loop is closed / attached to a different loop"，被 fail-open 吞成 debug 日志 ⇒ postgres 记忆/RAG 可能长期静默失效。证据：`hist = asyncio.run(self.memory.get_history(session_id, limit=6))`。修复：memory/retriever 提供同步接口或专用常驻 loop；fail-open 分支升级为 warning + 计数。[待确认：memory/ 包内部 async 实现]

### M4 · qd_service.py:226-241 vs llm.py:159-206 vs agent.py:33-35 | 同功能重复实现 ★
主对话模型经 `_build_default_model` 直读 `OPENAI_MODEL/OPENAI_BASE_URL/OPENAI_API_KEY` 构建；而 chain/c3p/resolver/skill_brewer/func_overlap/skills.base 走 `app.agent.llm.resolve_provider`（`LLM_PROVIDER` → 自动探测 → `AGENT_LLM_MODEL` → 按 provider key）。两套解析优先级不同 ⇒ 主对话与工具闭环/酿造可能跑在**不同模型不同端点**上，llm.py 头部"agent 链路唯一出口"的定调名不副实。证据：
```python
return get_model(config={"model_name": os.getenv("OPENAI_MODEL", "qwen-plus"), ...})   # qd_service
name = (provider or _env("LLM_PROVIDER")).lower() ... or _env("AGENT_LLM_MODEL") ...   # llm.py
```
修复方向：`_build_default_model` 改为 `llm.get_model()` 的薄包装；env 解析收敛到单一模块（constants 或 llm），`agent.py settings.llm` 从同一来源渲染。**统一接口建议**：`resolve_provider()` 为唯一配置事实源，所有建模点（服务主链、chain 轻调、func_overlap、skills）只允许经它取 spec。

### M5 · cron_worker.py:94-114 vs cron/guards.py:55-93 | 同功能重复实现 ★
两套 cron 字段解析器且行为已漂移：`guards._expand_field` 支持 `5/10`（起点/步长）、`parse_cron_fields` 还做字符白名单校验；`cron_worker._parse_cron_field` 对 `5/10` 落到 `int(part)` 直接 ValueError ⇒ guard 放行的表达式在 `_reschedule_job` 中抛异常被吞，任务**静默永久停摆**。证据：
```python
else: values.add(int(part))                              # cron_worker：5/10 → ValueError
acc.update(range(int(seg), hi+1, step) if step > 1 else [int(seg)])   # guards：支持
```
修复方向：抽单一 `cronspec` 模块（parse / validate / next_time 三函数同源），guards 与 worker 都消费它；顺带消除第三份语义（见 L3 `cron_matches`）。

### M6 · cron_tools.py:150-181 | 健壮性
F6 防滥用闸整段 fail-open：DB 计数失败 `_exist = 0`（任务数上限失守），外层 `except Exception: pass` 吞掉一切 guard 异常 ⇒ 闸门可被静默绕过。证据：`except Exception: _exist = 0` / `except Exception: pass`。修复：guard 是防滥用面，取数失败按"未知=拒绝/告警"处理（fail-closed），异常必须落 warning。

### M7 · cron_worker.py:413-433 | 健壮性/失败恢复
`_load_and_schedule_all` 仅在启动后 sleep(10s) 跑一次，失败仅记日志、无重试 ⇒ 启动期 DB 抖一下，整个进程生命周期内定时任务子系统静默失效（C-1 型故障：不崩、不报、功能消失）。修复：加载失败退避重试 + 健康状态暴露（`get_scheduled_jobs` 旁加 loaded/retry 状态）。

### M8 · cron_worker.py:242 vs 288-291 | 逻辑不一致
一次性任务：prompt 模式"先删后执行"（注释：防崩溃重复触发），function 模式却"先执行后 finally 删" ⇒ 进程中途崩溃时 function 一次性任务会重复触发，与注释语义相反。修复：两种模式统一崩溃语义（建议先标记 running/先删，按"宁少勿重"定调）。

### M9 · cron_worker.py:248-249 | 逻辑错误/恢复
prompt 任务 `future.result(timeout=300)` 超时后只标记失败，队列侧 agent run 继续执行且不可停（与 H2 叠加）；同时 timeout=300 硬编码与 CLI/task 的 900 不一致。修复：超时即 `request_stop(session)`；超时口径收进配置单一来源。

### M10 · cron_worker.py:248、331、419 | 逻辑错误（待确认）
`_execute_prompt_job` 用 `job.get("session_id", "default")`，但两处 SELECT 列表（`id,name,cron_expr,mode,prompt,function_path,enabled[,one_shot]`）**都不含 session_id** ⇒ 恒为 "default"，所有定时任务共享同一会话记忆上下文（互相污染）。修复：SELECT 显式取会话列；若"共享会话"是设计，写进文档并在任务卡片标注。[待确认：表结构是否有 session_id 列]

### M11 · audit/trace_adapter.py:67-90 | 逻辑/冗余
`on_step` 每步对 `msgs[-8:]` 全量摘录并 emit ⇒ 相邻步重复落同一 tool_call/tool_result 事件（JSONL 重复、复盘步数对不齐）。证据：`for msg in msgs[-8:]: ... self.emit("tool_call", ...)`。修复：按消息游标只发增量（qd_prompt_eval `_tools_since` 已是正确范式，可复用）。

### M12 · trace_collector.py:146-161、500-506 | 死代码/语义退化
① `begin_skill/end_skill` 全仓零调用（planner 随 nodes.py 退役）⇒ skill 层树恒空、`plan_digest()` 永远只返回单个 `_orphan` 段，案例记忆的"阶段+工具链"签名退化成平面工具名列表；② `_extract_confidence_from_text` 抽不到仍 `return 0.5` —— 同一文件头刚记录"confidence 88% 默认 0.5 毒化校准曲线"，又把 0.5 默认写库。修复：删 skill 层或恢复驱动源；confidence 缺失写 `None`（与 chain/claims "绝不填 0.5" 纪律对齐）。

### M13 · utils/tracing.py（AgentTraceRecorder，约 308-506 行）| 死代码 ★
旧 smolagents 链路写入侧，全仓零实例化（仅 `utils/__init__.py` re-export 与 trace_collector 注释提及）；真正在用的只有 `_repro_meta`（chain/evidence.py:154）。trace_collector 头注释"两条链并存，改任一侧都要回读另一侧"已失准（另一条链无人调用）。**三层 trace 现状**：utils/tracing（死）+ audit/trace_adapter（JSONL 事件）+ trace_collector（DB 树），事件语义（tool_call/run_start/run_finish）双写。修复：AgentTraceRecorder 归档到 del/，`_repro_meta` 迁至 utils/mask 同级的小模块；事件语义收敛为"采集一次、双出口落盘"。

### M14 · agent.py:326-356 | 死代码/执行双轨
`run_agent` 全仓零调用（仅文档提及"对外契约"）；若被外部使用，它绕过 message_queue：独立 event loop、不 register hooks（无 event_cb/probe）、不经停止机制 ⇒ 与 MQ 形成第二执行通道。修复：删除，或实现为 `submit()` 的包装（唯一执行通道），文档同步。

### M15 · flask_app.py:109、128-133 | 健壮性
SSE 硬超时分支直接 `return`：不 cancel future、不 request_stop ⇒ 判定为"卡死"的 worker 继续跑、event_cb 继续往**无界** `ev_queue` 塞事件（无人消费，内存增长到 run 结束）。证据：`if _time.monotonic() - _t0 > _hard_limit: ... return`。修复：收尾必须发停止信号；ev_queue 有界 + 弃帧计数。

### M16 · agent.py:36-48 | 健壮性（配置未校验）
`float(os.getenv("AGENT_LLM_TEMPERATURE"))`、`int(_seed_env)`、`int(os.getenv("QD_STEP_SCALE","3"))`、`int(os.getenv("OPENAI_MAX_TOKENS"))` 均无容错 ⇒ 一处配置写错 = import 期 ValueError，整进程起不来且报错指向代码行。constants.py 的 `get_agent_max_steps` 已示范正确范式（降级+告警）。修复：所有 env 解析收敛到 constants 的 `get_*` 一族，非法值降级默认并 warning（AGENT_ENV_KEYS 声明清单目前零消费，可作对账入口）。

### M17 · capabilities/loader.py:96-99 | 逻辑
`near_dup_tool_names` 规则 4「前两段 token 相同即等价」过宽：`get_market_overview` vs `get_market_fund_flow`、`get_stock_info` vs `get_stock_profile` 均判同功能 ⇒ 能力层在"域内其实没有覆盖"时也被误让位（三级兜底被自己裁掉）。证据：`if len(pa) >= 2 and len(pb) >= 2 and pa[0] == pb[0] and pa[1] == pb[1]: return True`。修复：规则 4 限定后缀模式词（`_DUP_SUFFIXES`/`_mode_tokens`）才判等价，或改走 func_overlap 的文档语义判据。

### M18 · capabilities/func_overlap.py:285-302 | 逻辑
缓存指纹不含 use_llm/LLM 可用性：LLM 不可用时 unsure 全判 "different" 的**降级结果被持久化**（overlap_cache.json），LLM 恢复后也不重算，直到工具面指纹变化。证据：`if cached and cached.get("fingerprint") == fp: return cached["report"]`（`used_llm` 存了但不参与失效判定）。修复：缓存键并入 used_llm，或降级结果不落盘只存内存。

### M19 · qd_hooks.py:48-52 + message_queue.py:205-215 | 并发
同一 session_id 并发两个 run 时，`register_run_hooks` 互相覆盖表项，先结束者 `unregister_run_hooks` 把后跑者的钩子删掉 ⇒ probes/event_cb 静默消失（停止失效、SSE 断流）。docstring 承认"同一 session_id 可能并发"但只修了线程绑定。修复：钩子表按 run 代际（run_id）登记，session → [runs] 一对多，注销只删自己那代。

### M20 · flask_app.py:230 vs 252 | 一致性
`/chat` timeout=120，`/task` 与 CLI 均 900；chat 场景的多任务答复同样会被 120s 截断（文件内注释自己承认 300s 都常截断）。修复：超时按场景进配置（单一来源），前端可见剩余预算。

### M21 · qd_service.py:260-263 | 健壮性（资源）
`_sessions` / `_skill_seen` 无上限无淘汰；匿名会话每请求新建 uuid ⇒ 每个 uuid 一个 QDAgent（整套 registry 快照+激活态），长进程内存单调增长。修复：会话 LRU/TTL + 上限，淘汰时释放 agent 引用。

---

## 四、低严重度

| # | 位置 | 类别 | 问题 | 证据 | 修复方向 |
|---|---|---|---|---|---|
| L1 | qd_grounding.py:37-43 | 冗余/死代码 | 双层 `except ImportError` 重复同一 import，第二层永不产生不同结果 | `except ImportError:\n try: from .utils.grounding import check_grounding` | 删一层 |
| L2 | cli.py:112-114、72-91、240-276 | 冗余 | `if not _stop_asked: pass` 空分支；`_future_sink`/`_active_future` 只 append/clear 从不读（注释称供 SIGINT 取消，实际 `_force_exit` 只调 request_stop） | `_active_future.clear()` / `_future_sink.append(future)` | 删死参数/死变量，或真用它做取消 |
| L3 | cron_worker.py:116-143 | 死代码 | `cron_matches` 全仓零调用，且是第三份 cron 语义实现 | grep 无调用方 | 删或改造成 H4 需要的"执行前时间复核" |
| L4 | cron/guards.py:132-135 | 死代码/断头接口 | `seconds_delay_to_at` 零调用；其产物 `"+{s}s"` `_parse_at_time` 根本不认 ⇒ B7「秒级延迟不漂移到明天」在工具层未实现 | `return f"+{s}s"` vs `_parse_at_time` 无对应分支 | 实现 at 的相对偏移解析并接线，或删除 |
| L5 | preselect/tool_preselect.py:606 | 逻辑 | parse_selection 兜底用 `n in body` 子串匹配（无词边界；`names_in_text` 是有边界的正确版），长名含短名会多选 | `raw_items = [n for n in valid_names if n and n in body]` | 复用 `names_in_text` |
| L6 | preselect/tool_preselect.py:565-580 | 逻辑/观测 | R4 中 `remain < MIN_FACE` 且非 R4b 时既不裁也不记 warning（静默无动作），与"三步"描述不符 | `elif remain >= MIN_FACE:` 无 else | 补一条"保守跳过裁剪"warning 进 LintReport |
| L7 | capabilities/scanner.py:160-166 | 逻辑 | write 前缀且 admitted 的条目 status=admitted 但 category=excluded，loader 又硬拒 ⇒ 报告与注册行为矛盾 | `status=("admitted" if key in admitted else ...)` | admitted 判定先过 `is_write_name` 排除 |
| L8 | capabilities/loader.py:120-165 | 冗余 | `load_admitted` 与 `load_admitted_meta` 重复解析 admission.json，register_capabilities 读两遍（两遍间不一致可能） | 两个函数各 `json.loads(path.read_text(...))` | 合并为一次解析返回统一记录 |
| L9 | capabilities/func_overlap.py:46-55、263 | 冗余 | `_sig_text` 收集的签名在判定里从未使用（code_judge_pair 注释说"签名同形"，实现只看名字+文档词） | `out.append({... "sig": _sig_text(fn)})` | 要么用于判定，要么删 |
| L10 | scripts/qd_bench.py:161-164、373-380 | 逻辑 | validate_tasks 拒绝 dims 含 "human"，但 DIM_WEIGHTS/score_answer 支持 human 标注维度（文档也这么写）；`cmd_run` 用全量 `load_tasks()` 打分，`--only` 时其余任务记 missing、n_total 失真 | `if d not in DIM_WEIGHTS or d == "human"` | 校验规则与评分口径对齐；--only 时只对跑过的任务打分 |
| L11 | scripts/qd_dispatch_ab.py:152 | 死代码 | `run_experiment` 内 `import qd_bench as B` 未使用 | 函数体无 B 引用 | 删 |
| L12 | scripts/weekly_panel.py:28-33 等 | 冗余 | 注释 A 说"不插 app/agent/"、注释 B 又说"_AGENT_DIR 必须更靠前"，代码两个都插（自相矛盾）；sys.path 引导在 cli/weekly_panel/qd_bench/qd_dispatch_ab/qd_prompt_eval/skill_run/scanner 复制了 7 份 | `for _p in (str(_BACKEND_ROOT), str(_AGENT_DIR))` | 抽 `scripts/_bootstrap.py` 单一实现，注释统一 |
| L13 | skills_adapter.py:224 | 冗余 | `_scan_python` 跳过名单 ("base","registry","call_skill_tool") 是 P9 刚批判过的 `_NOT_TOOLS` 同款手工名单 | `if module_name.startswith("_") or module_name in ("base", ...)` | 改为约定式（下划线/`__all__`）或集中常量并加 smoke 断言 |
| L14 | message_queue.py:148-151、96-107 | 冗余 | 毒丸 `task is None` 分支无人投毒（无优雅关停路径）；`init_workers` 的 `_workers_started` 检查无锁，双线程调用可能双份 worker | `if task is None: break` / `if _workers_started: return` | 实现真关停（投毒）或删分支；init 加锁 |
| L15 | cron_worker.py:64 | 冗余 | `_publish` 中 `dead = []` 未使用（清理残留） | `dead = []` | 删 |
| L16 | cron_worker.py:281-283 | 健壮性 | prompt 任务完成后 `print(f"...You> ")` 是 CLI 交互残留，服务部署下污染 stdout/日志 | `print(f"\n [{now}] {content}\nYou> ", ...)` | 移除或降为 logger.debug |
| L17 | qd_guards.py:32-38 | 健壮性（误伤） | `_DENY_PATH_RE` 含裸 `credentials`/`private[_-]?key` 子串，正常分析文件名（"credentials_flow.py"）会被误拒；deny 文案回显完整路径给模型 | `|credentials|private[_-]?key)` | 锚定路径形态（如 `/credentials`、扩展名白名单）；路径回显截断 |
| L18 | domain_registry.py:138-142 | 逻辑（待确认） | `strip_entity` 的 `\d{4,6}` 会把年份/期数（2026、12345）当实体码剥掉，链名归一可能误合并不同任务 | `_ENTITY_RUN_RE = re.compile(r"(?<!\d)\d{4,6}(?!\d)")` | 区分证券码形态（6 位且前导 0/3/6/8/9）与年份；或仅剥"段=纯数字码"的情况。[待确认：是否有意为之] |
| L19 | audit/trace_adapter.py:80-86 | 健壮性 | `emit` 每事件 open/append/close 无锁，多会话并发写同一 qd_agent_runs.jsonl 依赖单次 write 原子性（大事件可能交错） | `with open(self.path, "a", ...) as f: f.write(...)` | 进程内锁或按 run 分文件 |
| L20 | scripts/qd_smoke.py（test_36/37） | 低 | smoke 对 qd_bench/qd_dispatch_ab 做了大量白盒断言（源码文本匹配、内部函数直调），脆弱度高：重构即碎，且 test_32 无超阈值技能时静默"跳过判据"仍计 PASS | `check("存在超阈值技能（无则跳过本项判据）", True, ...)` | 跳过项应记 SKIP 而非 PASS |

---

## 五、任务点名的"同功能多实现"专项结论（类别 4）

| 怀疑对 | 结论 |
|---|---|
| qd_preselect.py vs preselect/ | **不是重复**：qd_preselect 是 run 前编排门面（mixin），preselect/ 是纯函数管线，分工清晰、无双实现。质量最好的一对。 |
| qd_guards.py vs cron/guards.py | **不是重复**：一个是执行面 deny（危险命令/凭据路径），一个是调度面防滥用（cron 校验/限额），职责不同。真正的重复在 **cron_worker._parse_cron_field vs cron/guards._expand_field**（M5）。 |
| skills_adapter.py vs capabilities/ | **不是重复**：技能=方法论文档+执行型入口，能力层=准入取数函数。小瑕疵是 skills_adapter 的手工跳过名单（L13）。 |
| utils/tracing.py vs trace_collector.py vs audit/trace_adapter.py | **确有重复 + 死代码**：三层并存，utils/tracing.AgentTraceRecorder 全仓零调用（M13）；trace_collector（DB 树）与 trace_adapter（JSONL 事件）双写同名事件语义（M11）。建议：删除 AgentTraceRecorder，采集一次、按需双出口落盘。 |
| qd_config vs constants | 边界基本清晰（constants=跨模块常量/env 清单，qd_config=执行核配置），但 **env 读取事实上三处并存**：agent.py（LLM/MEMORY/RAG）、llm.py（provider 解析）、qd_service._build_default_model（OPENAI_*）⇒ 汇成 M4/M16。建议 env 解析统一收口 constants，`AGENT_ENV_KEYS` 做对账（目前该清单零消费）。 |
| LLM 出口（新增项） | **确有双实现**：`llm.resolve_provider/complete` vs `qd_service._build_default_model`（M4），两套优先级不同、可能指向不同模型。 |
| cron 解析（新增项） | **确有双实现**：cron_worker vs cron/guards（M5），且已行为漂移。 |
| 执行入口（新增项） | **确有双轨**：message_queue.submit（唯一正轨）vs agent.run_agent（死代码且绕过钩子/停止机制，M14）。 |
| sys.path 引导（新增项） | scripts 7 处复制粘贴（L12），建议抽公共引导模块。 |

---

## 六、整体评价

**模块边界**：2026-10-13 的 P3 拆分（qd_* 混入件）、P5（相对导入/单实例）、P9（管线移出扫描目录）方向正确，拆分后每个模块头部都有"为什么/易错点/事故复盘"三件套，注释与测试护栏（qd_smoke 40 例）质量在同类项目中属上乘。preselect/ 子系统（纯函数 + 显式退化规则 + fail-open + 观测计数器）是全仓质量标杆。真正的问题不在"拆得好不好"，而在**"统一出口"类承诺有三处名实不符**：LLM 出口（M4）、cron 解析（M5）、trace 三层（M11/M13）——每次"统一"之后都留了一个还在跑的旧通道。

**调度/生命周期（最大系统性风险）**："手工 Future 无 RUNNING 态 + asyncio.to_thread 不可取消 + 钩子表按 session 注册"三者叠加，使**停止/超时语义在四个入口（CLI/Web/Cron/直调）各写一套且互相打架**：
- 超时/取消后的孤儿 run 脱离一切守卫继续烧 token、写记忆（H2/M9）；
- cancel 能杀死 worker 线程（H1）；
- 开跑即清停止位吞掉预约停止（M2）；
- 同 session 并发互删钩子（M19）。
建议把任务生命周期收敛为 message_queue 内一个 Task 对象（state/stop-generation/timeout/钩子绑定同生命周期），四个入口只做"提交/请求停止"两件事。cron 子系统是第二个风险集中区（H4 + M5-M10）：解析器重复且漂移、无效表达式=每分钟真跑、启动加载无失败恢复、一次性任务两种崩溃语义、防滥用闸 fail-open——建议整块按"单一 cronspec 解析 + fail-closed 闸 + 加载重试"重做一遍，而不是逐点打补丁。

**可以动手删的死代码**（全仓 grep 佐证）：`agent.run_agent`、`cron_worker.cron_matches`、`trace_collector.begin_skill/end_skill`、`utils/tracing.AgentTraceRecorder`、`cron/guards.seconds_delay_to_at`、`qd_grounding` 双 import、`cli._future_sink`、`cron_worker._publish.dead`、`func_overlap._sig_text` 消费端。删除即减少下次"两处并存"事故的土壤。

**待确认清单**（未臆测，需读仓外/表结构确认）：① memory/ 包 async 实现与 PostgresMemory loop 绑定（M3）；② `qd_agent_cron_jobs` 是否有 session_id 列（M10）；③ `/api/agent-v2/*` 是否有全局鉴权中间件（H5 不受影响，但影响面评估）；④ `domain_registry.strip_entity` 剥年份是否有意（L18）。
