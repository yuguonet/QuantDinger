"""
Tools 工具链系统

统一工具注册表 + OpenAI Function Calling schema 生成。

使用方式：
    from tools.base import ToolProvider, tool, func_to_openai_schema

    provider = ToolProvider()
    provider.scan_directory(Path("tools"))
    provider.scan_subdirectories(Path("tools"))

    # executor 用
    functions = provider.get_functions()

    # planning 用
    schemas = provider.get_schemas()
"""

from tools.base import Tool, ToolResult, ToolProvider, func_to_openai_schema

__all__ = ["Tool", "ToolResult", "ToolProvider", "func_to_openai_schema"]
