# QuantDinger 工具层重构 — 最终版

## 核心改动

1. **删除 MCP 子进程层**（mcp_bridge.py、mcp_executor.py、_MCPSingleton）
2. **统一工具注册表**（ToolProvider 替代 ToolRegistry + QDToolAdapter）
3. **call_tool router** 替代 mcp(action="call")

## 3 层工具可见性

| 层 | 包含什么 | 用途 |
|---|---|---|
| smolagents tools=[] | 5 个必选工具 | system prompt 自动描述，LLM 天然可见 |
| {{tool_list}} | 66 个领域工具 schema | planning 选工具、写调用代码 |
| executor custom_tools | 5 个必选工具 | executor 命名空间可调用 |

领域工具不在 custom_tools 中，通过 `call_tool("tool_name", **args)` 调用。

## executor custom_tools (5个)

```
call_tool          ← router，领域工具统一入口
list_tools         ← 发现工具
search_tools       ← 搜索工具
format_result      ← 格式化
web_search         ← 联网搜索
```

## LLM 工作流

```python
result = search_tools("资金")                              # 发现
result = call_tool("get_fund_flow", codes="600519")        # 调用
output = format_result(result)                             # 格式化
final_answer(output)                                       # 输出
```

## 修改的文件

| 文件 | 说明 |
|---|---|
| `tools/base.py` | +ToolProvider + func_to_openai_schema |
| `tools/__init__.py` | 导出更新 |
| `tools/list_tools.py` | _MUST_HAVE 过滤（不列必选工具） |
| `tools/bb_screener_scan.py` | 适配 ToolProvider |
| `agents/task_agent.py` | 删 MCP 壳，改 _build_code_agent（call_tool router） |
| `nodes.py` | init_mcp→init_tools，mcp_tool_list→tool_provider |
| `llm/__init__.py` | 删废弃导出 |
| `agent.py` / `agents/base.py` | 注释更新 |

## 删除的文件

```
tools/registry.py       → 被 ToolProvider 替代
tools/mcp_bridge.py     → MCP 子进程，不需要
executor/mcp_executor.py → MCPRouterTool + MCPExecutor
llm/qd_tools.py         → schema 生成迁移到 tools/base.py
```

## Skill 链路（未改动）

Skill 工具保持原版：_SkillSectionTool、_SkillResourceTool、_load_skill_functions。
run.py 函数在 plan_node 注册到 provider，与普通工具共用 call_tool 链路。
