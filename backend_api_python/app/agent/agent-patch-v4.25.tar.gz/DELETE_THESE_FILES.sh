# 以下文件需要从项目中删除（已被重构替代）
# 删除命令：在 backend_api_python/app/agent/ 目录下执行

rm -f tools/registry.py
rm -f tools/mcp_bridge.py
rm -f executor/mcp_executor.py
rm -f llm/qd_tools.py
