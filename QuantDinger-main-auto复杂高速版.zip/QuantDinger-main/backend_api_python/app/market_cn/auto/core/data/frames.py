#!/usr/bin/env python3
"""frames.py — 历史盘中"快照帧"重建层 (统一回测内核 P1, 2026-09-10)

用途:
  把 kline_1m 重建为**逐分钟全市场快照帧**, 让 intraday_window 策略 (tail/knife 及
  未来同类) 在历史区间内以与实盘**完全相同**的 scan_signals(ctx) 路径回测 ——
  回测与实盘共用同一份判定代码, 差异只剩数据通道 (kline_1m 重建 vs realtime_snapshot)。

触发语义 (与 test_v2_tail_buy 基线逐字段对齐, "bar 开盘触发"):
  - 触发时刻 = 某分钟 bar 的开盘边界 p → snap.last = bar[p].open (即本次触发的可成交价);
  - snap.high/low = 当日累计极值 (截至 p-1 收盘), snap.previousClose = 前一 1m 交易日
    该股最后一根 close (qfq, 由引擎的 pc_map 注入);
  - series = bar[0..p-1] (已收盘分钟), 行结构模拟快照: {time, open, high, low, last, volume(累计)};
  - 时间标签按**位置→分钟槽**重标 (MI_HHMM[pos]), 与基线的位置索引口径一致 (稀疏票的
    位置≈槽位近似, 基线本身即如此); 实盘路径不受影响。
  - 复权: 1m 原始价 → qfq (unadj_to_qfq, 失败退回原始价), 与基线 fetch_1m 同处理。

缓存:
  每交易日一 npz (data/market_cn_cache/frames/YYYYMMDD.npz)。首次构建全市场单日约
  10~20s (一次性), 之后加载秒级; 目录超 CACHE_BUDGET_GB 按_mtime 淘汰最旧。

易错点:
  - kline_1m 按**年分表** (kline_1m_YYYY), 单日查询只命中一张表;
  - 快照帧的 codes = 当日 1m 有 bar 的股票 (停牌股自然缺席, 与基线 group_days 同效果);
  - 本模块**零策略规则** — 预筛/判定全部在策略插件 (intraday_shortlist/scan_signals)。
"""
import os
import glob
import numpy as np

from app.utils.logger import get_logger

logger = get_logger(__name__)

# 缓存目录: backend_api_python/data/market_cn_cache/frames
# (路径锚点走 core/_paths.PROJECT_ROOT —— 曾用"回退 N 级", 目录一挪就静默指错;
#  原 3 级曾把 1.3G 缓存写进 app/data 源码树, 2026-09-10 修正并迁移)
from app.market_cn.auto.core._paths import CACHE_ROOT
CACHE_DIR = os.path.join(CACHE_ROOT, "frames")
CACHE_BUDGET_GB = 2.0
CACHE_VER = "v2"        # 帧结构版本 (v1=跨股 cumsum 量纲污染, 已弃用; 旧文件由淘汰机制自然清理)
                        # v2 结构增强 (A1): 新增 hcum/lcum 键 — 保持 v2 号避免已建 151 帧
                        # 全部作废重建; 读侧对缺键旧文件加载期补算并原子升级, 语义不变

# 位置(=分钟槽) → HH:MM, 与基线 _mi_to_hhmm 一致: 0↔09:31, 119↔11:30, 120↔13:01, 235↔14:56
MI_HHMM = []
for _mi in range(240):
    _minutes = 571 + _mi if _mi <= 119 else 661 + _mi
    MI_HHMM.append(f"{_minutes // 60:02d}:{_minutes % 60:02d}")


def hhmm_to_pos(hhmm):
    """'HH:MM' → 分钟槽位 (MI_HHMM 的逆映射); 不在交易时段返回 -1。"""
    try:
        return MI_HHMM.index(str(hhmm)[:5])
    except ValueError:
        return -1


class MinuteFrame:
    """单交易日全市场分钟帧 (CSR 按股分段, 位置=分钟槽近似口径)。"""

    __slots__ = ("date", "codes", "code_idx", "offsets", "counts",
                 "o", "h", "l", "c", "vcum", "hcum", "lcum")

    def __init__(self, date, codes, offsets, counts, o, h, l, c, vcum,
                 hcum=None, lcum=None):
        self.date = date
        self.codes = codes                      # list[str], 升序
        self.code_idx = {c: i for i, c in enumerate(codes)}
        self.offsets, self.counts = offsets, counts
        self.o, self.h, self.l, self.c, self.vcum = o, h, l, c, vcum
        # 分段累计极值 (截至各位置(含)之前 → 用 exclusive cummax)
        # hcum/lcum 已入缓存 (A1 提速): 缓存缺键 (旧文件) 时加载期补算并原子升级
        if hcum is None or lcum is None:
            hcum, lcum = self._seg_cummax(h, l, offsets, counts)
        self.hcum, self.lcum = hcum, lcum

    @staticmethod
    def _seg_cummax(h, l, offsets, counts):
        hcum = np.empty_like(h)
        lcum = np.empty_like(l)
        for i in range(len(offsets)):
            s, e = int(offsets[i]), int(offsets[i]) + int(counts[i])
            if e > s:
                hcum[s:e] = np.maximum.accumulate(h[s:e])
                lcum[s:e] = np.minimum.accumulate(l[s:e])
        return hcum, lcum

    def day_extremes(self):
        """每股当日 (首开, 日高, 日低) — reduceat 向量化 (通用窗口统计, 供策略日级预筛)。

        返回三个与 self.codes 对齐的 float64 数组; 分段保证非空 (构建期跳过无 bar 股)。
        """
        if (self.counts == 0).any():            # 防御: 空段会让 reduceat 错位
            dhigh = np.empty(len(self.codes))
            dlow = np.empty(len(self.codes))
            for i in range(len(self.codes)):
                s, n = int(self.offsets[i]), int(self.counts[i])
                if n > 0:
                    dhigh[i] = self.h[s:s + n].max()
                    dlow[i] = self.l[s:s + n].min()
            return self.o[self.offsets], dhigh, dlow
        starts = self.offsets
        return (self.o[starts],
                np.maximum.reduceat(self.h, starts),
                np.minimum.reduceat(self.l, starts))

    def __len__(self):
        return len(self.codes)

    def _seg(self, code):
        i = self.code_idx.get(code)
        if i is None:
            return None, None, None
        return i, self.offsets[i], self.counts[i]

    def snap(self, code, pos, pc):
        """位置 pos 的快照 dict (last=bar[pos].open); 位置不存在返回 None。"""
        i, off, n = self._seg(code)
        if i is None or pos >= n:
            return None
        s = off
        last = float(self.o[s + pos])
        if pos > 0:
            high = float(self.hcum[s + pos - 1])
            low = float(self.lcum[s + pos - 1])
        else:
            high = low = last                   # 日初无累计极值 (退化, 预筛会拒)
        # 时间串带秒 (与 realtime_snapshot 同格式): knife._tail_ret strptime("%H:%M:%S") 依赖
        return {"time": f"{self.date} {MI_HHMM[pos]}:00", "open": last, "high": high,
                "low": low, "last": last,
                "previousClose": float(pc) if pc else 0,
                "volume": float(self.vcum[s + pos])}

    def snaps_at(self, pos, pc_map, codes=None):
        """触发位置 pos 的全市场快照 {code: snap} (只含有 bar 的股票)。

        向量化 (A2 提速, 语义与逐股 snap() 逐字段一致): 同槽位所有股票的 time 串相同
        (外提一次); 价格/极值/累计量用 fancy indexing 一次取齐再建 dict。
        """
        idxs = [i for i, c in enumerate(self.codes)
                if int(self.counts[i]) > pos and (codes is None or c in codes)]
        if not idxs:
            return {}
        ia = np.asarray(idxs, dtype=np.int64)
        s = self.offsets[ia] + pos
        lasts = self.o[s].tolist()
        if pos > 0:
            highs = self.hcum[s - 1].tolist()   # 截至 p-1 收盘的累计极值 (exclusive)
            lows = self.lcum[s - 1].tolist()
        else:
            highs = lows = lasts                # 日初无累计极值 (退化, 预筛会拒)
        vols = self.vcum[s].tolist()
        t = f"{self.date} {MI_HHMM[pos]}:00"
        out = {}
        for k, i in enumerate(idxs):
            code = self.codes[i]
            pc = pc_map.get(code)
            out[code] = {"time": t, "open": lasts[k], "high": highs[k],
                         "low": lows[k], "last": lasts[k],
                         "previousClose": float(pc) if pc else 0,
                         "volume": vols[k]}
        return out

    def series(self, code, upto_pos):
        """bar[0..upto_pos-1] → 快照形行的序列 (模拟快照累计量; 位置→时间重标)。"""
        i, off, n = self._seg(code)
        if i is None:
            return []
        e = min(off + upto_pos, off + n)
        date = self.date
        return [{"time": f"{date} {MI_HHMM[j - off]}:00",
                 "open": float(self.o[j]), "high": float(self.h[j]),
                 "low": float(self.l[j]), "last": float(self.c[j]),
                 "volume": float(self.vcum[j])}
                for j in range(off, e)]

    def mkt_gain(self, pos, pc_map):
        """全市场均涨幅% (与 scan._mkt_gain 同口径: mean(last/pc-1); 无样本返回 0.0)。

        向量化 (A2 提速, 口径不变): 有 bar 且 pc>0 的股票, last>0 过滤后取均值。
        """
        valid = self.counts > pos
        if not valid.any():
            return 0.0
        idxs = np.nonzero(valid)[0]
        pcs = np.asarray([pc_map.get(self.codes[i]) or 0 for i in idxs], dtype=float)
        lasts = self.o[self.offsets[idxs] + pos]
        ok = (pcs > 0) & (lasts > 0)
        if not ok.any():
            return 0.0
        return float(np.mean((lasts[ok] / pcs[ok] - 1.0) * 100.0))

    def first_open(self, code):
        """该股当日第一根 bar 的 open (次日出场价用)。"""
        i, off, n = self._seg(code)
        if i is None or n == 0:
            return 0.0
        return float(self.o[off])

    def last_close(self, code):
        """该股当日最后一根 bar 的 close (pc_map 结转用)。"""
        i, off, n = self._seg(code)
        if i is None or n == 0:
            return 0.0
        return float(self.c[off + n - 1])


# ------------------------------------------------------------------
# 构建 / 缓存
# ------------------------------------------------------------------

def _cache_path(date):
    return os.path.join(CACHE_DIR, f"{CACHE_VER}_{date}.npz")


def _evict_cache():
    """目录超预算 → 按 mtime 淘汰最旧 (保留当前不删)。"""
    try:
        files = sorted(glob.glob(os.path.join(CACHE_DIR, "*.npz")),
                       key=os.path.getmtime)
        total = sum(os.path.getsize(f) for f in files)
        limit = CACHE_BUDGET_GB * (1 << 30)
        for f in files:
            if total <= limit:
                break
            total -= os.path.getsize(f)
            os.remove(f)
            logger.debug("[frames] 缓存淘汰: %s", f)
    except OSError as e:
        logger.debug("[frames] 缓存淘汰失败: %s", e)


def _seg_cumsum(v_l, off_l, cnt_l):
    """逐股分段累计量 (快照口径 volume=当日累计; **段内** cumsum, 跨股必须重置)。"""
    v = np.asarray(v_l, dtype=np.float64)
    out = np.empty_like(v)
    for i in range(len(off_l)):
        s_, n_ = int(off_l[i]), int(cnt_l[i])
        if n_ > 0:
            out[s_:s_ + n_] = np.cumsum(v[s_:s_ + n_])
    return out


def _qfq_bars(code, bars):
    """1m 原始价 → qfq (与基线 fetch_1m 同处理; 失败退回原始价)。"""
    try:
        from app.data_sources.provider.adjustment import unadj_to_qfq
        return unadj_to_qfq(bars, code)
    except Exception:
        return bars


def build_frame(date, codes=None):
    """构建单日全市场分钟帧 (先查缓存)。date='YYYY-MM-DD'。

    codes=None: 全市场 (结果落缓存); codes=[...]: 子集查询 (不落缓存, 防污染全量缓存)。
    """
    date = str(date)[:10]
    if codes is None:
        cached = _load_cache(date)
        if cached is not None:
            return cached
    else:
        codes = sorted(codes)

    from app.market_cn.auto.core.data.hub import all_codes
    universe = codes if codes is not None else all_codes()
    year = date[:4]
    table = f"kline_1m_{year}"

    from app.utils.db_market import get_market_db_manager
    mgr = get_market_db_manager()
    pool = mgr._get_pool("CNStock")

    per_code = {}                            # code -> list[(mi,o,h,l,c,v)]
    CHUNK = 800
    partial = False                          # A11: 任一分块最终失败 → 本帧残缺, 不落缓存
    for s in range(0, len(universe), CHUNK):
        chunk = universe[s:s + CHUNK]
        for attempt in (1, 2):               # 单次重试: 吸收瞬时 DB 抖动 (只此一次, 非循环兜底)
            try:
                with pool.connection() as conn:
                    with conn.cursor() as cur:
                        cur.execute(
                            f'SELECT symbol, time, open, high, low, close, volume '
                            f'FROM "{table}" WHERE symbol = ANY(%s) '
                            f'AND time >= %s AND time < %s ORDER BY symbol, time',
                            (chunk, f"{date} 09:00:00", f"{date} 15:01:00"))
                        cols = [d[0] for d in cur.description]
                        for row in cur.fetchall():
                            r = dict(zip(cols, row))
                            per_code.setdefault(str(r["symbol"]), []).append(r)
                break
            except Exception as e:
                if attempt == 1:
                    logger.warning("[frames] %s 分块查询失败(重试一次): %s", date[:10], e)
                else:
                    partial = True
                    logger.warning("[frames] %s 分块查询重试仍失败(该块≤%d票缺失, 本帧不落缓存): %s",
                                   date[:10], CHUNK, e)

    # 分段展平 (qfq → float 数组)
    sym_list, o_l, h_l, l_l, c_l, v_l, off_l, cnt_l = [], [], [], [], [], [], [], []
    off = 0
    for code in sorted(per_code):
        rows = per_code[code]
        if not rows:
            continue
        bars = _qfq_bars(code, [
            {"time": str(r["time"]), "open": float(r["open"] or 0),
             "high": float(r["high"] or 0), "low": float(r["low"] or 0),
             "close": float(r["close"] or 0), "volume": float(r["volume"] or 0)}
            for r in rows])
        o_l.extend(float(b["open"]) for b in bars)
        h_l.extend(float(b["high"]) for b in bars)
        l_l.extend(float(b["low"]) for b in bars)
        c_l.extend(float(b["close"]) for b in bars)
        v_l.extend(float(b["volume"]) for b in bars)
        off_l.append(off)
        cnt_l.append(len(bars))
        off += len(bars)
        sym_list.append(code)

    frame = MinuteFrame(
        date, sym_list,
        np.asarray(off_l, dtype=np.int64),
        np.asarray(cnt_l, dtype=np.int64),
        np.asarray(o_l, dtype=np.float64), np.asarray(h_l, dtype=np.float64),
        np.asarray(l_l, dtype=np.float64), np.asarray(c_l, dtype=np.float64),
        _seg_cumsum(v_l, off_l, cnt_l))
    if codes is None and not partial:
        _save_cache(frame)          # A11: 残缺帧(partial)不落缓存, 否则脏缓存永不失效
    return frame


def _save_cache(frame):
    try:
        os.makedirs(CACHE_DIR, exist_ok=True)
        path = _cache_path(frame.date)
        tmp = path + ".tmp"                 # 原子写: 先落 tmp 再 replace (防半文件/并发覆盖)
        with open(tmp, "wb") as f:
            np.savez_compressed(
                f, codes=np.asarray(frame.codes),
                offsets=frame.offsets, counts=frame.counts,
                o=frame.o, h=frame.h, l=frame.l, c=frame.c, vcum=frame.vcum,
                hcum=frame.hcum, lcum=frame.lcum)
        os.replace(tmp, path)
        _evict_cache()
    except OSError as e:
        logger.debug("[frames] 缓存写盘失败 (%s): %s", frame.date, e)


def _load_cache(date):
    path = _cache_path(date)
    if not os.path.exists(path):
        return None
    try:
        with np.load(path, allow_pickle=False) as z:
            hcum = z["hcum"] if "hcum" in z.files else None     # 旧 v2 文件无此键
            lcum = z["lcum"] if "lcum" in z.files else None
            frame = MinuteFrame(
                date, [str(x) for x in z["codes"].tolist()],
                z["offsets"], z["counts"],
                z["o"], z["h"], z["l"], z["c"], z["vcum"],
                hcum=hcum, lcum=lcum)
        if hcum is None:                    # 加载期升级 (补算的 hcum/lcum 回写, 下次免算)
            _save_cache(frame)
        return frame
    except Exception as e:
        logger.warning("[frames] 缓存加载失败 (%s): %s", date, e)
        return None


def trading_dates(days_back, end=None):
    """有日线记录的交易日列表 (升序, 窗口=最近 days_back 个自然日), 供引擎遍历。

    ⚠ 年份必须遍历 [start.year, end.year] **整段** (2026-09-28 审计 A2): 原写法
    `for year in {start[:4], end[:4]}` 只查首尾两年, days_back ≳638 (跨 2 个年以上) 时
    **中间年份整年丢失** (实测 days_back=700 → 2025 整年 0 日, 实得 225 应约 490);
    命中 core/backtest、present/intraday、tools/present_bench、tools/replay。
    同仓正确写法见 hub._query_batch_raw 的 `range(start.year, end.year + 1)`。
    """
    from datetime import datetime, timedelta
    from app.utils.db_market import get_market_db_manager
    end = str(end or datetime.now().strftime("%Y-%m-%d"))[:10]
    start = (datetime.strptime(end, "%Y-%m-%d") - timedelta(days=int(days_back))).strftime("%Y-%m-%d")
    mgr = get_market_db_manager()
    pool = mgr._get_pool("CNStock")
    out = []
    for year in range(int(start[:4]), int(end[:4]) + 1):
        try:
            with pool.connection() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        f'SELECT DISTINCT time::date FROM "kline_1D_{year}" '
                        f'WHERE time >= %s AND time < %s ORDER BY 1',
                        (start, end + " 23:59:59"))
                    out.extend(str(r[0]) for r in cur.fetchall())
        except Exception as e:
            logger.warning("[frames] %s 交易日查询失败: %s", year, e)
    return sorted(set(out))


def first_1m_date():
    """1m 数据覆盖的最早日期 (无数据返回 None); 引擎用它裁掉空帧日。

    ⚠ 不能只查 (今年, 去年) (2026-09-28 审计 A2 同源): 分钟表按年分表
    (kline_1m_YYYY), 更早年份有数据时会漏判 ⇒ 改为枚举全部 kline_1m_* 表取 MIN。
    """
    from app.utils.db_market import get_market_db_manager
    mgr = get_market_db_manager()
    pool = mgr._get_pool("CNStock")
    best = None
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT table_name FROM information_schema.tables "
                "WHERE table_schema = 'public' AND table_name ~ '^kline_1m_[0-9]{4}$'")
            tables = sorted(r[0] for r in cur.fetchall())
        for t in tables:
            try:
                with conn.cursor() as cur:
                    cur.execute(f'SELECT MIN(time) FROM "{t}"')
                    row = cur.fetchone()
                if row and row[0]:
                    d = str(row[0])[:10]
                    best = d if best is None or d < best else best
            except Exception:
                continue
    return best


def _qfq_close(code, ts, close):
    """1m 原始 close → qfq 单点换算 (A12, 2026-09-29 审计修复)。

    帧内价格过 unadj_to_qfq、_rollover_pc 用 qfq close, 而 prev_closes 原先直读
    kline_1m.close (原始价) —— 除权股的 previousClose/gap/mkt_gain 系统性算错,
    且回测首日与次日起口径不一致。失败退回原始价 (与 _qfq_bars 同策略)。
    """
    try:
        from app.data_sources.provider.adjustment import unadj_to_qfq
        bars = unadj_to_qfq([{"time": str(ts), "open": close, "high": close,
                              "low": close, "close": close, "volume": 0}], code)
        return float((bars[0] if bars else {}).get("close") or close or 0)
    except Exception:
        return float(close or 0)


def prev_closes(before_date):
    """每股在 before_date 之前最近一根 1m close (qfq) → {code: price} (pc_map 种子)。

    全量查询较慢 (~分钟级) → 结果按 before_date 落盘缓存 (data/market_cn_cache/frames)。

    易错点 (A10, 2026-09-28): 分钟表按年分表, 最近一根 1m close 可能落在**上一年**表
    (每年 1 月最初交易日回看 / 跨年长期停牌复牌) —— 只查 before_date 当年表会整体漏,
    previousClose=0 → 涨幅判定/除零全错。必须 UNION 相邻两年表后 DISTINCT ON 取最近
    (同 hub._query_batch_raw 跨年写法; before_date 在 Y 年则 time<Y-01-01 只可能落
    Y-1/Y 两表, 不需要 Y+1)。分块失败或全空**不落缓存** (A11: 脏缓存永不失效)。
    """
    date = str(before_date)[:10]
    # 缓存名带 _qfq 后缀 (A12): 旧缓存存的是不复权原始价, 修复后不得复用
    path = os.path.join(CACHE_DIR, f"pc_{date}_qfq.npz")
    if os.path.exists(path):
        try:
            with np.load(path, allow_pickle=False) as z:
                return {str(c): float(v) for c, v in
                        zip(z["codes"].tolist(), z["vals"].tolist())}
        except Exception as e:
            logger.debug("[frames] pc 缓存加载失败 (%s): %s", date, e)

    from app.market_cn.auto.core.data.hub import all_codes
    from app.utils.db_market import get_market_db_manager
    universe = all_codes()
    mgr = get_market_db_manager()
    pool = mgr._get_pool("CNStock")
    year = int(date[:4])
    with pool.connection() as conn:          # 只 UNION 实际存在的表 (最早年份无上一年表)
        with conn.cursor() as cur:
            cur.execute("SELECT table_name FROM information_schema.tables "
                        "WHERE table_schema = 'public' AND table_name ~ '^kline_1m_[0-9]{4}$'")
            existing = {str(r[0]) for r in cur.fetchall()}
    years = [y for y in (year - 1, year) if f"kline_1m_{y}" in existing]
    out = {}
    ok = bool(years)                         # A11: 任一分块失败 / 无可用表 → 不落缓存
    CHUNK = 800
    for s in range(0, len(universe), CHUNK):
        chunk = universe[s:s + CHUNK]
        union = " UNION ALL ".join(
            f'(SELECT symbol, time, close FROM "kline_1m_{y}" '
            f'WHERE symbol = ANY(%s) AND time < %s)' for y in years)
        try:
            with pool.connection() as conn:
                with conn.cursor() as cur:
                    # 占位符按子查询交错: (symbol, time) × N年
                    params = tuple(v for _ in years
                                   for v in (chunk, f"{before_date} 09:00:00"))
                    cur.execute(
                        f'SELECT DISTINCT ON (symbol) symbol, time, close '
                        f'FROM ({union}) t ORDER BY symbol, time DESC',
                        params)
                    for sym, ts, close in cur.fetchall():
                        out[str(sym)] = _qfq_close(str(sym), ts, close)
        except Exception as e:
            ok = False
            logger.warning("[frames] pc 种子查询失败 (%s): %s", before_date, e)
    if ok and out:                           # A11: 失败/查空不落缓存 (下次重新取数)
        try:
            os.makedirs(CACHE_DIR, exist_ok=True)
            np.savez_compressed(path, codes=np.asarray(list(out)),
                                vals=np.asarray([out[c] for c in out]))
        except OSError as e:
            logger.debug("[frames] pc 缓存写盘失败: %s", e)
    return out
