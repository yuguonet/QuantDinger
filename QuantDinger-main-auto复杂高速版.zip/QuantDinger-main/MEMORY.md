# MEMORY.md — 长期记忆

## 项目：QuantDinger
- **本地**: D:/QuantDinger
- **用途**: A股量化交易系统，小资金快速复利
- **技术栈**: Python 后端 (Flask + smolagents CodeAgent) + Vue 前端 + PostgreSQL
- **用户环境**: Windows10 + 40核 64G, D:\QuantDinger\, powershell, vscode
## 关键设计文档
- docs/AGENT_ACCOUNTABLE.md — 可追责架构（2026-06-20 重写，基于当前代码状态）
- docs目录中及系统目录下
- backend_api_python/app/agent/DESIGN.md — Agent 模块设计（最新 v2.2, 2026-09-13；含"能力发现层断链清单 L1~L7"审计记录与 v2.2 修复说明）
## Agent 架构现状（2026-09-13 核实）
- 编排层 `app/agent/graph.py` 是**自研轻量 StateGraph**，刻意不引入 langgraph 依赖（文件头明确写"不引入 langgraph 依赖，自己实现"）。
- 执行层用上游 **smolagents[openai]>=1.27.0**（CodeAgent）；未引入 langchain / pydantic-ai / agno / openai-agents。
- 差异化内核（不可替换）：`chain/`（EvalNode 树 + 盘后评估/权重迭代）、`capabilities/` 准入、`tools/finance/` 领域工具、`skills/`(SKILL.md)、`rag/`、`resolvers/`、`message_queue`。
- 契约：Tool 兼容 OpenAI Function Calling；Skill 兼容 Anthropic SKILL。
- **实际图结构**（以代码为准）：`chat → plan → execute → finalize` 四节点，注册在 `agents/task_agent.py:1765-1771`，节点工厂在 `nodes.py`（`make_chat_node:374` / `make_plan_node:592` / `make_execute_node:1228` / `make_finalize_node:1400`）。
- ⚠️ **文档与代码有既定落差**：`docs/AGENT_ACCOUNTABLE.md` 头部自述"状态: 实施中（LangGraph 版本）"，其 §二~§七 描述的是**目标架构**（LangGraph StateGraph + prepare/planner/agent 3-LLM + `messages: Annotated[...,add]` + `cached_tools` + `_collectors` + PostgresSaver + 通用 entity_code/entity_type）；而**代码现状**是自研 graph + chat/plan/execute + step_budget/phases + 金融专用。即"换 LangGraph"是项目自己已定的方向，只是**尚未落地**。评估时一律以代码为准。
- `docs/harness改造计划.md` 是上一轮改造计划（用 smolagents 替换旧 executor.py/runner.py/factory.py），**已完成**。
- 项目**只有一套** agent 实现（`app/agent`），不存在 `app/nanobot` 等第二套。
- ⚠️ `AgentState`（`nodes.py:39`）含**不可序列化字段**：`_code_agent`、`_phase_agents`（smolagents CodeAgent 实例）。启用任何"序列化整个 state"的 checkpointer 前，必须先把这些字段移出 state。
- Checkpointer 接口自研且**当前未启用**（`task_agent.py:1765` 附近注明"暂不启用 checkpointer，需要数据库连接池"）→ "可回测/可复现"存在真实缺口。
## 方向和约束
- 做 A 股量化交易,代码修改和迭代,项目研究和评估
- 网上找轮子比自己造轮子更好
- 不使用硬编码的方式写代码
- 不使用兜底方案和打补丁方案解决问题,要找到问题根源
- 模块化设计
- 统一代码风格,比如内部函数/接口使用下划线
- 修复问题不要矫枉过正
- 较大变动先分析再询问是否修改
- 每个文件的特点作用功能应该记录在头部注释中,关键设计点,容易误解和容易出错点都应该将注释,并放在当前代码旁
- 临时文件,结果,日志放在tmp/目录下,尽量不要污染整个项目
- 当前项目中多人在同时协同工作,注意加以区分：共享区域（MEMORY.md、.codebuddy/memory/、docs/、tmp/、日志等）只增量追加，不覆盖他人内容；自己产出的内容需标注来源（任务名/署名/时间）以便区分。
- 禁止执行任何 git 指令（status/add/commit/push/checkout/reset 等），提交一律由用户手工完成。
- **领域(domain)必须可扩展**（2026-09-13）：领域不止 finance，未来会有很多领域。凡涉及领域的判定一律用**登记表/目录推导**，禁止在代码里硬编码某个领域名。
  · 工具集域 = `tools/<子目录>` 名（`ToolProvider.get_domains()`）；工具**来源层**（如 `capabilities/` 的准入函数）**不是域**，不得占用 `selected_domain`。
  · "领域特性"（如交易日口径）放登记表：`resolvers/time.py` 的 `_ENTITY_DOMAIN` / `TRADING_CALENDAR_DOMAINS`。
- **领域标准化输出 = 注册表 + 自动发现**（2026-09-13）：新增领域只需放 `formatters/<domain>.py` 并 `@register_formatter("<domain>")`，`formatters/__init__.py` 自动加载（禁止再手写 import 清单）。查找顺序 **domain → entity_type → default**。
- **清单裁剪用相关性**（2026-09-13）：工具/条目超出注入上限时按与本次需求的相关度排序后截断（中文可用 2-gram 打分，无需分词依赖），**不要用字母序**；被裁数量要如实告知，无相关信号时退化为稳定序以避免随机丢弃。
- **能力层已正式接入**（2026-09-18）：默认开启（CAPABILITIES_ENABLED=0 可显式关）。审核留痕已补齐
  （admission.json 逐项 reviewed_by/at/note，20 项准入 = hub 13 + registry 2 + store 5，全部只读）；
  e2e 实测 planner 点名→白名单注入→沙箱调用全链路通。**当前准入全来自 auto 域，与 finance 工具
  （包装 market_cn 根模块 + agent DataSource）零重叠，无可删工具**；未来若准入 market_cn 根模块
  （scanner.SCAN_TARGETS 已支持），对应薄包装才进入"可删"讨论，且须逐个论证（包装层有契约/校验价值）。
  详见 `.codebuddy/memory/2026-09-18.md`。
- **market_cn 根模块已接入能力层**（2026-09-18 续四）：按 capability_scan_20260914_1326.json 审核
  94 个 pending，准入扩至 **69 项**（+49：china_market/dragon_limit/tape/index/finance F10/
  hot_sectors/data_bridge 等只读取数；refresh_*/cache_写/import_history/collect_* 排除）。
  plan 提示能力段已加**相关性裁剪**（`CAP_PLAN_LIST_LIMIT` 默认 30，复用 rank_tool_names 补 L7 缺口）。
  **9 项能力函数与 finance 工具同名被遮蔽（先到先得）**：逐个论证后仅 finance.get_sector_cycle/
  get_sector_prediction 2 个纯透传可删（删后能力层自动补位），其余 7 个包装有批量/降级/解析增量
  应保留。同名让位原则：聚合层（china_market）为唯一来源，子模块同名函数（emotion/sector_history）
  不准入。planner JSON 偶发损坏 → tools 字段丢失 → 靠 replan 自愈（遗留观察）。
- ⚠️ **本项目高发 bug："声明了但没接线"的静默断链**（2026-09-13 一次审计就查出 5 处）：判据依赖已被清空的字段（技能恒空 → 条件恒真）、参数从未传入（`TimeResolver()` 无参 → 分支恒假）、模块从未 import（formatter 注册表恒空）、注册 key 与查询 key 语义不一致、变量算了不用。共同点是**不报错、不告警、无 trace**。新增/改动这类"注册表/契约"时，务必顺手确认消费端真会命中（可加 `list_formatters()` 这类自检接口）。
  · 2026-09-13 又查出更狠的一例（L8）：**注入对象不满足消费端契约**（注入裸函数，而 nodes.py 调 `.resolve()`）→ `AttributeError` 被 `except: logger.debug` 吞掉 ⇒ 整条链**从未执行**。教训：验证时**不能只测组件本身，必须测"注入对象是否满足调用处契约"**；凡 `except` 里只写 debug 的接线处都该怀疑（已把该处升级为 warning）。

## Agent token 成本实测结论（2026-09-18，cli 实测确认）
- smolagents 每步打印的 `Input tokens` 是**整个 run 的累计值**，单步 = 相邻差分。别再把累计值误读成"单步 36k"。
- CodeAgent 每步重放 memory 的 token 大头**不是 observations**（`_wrap_stage_guard` 后 obs 已是 0），而是：
  `tool_calls.arguments`（8-12k 字符/步，`str([tc.dict()])` 全文渲染）、`model_output`（思维链+代码）、
  `PlanningStep.plan`（planning 后跳 ~9k）、`error`（出错后跳 ~6k）。四源已全部在 `_truncate_observations`
  系列截断（task_agent.py），实测验证。**全截 model_output 是错的**（模型失去上一步代码 → 输出暴涨），
  正确做法 = code-only 截断（保 `<code>` 块、丢思维链）。
- 真正发 API 的层 = `task_agent.py` 的 `_LLMAdapter.generate`（同步 OpenAI client，**绕过 LLMService/QDLLM**）；
  patch LLMService 或 `smolagents.Model.__call__` 都测不到（smolagents 调 `model.generate(...)`）。
- 遗留固定成本：SYSTEM prompt 11.6k 字符 ≈ 3.7k token/步。详见 `.codebuddy/memory/2026-09-18.md`。
- **SYSTEM prompt 已精简落地（2026-09-18 续二）**：code_agent.yaml 模板 10,176 → 6,717 字符（-34%）。
  病灶 = 6 个 few-shot 示例占 4.5k（其中 2 个演示 REPL 模式、与规则 13 矛盾）+ 规则 17 与
  `_sandbox_instructions` base 逐字重复 + 规则 12/15 重复。改后同任务 Step5 累计 35,173 → 25,980
  token（**-26%**），单步 Step1 -27%。**改 yaml 编号前必须查外部交叉引用**：只有「规则 9」「规则 13」
  被 task_agent.py 注释引用，不可变动。

## 三重共振三级过滤挖掘归档（来源：任务"三重共振信噪比挖掘"，2026-09-17）
- 结论：**不上线、不进生产**（用户裁定归档）。生产策略 `triple_resonance.py` 与 config.json 未改动；全部实验在 tmp/。
- 挖掘链（勿重复）：参数全扫/门消融/盘中触发/前视验证 → D0特征 → 前20日路径 → S/N 四级筛选。全样本最优规则=光头基底(距MA5>2.474%+无上影)+前5日无涨停+(D0涨2~4% 且 RSI14<60 且 ATR14%≤板块P50；主板另 OR MFI14<40，20cm 该分支证伪)。600天全样本 165+73 笔、胜率73%/81%、均收+4.0/+5.1%，看似成立。
- **证伪点①（时间切分）**：收益~100%来自2024年（主板2024: 111笔85%/+5.68；2025: 59%/+0.62；2026: 32%/+0.15；20cm 2025转负、2026信号绝迹）。两板块"互验"实为共同暴露2024政策行情风格——同批数据连筛4轮的样本内过拟合，跨板块验证无效。
- **证伪点②（风控门冲突）**：该 alpha 选的是冷门安静票，U4热度门拦95%、U2换手<3%拦79%/56%、U3小市值拦7%/34%，全门通过率仅1%/3%。与为龙回头热股设计的 unified_prefilter 结构性对立。
- 方法论教训：**段统计/真实出场/跨板块都通过后，必须再做年度时间切分**，本轮只有它揭穿了过拟合。产物：tmp/triple_resonance_d0diff.py+json（4.2万段全特征探针）、tmp/snr_analysis*.py、tmp/triple_resonance_v3_bt.py（正式回测+U门诊断，TRES_DIAG=1）。
- **近150天补充验证（2026-09-17）**：用户裁定600天被2024政策行情污染，只用近150天（6015段，主板3744/20cm2271）从零重做S/N。结果：alpha方向**完全反转**——600天有效的是"低波低涨幅冷门安静票"，150天AUC最高的全是"高涨幅/高乖离/高波动/距低点远"（距20日低点AUC0.69、收盘距MA5 0.68、ATR 0.65、D0涨幅 0.64）。但**所有分区D1开盘收益均为负**（主板最高分位-0.66~-0.86%，20cm最高分位-0.05~-0.49%），即当前环境下三重共振形态无论怎么分区都没有可交易alpha。结论：**三重共振策略在2026年市场环境下整体失效**，不是参数问题而是形态逻辑失效，应放弃该策略原型。产物：tmp/snr_150.py / tmp/snr150_out.txt。
- **近150天买点穷尽+提前一日可预测性验证（2026-09-17，同任务续）**：用户判断"冲高被D0+D1开盘吃掉"，买点侧系统验证（宇宙=近150天光頭基底462/109段，v1真实出场）：① 7个日频买点（D0尾盘/D1开/D1收/D2开/D1低开收阳确认/D1收阴→D2开/D1限价回踩MA5）仅D2开盘小幅改善（主板-0.78→-0.29，20cm+0.37但月度不稳），**日频买点全部无正期望**；② 提前一日双层验证（tmp/pre_signal_150*.py）：**先知天花板**买D-1收+2.15/+2.68%、买D0开+6.62/+10.38%（胜率84%、月度全正）——钱确实在D0当天；但**可预测性证伪**：D-1三线临界带全市场9870/3502个预测日，次日真出光头金叉仅0.6%/0.3%，全样本买D-1收/D0开整体-0.82/-0.79%（主板）、-1.27/-1.23%（20cm）。D-1前兆画像（真事件D-1已涨+2~3%、站MA10上方）把最强分区精确率抬到8.9%（距MA10>5%，盈亏平衡需~11%），该分区无条件收益仍-0.93%。本质：光头金叉由D0突发大涨"造成"而非技术状态"演变"，日线信息无法提前预测；唯一例外"主板D-1涨停→D-1收买+1.13%"封板实际不可成交且20cm不重复。**方法论沉淀：评估"提前买点"必须双层——oracle天花板只证明空间存在，必须再用≤决策日数据的预测规则在【全部】股票日（含假信号）上算无条件收益；在已确认信号段内回算早期买点=前视偏差。** 要兑现只剩分钟级盘中策略。产物：tmp/buypt_150.py/json、tmp/pre_signal_150.py/json、tmp/pre_signal_150b*.py/json。
- 另：dragon_v2 min_streak=4 已落地（600d 131笔/58.8%/+2.59/rpd1.273）；relay3 量能门实验全证伪已回退原版。
- **澄清优先于猜测**（2026-09-13 用户裁定）：**无法准确判断就应该反问，拿到准确信息才执行**。解析器/取数层遇到歧义（标的多个候选、口径不明、相对时间不落交易日…）必须返回 `clarify_question`（见 `resolvers/base.ResolveResult`），**不许猜默认值往下跑**——猜错标的/窗口会让整份分析作废，反问只花一轮对话。新增领域/解析器沿用该契约（`resolvers/composite.CompositeResolver` 组合），无需改 `chat_node`。
- ⚠️ **裸环境验证 agent 代码的坑**（2026-09-13）：本机无 `requests`/`pandas`，`app` 包链会断。**不要**用桩顶掉 `app.utils`——`resolvers/time.py` 的 `_cal()` 依赖 `from app.utils import trading_calendar`，被顶掉会误判成"逻辑没生效"。正确做法：`importlib.util.spec_from_file_location` 按**文件路径**加载那一个真实模块再挂到桩上。
- **死票/冲高分解 + 延迟买入终验（2026-09-17，来源：任务"三重共振信噪比挖掘"续）**：用户观点"买入后没有高振幅就是纯亏损(山顶票)"获证实：G1池死票组(7日峰<3%)占37%(主板)/33%(20cm)，胜率0.6%/0.0%，均亏-4.63%/-5.19%，亏损占比99%——整体亏损**全部**来自死票；冲高组(峰≥5%)占44%/51%，均收+2.99%/+3.09% 胜率80%。①死票 D-1 预剔除失败：冲高组vs死票组 AUC atr1=0.54/0.54、big20=0.53/0.51、rma_chg=0.52/0.52，残差判别力≈0；②山顶假设证伪：big20≥5 组冲高率反而最高(主板50.4%/20cm53.7%)，ATR 五分位冲高率单调升但均收仅+0.2~0.4pp；③**冲高兑现不是主要矛盾**：peak≥10 交易在 v1 引擎下最终胜率97.2%/92.1%、最终亏损仅2%/8%——-8%止损/-5%追踪接得住冲高，问题只在死票；④延迟买入(D0收盘确认→收盘买，l1win 缓存日线代理)也全负：dh0/chg0/volr0 确认越强追价越高(P冲高↑但期望↓)，主板最好-0.00%、20cm最好 dma5_0>6 +0.24%(未含费用)——D0收盘价已有效定价当日信息，确认信号预测的是"相对开盘的冲高"，延迟买入把 alpha 吃掉；⑤月度冲高率强周期：2026-08 达54~65%(唯一正月)，2026-09 仅22~25%——振幅概率受 regime 支配，G+ 依市场环境。**终论：买点侧(D-1盘后/D0开盘/D0收盘/D1各时点)日线级全部穷尽且全负；死票只能靠盘中分钟级实时信息或出场侧加速止损解决。** 产物：tmp/pumpdead_150.py、tmp/lateday_150.py(均只读缓存/零重扫)，输出 pumpdead150_out.txt / lateday150_out.txt，生产代码零改动。
- **「56%胜率规则」（2026-09-17 用户命名，冻结待研）**：三重共振 G+ 链的 G1 池收窄规则。完整定义：①基座 L1=D-1 满足 |MA5-MA10|≤2.5% & rma_chg>0；②高波门=ATR14>板块Q5(主板5.07/20cm 6.42) & 前20日大涨日(≥5%)≥2；③核心=rhist_chg>板块池内Q5(主板0.51/20cm 0.66)，rhist_chg=(D-1 MACD柱−D-2 MACD柱)/D-1收×100；④执行=D-1盘后选→D0开盘买(一字/触板剔)→v1引擎(7d/-8%/-5%)。战绩(近150天)：20cm 胜率57.0%/+0.77%/日均11笔(得名)、主板-0.06%/44.1%/日均16。⚠️未解缺陷：样本53%集中2026-08、环境过拟合嫌疑未除(月度拆解 g1deep2150_out.txt)，待 regime 门解。备选剔除门：dif0/rsi_1/mfi_1 水平过热(死票组高, 20cm dif0≤P20 +1.12%)。参数快照同步存 project_memory.md。
- **G1池内二次差异性 → regime 择时发现（2026-09-17，来源：任务"三重共振信噪比挖掘"续，用户要求"G1过滤结果后再找差异性+加规则收窄"）**：① G1 池内残差判别力之王 = rhist_chg(D-1 MACD柱二阶动量, AUC 0.62/0.59) > dma5_1 > cci_1 > chg1 > volr1；**dif0/rsi_1/mfi_1 AUC<0.5 死票组高（20cm dif0≤P20 +1.12%）——"指标水平过热=死票、动量斜率=判别器"**；② 收窄规则可把日均压到 10~16 笔（rhist_chg>Q5: 主板-0.06%/44%/日均16、20cm+0.77%/57%/日均11），**但月度拆解揭穿：20cm Q5 桶 53% 样本、dif0≤0 组合 68% 样本集中在 2026-08 单月，剔除后回归负值；主板最好组合也 5/6 月为负——又是一次环境过拟合（与 600 天被 2024 污染同一模式），个股规则挖掘到头**；③ **regime 延续性确认（首个干净信号）**：前日池冲高率五分位→次日单调：主板 Q5→次日 P(peak≥5)=55.9%(基线44%)/均收+0.53%，Q1→32.3%/-1.87%；20cm Q5→61.1%/+0.41%，Q1→38.4%/-1.88%；日冲高率 lag1 自相关 0.43~0.55、lag5 归零——冲高率是 2~3 天尺度的市场状态，**"什么时候做"比"做什么票"信号更强**。终论：个股 D-1 规则已无独立 alpha，下一层=regime 择时门（及时指标需另设计：D-1 全市场涨停数/池内部分实现冲高率等，滞后≥2 天才干净，本探索用 7 日实现 peak 有前视，只证存在性）。产物：tmp/g1deep_150.py(+缓存npz)、tmp/g1deep2_150.py、tmp/regime_150.py，输出 g1deep150_out/g1deep2150_out/regime150_out.txt，生产代码零改动。
- **金叉前夜→G+大肉链 日线级终点归档（2026-09-17，来源：任务"三重共振信噪比挖掘"续，用户裁度：只看结果不管历史一致性）**：目标改定义为 G+（D0 开盘买、D0~D1 冲高>10%）。① L1 盘后筛选层（全 D-1 数据）= `|MA5-MA10|≤2.5% & rma_chg>0`，日均 679(主板)/341(20cm) 只，G+ 保留 90%/83%；② L1 池内 G+ 判别力 AUC 排名 = 高波 ATR14(0.75/0.72) > 前20日大涨日≥5%(0.71/0.69) > 前20日涨停数 > 快线追赶速度——G+ 型条件 `L1+ATR>Q5(5.07/6.42)+big20≥2` 把 G+ 率抬到 11.4%/17.6%（3 倍）；③ **真实出场验证全负**：G1 池 D0 开盘买+v1 引擎(7d/-8%/-5%) 主板 -0.77%/36%、20cm -0.51%/41%，月度 6 个月 5 负；④ **D1 限价挂单（T+1 下最后一招）也只到盈亏平衡**：20cm 挂 +8% 未成交续引擎 = **+0.04%（≈0，未含费用）**，主板全负（最好 -0.19%）；⑤ 光头/金叉 E 事件只是 G+ 的 6.6%，两条"有效信号"定义下规则方向相反（保 E 用安静票、抓 G+ 用高波强势票）。**终论：大肉存在于冲高分布（16~22% 的交易 7 日内冲高>10%）但日线级任何可执行买点/出场组合均无法转正，日线通道正式穷尽；唯一剩余杠杆=盘中实时系统（D1 盘中冲高卖出器，需分钟数据）。** 产物：tmp/retain_150 / migrate_150 / l1win_150 / gmeat_150 / limitexit_150（均含 npz/json 缓存），生产代码零改动。
- **门内精修+实战top-K（2026-09-17，来源：同任务续，regime4_150）**：在 v2 门内继续挖提升。**主板：精修无效**（dif0/rsi/mfi/chg1/cp1 全部仅 +0.06~0.13pp 噪声级，top-K by rhist_chg 反向：top3 +0.80<门整体+0.87，top5 +0.19——强度排序越强越差）→ 主板维持 56%&rmed>0.25 = +0.87%/52.2% 不动。**20cm：①dif0<=0 精修有效：56%&score>0.65&dif0<=0 = +2.02%/69.2%/日均6.3笔 正3/4月（07月-0.8→-0.5），dif0<=0&chg1>0 = +2.05%/69.5%——有独立先验（DIF未高企=动量刚起步+死票组dif0高），月度结构未恶化，采纳**；②top3 by rhist_chg = 74笔 **4/4月全正**（05+5.2 06+0.0 07+1.7 08+2.9，07月唯一转正的执行口径）但均收+1.12%/胜率48.6%偏弱——rhist_chg 最强的票高方差（top1 胜率仅44%但P(>10)=40%），适合"求稳"不适合"求收益"；③score P60-80 单桶（不用56%）仍全场最强 +2.23%/66.8%/日均11笔 3月全正，但05月空仓+事后挑选嫌疑未除。**v2.1执行口径：主板 56%&rmed>0.25；20cm 56%&score_r>0.65&dif0<=0（+2.02%/69.2%，求稳健可改门内top3）**。交易量：56%规则150天 20cm 1605笔/主板2325笔。产物：tmp/regime4_150.py/regime4150_out.txt，生产代码零改动。
- **「56%胜率规则」600天扩窗扫描（2026-09-17，仅存档不采信）**：**用户裁定（2026-09-17 重申）：不考虑600天（2024政策行情污染），只以150天以内窗口为准——本条结果仅作反面教材存档，56%规则与 regime 门不作废**。扫描口径同 g1deep_150 扩窗 600 天（24Q4~26Q3，8季度/424交易日，主板36500/20cm 20886笔），全部阈值用 150 天先验固定值不重估（零前视）：①56%规则 600 天口径 20cm +0.08%（胜率48.2%）、主板-0.49%；②正收益集中 26Q2+26Q3、2025 同条件触发均亏；③regime 门（rmed>0.5）在 2025 触发季为负——即"G+ alpha 依存于 2026-04 后的动量行情段"这一环境敏感性在长窗口得到印证（反面教材价值：任何规则上线前必须知道它赚的是哪段行情的钱）；④唯一跨期稳健=反向门：dif0med/rsimed≥池P80 时主板 7/8 季、20cm 8/8 季全负——"池过热回避"跨 regime 成立。产物：tmp/g1deep_600.py（+缓存 g1deep_600_cache.npz），输出 g1deep600_out.txt，生产代码零改动。
- **regime门v2：滚动20日分位"相对热度"score（2026-09-17，来源：同任务续，用户裁定150天框架内）**：及时指标=按D0聚合池内D-1特征（池宽n、rmed=rhist_chg中位、dmed=dif0中位、smed=rsi_1中位），各自滚动20日分位（不含当日，零前视，D-1盘后可知）方向调整后等权=score。**发现①"相对热度">>"绝对热度"：滚动分位门优于全期分位上界（20cm 56%×score_r>0.75 +1.94% vs score_f>0.7 +1.48%；主板同向）——regime是相对概念，问"比最近20天更热吗"而非"绝对热不热"**；②**倒U型**：score与收益非单调，P60-80桶最好、top20%回落（主板-0.16/20cm+0.00）——"极端同步20日新高"=过热衰竭，与dif0/rsi反向门互证；③战绩：主板最优=**56%&rmed>0.25固定 +0.87%/52.2%/日均14笔 正3/4月**（05+2.7 06+0.5 07-0.7 08+1.9），零前视替代=rmed滚动分位Q5(20日新高) +0.91%/52.6% 正4/5月；20cm最优=**56%&score_r>0.65 +1.75%/66.0%/日均12笔 正3/4月**（05+5.2 06+0.6 07-0.8 08+3.0），score>0.75 +1.94%/68.0%；score单桶P60-80(不用56%)=+2.23%/66.8%/日均18笔 3月全正含07月（事后五分位挑选，多重比较嫌疑，待确认）；④**09月全部门自动空仓**（9月基线-2.4，门正确闭嘴）。残留：主板05月滚动门-2.9（固定门反而+2.7）；95交易日单一regime段权威性有限。**v2执行口径：D-1盘后算G1池+56%票→主板rmed>0.25固定门/20cm score_r>0.65门→D0开盘买（一字/触板剔）→v1引擎(7d/-8%/-5%)**。产物：tmp/regime3_150.py/regime3150_out.txt，生产代码零改动。
- **56%池指标扩展对比：换手率/KDJ/布林带（2026-09-17，来源：同任务续，用户要求"peak>10 vs peak<5 对比+扩充指标"）**：56%池内冲高组(peak>10) vs 弱势组(peak<5)（用户口径切分）：主板 497笔+6.66% vs 1071笔-3.87%；20cm 464笔+5.92% vs 541笔-4.05%——两组差10个点，池内可分性强。新指标结论：①**boll_bw(布林带宽)是唯一跨板块一致的新判别器**：AUC 0.58(主板)/0.56(20cm) 全特征最高，Q5桶 主板+1.22%/55.7%、20cm+2.13%/67.9%（宽带=20日波动率大=弹性大，与ATR门同族）；②**boll_pctb 反向一致**：D-1收盘贴布林上轨(P>80)最差（主板-0.50/20cm-0.59，与dif0/rsi"未高企"族互证——贴带顶=动量已兑现）；③**换手率turn1无区分力**（AUC 0.52/0.51，桶平坦）；④**KDJ全套无力**（AUC≈0.5、kdj_j中间桶最高=非单调噪声，信息被RSI/MACD覆盖）。月度检查（g1deep3chk）：56%&bw>P60&pctb<=P40 主板+1.08%/54.3%（正2/4月，07月-0.4）、20cm+1.95%/67.8%——**但20cm门后样本78%集中2026-08（比池本身53%更糟）=环境偏差加重，未解决08月独强问题**；主板bw门5-7月仍负，不如rmed环境门。终论：**"未高企"族（dif0/rsi/mfi/pctb低）方向一致，dif0<=0仍是族内月度最优（已入v2.1口径）；boll_bw可作为20cm求稳备选但样本集中问题未解**。产物：tmp/g1deep3_150.py(+缓存npz)/g1deep3chk_150.py，输出 g1deep3150_out/g1deep3chk150_out.txt，生产代码零改动。
- **boll_bw 门叠加 v2.1 口径验证（2026-09-17，来源：同任务续，regime5_150，用户问"加入策略规则后的结论"）**：bw/pctb 阈值用 g1deep3 桶边界冻结（56%池内P60/P40）。**20cm：不采纳**——56%&score>0.65&dif0<=0（v2.1现行）&bw>P60 点收益+2.52%/73.1% 更高，但月度结构恶化（正3/4月→正2/4月，06月-3.0，08月占比69%→81%）=bw 门把样本进一步推向 08 月强势段，是环境杠杆放大器不是独立 alpha（dif0<=0 的采纳判据"月度未恶化"恰是 bw 门不满足的）；&pctb<=P40 / 双门同样正2/4、正1/4。**主板：首个有效增量但证据弱，挂"待确认"**——上轮 regime4 精修（dif0/rsi/mfi/chg1/cp1 水平类）全无效，而波动率结构类门有效：v2.1主门(56%&rmed>0.25, +0.87%/52.2% 正3/4月 07月-0.7)&pctb<=P40 = +1.45%/58.6% 正4/4月（07月+0.0，但05月仅1笔）；&bw>P60&pctb<=P40 = +1.62%/59.2%（07月+0.0）；08月占比 49%→58-63%（比 20cm 温和）。判定：主板备选口径 = v2.1主门&pctb<=P40（+1.45%/58.6%），因阈值样本内+05月空样本，不直接替换 v2.1，纸面跟踪攒样本后再定。产物：tmp/regime5_150.py/regime5150_out.txt，生产代码零改动。
- **g56「56%规则G+」生产上线（2026-09-17 17:10，来源：g56生产化任务，用户拍板"将这个策略写进生产中"+主板带pctb门+立即启用）**：新插件 backend_api_python/app/market_cn/auto/strategies/g56.py（key=g56，family=g56，use_unified_prefilter=False），口径冻结为模块常量：主板 G1&56%&rmed>0.25&pctb<=49.87 / 20cm G1&56%&score_r>0.65&dif0<=0，执行 D-1盘后信号→D0开盘买(gap≥涨停幅剔)→7d/-8%/-5%。架构三要点：①横截面 regime 门用模块级惰性聚合缓存（_ensure_pool_daily：hub.all_codes+hub.daily(200, as_of=target) 逐票G1特征→按板块日度聚合 n/rmed/dmed/smed→滚动20日分位，key=target 跨日失效，失败当日不产信号宁缺勿滥）；②聚合锚=切片前末根（回测=快照末日/实盘=扫描日），查表 key=特征日(D-1)→回测=实盘同 key 同值；③exit day_close 重放=引擎逐日决策流式等价（trig=max(peak*0.95, entry*0.92)、d≥7到期收盘），勿直接调 _run_backtest（其 exit_day 是兜底残影与触发的混合值无法区分）。特征逐字移植 migrate_150（_rsi 为 roll_sum 口径，indicators.rsi 的 Wilder 口径不可替换；calc_macd 返回 list 需转数组）。config.json strategies.g56 {enabled=true, daily_limit=30}；store.py SIGNAL_EXTRA_KEYS 增量追加 rhist_chg/boll_pctb/dif0/rmed/score_r。**回测对账验收 PASS（tmp/g56_verify.py，2026-09-17）：主板 n=649/+1.45%/58.6%、20cm n=945/+2.01%/69.1%，与 regime5 基线(649/+1.45/58.6、944/+2.02/69.2)逐字一致；逐笔 ret 8/8 相同、rhist_chg 差≤0.0004（EMA窗口微差）；出场流式等价 83/83；entry gap 门/as_of 切片冒烟通过——研究池含 D0-gap 条件的口径差实际影响为零**。当日 17:05 手工补跑 run_scan（16:30 定时扫描在启用前已跑过）：链路正常、g56 今日 0 信号=门正确关闭（主板 rmed 0.199<0.25、20cm score_r 0.49<0.65，"09月自动空仓"复现），非故障。已知风险：阈值样本内拟合（08月样本占比主板58%/20cm 69%），纸面跟踪期持续盯月度结构；live 出场标记后次日开盘执行与回测触发价有执行时点差（全框架同口径）。
- **d1_close_pos 门验证：入场门否定，但发现"D0收盘弱"强预警（2026-09-17，来源：g56门验证任务，用户提供 pos<42&ret10<0 门并称提胜率）**：用户门在 g56 150天交易集上**真 D-1 口径为负贡献**（主板门内 79笔 +0.63%/46.8% vs 基线 58.6%；pos/ret10 分桶均单调向上=高位+上涨才是好组，反向门 pos≥42&ret10≥0 主板70.4%/20cm 73.2%，ret10≥0 单门≈双门）。**用户结论的真正来源=导出 JSON 索引错位**：tmp/g56_trades_export.json 的 pre_ohlcv 是 D-20..D0 共21根，末根 pre[-1] 是 **D0 买入日**而非 D-1；按 pre[-1] 算（实际=D0收盘位置<42 & D0近10日跌）门内组胜率仅 21.3%(主板188笔)/14.2%(20cm 127笔)，剔除后 73.8%/77.6% 确实"大提胜率"——**但 D0 收盘位置在 D0 开盘买入时点不存在，作入场门是前视不可执行**。可执行变体也否定：D0收弱→D1开盘砍仓，主板 -2.08%（比原引擎 -1.69% 更差，D1 平均跳空低开）、20cm -2.69%≈持平——亏损在 D0 盘中已形成，日线级无法抢救。**价值：为分钟级盘中监控提供特征锚（D0 日内收盘位置可实时跟踪，低位+近10日跌=当日就走弱的死票特征），与"死票加速止损需分钟级"结论闭环**。导出链路：tmp/g56_export_json.py→g56_trades_export.json（150天 1594笔 OHLCV+买卖点标记）→g56_gate_check.py/g56_gate_diagnose.py；注意 pre_ohlcv[19]=D-1、[20]=D0 的索引约定。
- **peak<5% 死票过滤三方案全部否定（2026-09-17，来源：g56门验证任务续，用户二次分析提出3方案+自我结论"D-1难分"）**：用户表格只有过滤率/误杀维度，补收益期望裁决后：**P1 big_up_5d=0&pctb<35 / P2 +ret10<0&rsi<35 被砍组是最好的一批票**（主板 +3.50%/65.0%、20cm +3.51%/66.7% vs 基线 +1.45%/58.6%）——G1池定义就是MA5-MA10粘合蓄势，池内"近5日无大涨+低位"的票在56%门(D-1 MACD柱放大)触发时恰是启动初期弹性最大，弱势特征过滤=反向选择，绝对不可上。**P3 chg_10d<-5% 整体正贡献（砍后主板 +1.95%/65.5%、20cm +2.13%/73.0%）但月度检查拆穿：07月双板块反向（主板剩余-0.11%<被砍+0.09%、20cm剩余-1.41%<被砍+0.36%）、20cm 08月也反向（被砍+3.28%>剩余+2.94%）、剩余样本08月占比恶化至主板71%/20cm 75%——与bw门同款"环境杠杆放大器"假象，非独立alpha**。终论：用户原始直觉正确——**peak<5%的28%死票在D-1日线维度与好票同分布（该维度已被G1+56%+regime门榨干），区分信息在D0盘中，归于分钟级监控方向**；g56 生产零改动。产物：tmp/g56_filter_expect.py。
- **出场研究定稿：删追踪止损→纯 7d/-8% 无追踪（2026-09-17，来源：g56出场优化任务，用户拍板"既然入场门已穷尽，那就修改出场"→AskUserQuestion"删追踪止损(推荐)"）**：网格扫描（hold×stop×trail_keep 全因子，信号集=导出JSON 1594笔，独立模拟器与引擎同式）：**trail 保留系数 0.85~0.97 全区间单调（越松越好）、0.75~0.85 平台化≈无追踪 → 无追踪是结构终点非阈值拟合**；机制=G1池定义即MA5-MA10粘合蓄势+56%门=启动初期，紧追踪系统性打断动量延续。hold=7双板块共同峰，stop=-8边际递减保留。**生产已改版**：g56.py 删 TRAIL_STOP、新增模块级 _exit_no_trail（exit_decision/backtest_stock 全链路脱离 v1._run_backtest）；出场分布 追踪1513/到期81/硬止损0 → **止损220/到期1374**。**新基线（150天，tmp/g56_verify.py 验收 PASS 重跑出场流式等价83/83）：主板 649笔 +7.51%/81.0%（06 +0.72/07 +4.62/08 +10.38）、20cm 945笔 +9.95%/83.9%（06 +6.56/07 +3.25/08 +12.21）**；入场链路零变化（笔数逐字同改版前、rhist_chg 与 g1deep3 缓存抽查 8/8；ret 因出场改版与旧缓存不可比）。验收插曲：①导出6笔±0.001出场价告警=raw/rounded entry 舍入链（回测止损线用未舍入D0开盘价、导出重算用3位舍入入场价），零经济影响不修；②流式等价82/83一笔0.0002差=exit_decision到期分支未round(3)，已修复对齐。改版前 trail 基线：主板+1.45/58.6、20cm+2.01/69.1。**用户提议"D1亏损就出场"数据否定**（tmp/g56_d1_exit.py）：全变体（V_open/V_close th∈{+1,0,-1,-2}%/V_exec实盘D2跳空版）双板块均负（用户口径 主板+7.51→+6.26/66.3%、20cm→+8.93/75.3%），被砍组基线均收+3.52/+5.39强正（64~70%本盈利）、被砍组死票占比33%/26%≈全体28% → **D1亏损与最终死活零相关，第三次验证"G1蓄势结构上弱势表象过滤系统性反向"**（前两例=pos<42门、死票P1/P2）。风险：跌停无法成交高估、无追踪单笔最大回撤可达-20%+（20cm）、阈值样本内拟合未除纸面跟踪盯月度。**策略更名（同日，用户"g56辨识度太差"）**：显示名"56%规则G+"→**"五重共振"**（5重硬条件可数：|MA5-MA10|≤2.5%/rma_chg>0/ATR>板块Q5/前20日大涨日≥2/rhist_chg>板块Q5，regime门=横截面环境门不占位，与祖先"三金叉共振"成谱系；config.json label 同步），key=g56 不动（DB信号/config/tmp 链路稳定）。产物：tmp/g56_exit_scan.py / g56_d1_exit.py、新 g56_trades_export.json（1692笔含出场OHLCV）、g56_verify.py 改对账 _exit_no_trail + rhist_chg 一致率。

## 两套沙箱与 prompt 渲染层（2026-09-18，来源：agent 沙箱残留清理任务，署名：agent 接线清理）

- **"沙箱"在本项目是两个东西，勿混淆**：
  (a) **安全限制层**（import 白名单 + 破坏性扫描层）→ **已删**；
  (b) **执行环境** smolagents `LocalPythonExecutor` → **仍在且必然在**（它是执行代码的地方，
  删了就没法执行）。所谓"删沙箱"只删了 (a)。
  `additional_authorized_imports=["*"]`，`check_import_authorized` 首层通配短路
  ⇒ `Import of X is not allowed` 永不触发。
- **(b) 仍在生效的限制（2026-09-18 实测）**：
  ① **内置函数白名单 `BASE_PYTHON_TOOLS` 仅 52 个**——`eval` / `exec` / `compile` /
  `globals` / `locals` / `__import__` **均不在其中** ⇒ 模型写这些得到
  `The variable 'eval' is not defined`（**不是**被拦截，是压根未定义）；
  ② 工具调用白名单（`Forbidden function evaluation`）；
  ③ 语法子集限制（41 处 `raise InterpreterError`：不支持的语句/运算符等）；
  ④ 资源上限 `MAX_OPERATIONS=1e7` / `MAX_WHILE_ITERATIONS=1e6` / 超时；
  ⑤ dunder **函数**调用拦截（`local_python_executor.py:917`）——注意属性访问已被本项目
  monkeypatch 放行，但函数调用未放行。
- **smolagents `DANGEROUS_FUNCTIONS`（:143-153）实测不生效**：`eval/exec/globals` 等本就
  不在 BASE_PYTHON_TOOLS（未定义）；`os.system` 赋值实测**未被拦**（`__module__` 不匹配 'os'）。
  ⇒ 不要以为这层在保护什么。
- **坑（§8.4 剩余缺口的可触发实例）**：上面 ①③⑤ 的报错**都不在** GuidedPythonExecutor 的
  4 类改写范围内（只改 Forbidden function / has no attribute / dunder 属性）⇒ 模型撞到后
  不知道原因、可能反复尝试。若日后要做通用错误指纹，这些是主要命中面。
  相关死代码已于 2026-09-18 清理（executor 的 import 改写分支 + `_err_counts` + `_import_names`、
  `task_agent.py` 的 `"[import 拦截]"` 死匹配与最小授权白名单注释块）。
- **`app/utils/safe_exec.py` 是另一套仍在生效的沙箱**（`_BUILTINS_WHITELIST` + 安全模块白名单），
  供 `services/indicator_review.py` / `indicator_analyzer.py` 执行**用户在指标 IDE 提交的指标代码**。
  安全语义与 agent 不同（多租户用户代码），**不在"删除沙箱"范围内，勿顺手删**。
- `guided_executor.py` 的破坏性操作审批层（原 `DANGEROUS_IMPORTS` + `_scan_dangerous` +
  `_approve` + `confirm_cb` 参数）**已于 2026-09-18 删除**（从未接线，留着是"看起来有防护、
  实际零作用"）⇒ 现 agent 侧对破坏性操作**零拦截**，`import os/shutil/subprocess` 均可执行。
- **`prompts/code_agent.yaml` 有隐藏渲染层**：规则 9 是 smolagents 原生行 `{{authorized_imports}}`，
  由 `initialize_system_prompt`（agents.py:1626-1630）渲染——`*` 时输出
  `You can import from any package you want.`，否则回退默认受限清单。
  ⇒ 改这句不能只看 yaml 字面，必须连同渲染值一起验；`task_agent.py` 的对齐逻辑失败时**会 warning**。
- **教训（删"死字符串"前必做）**：曾判断 `nodes.py` bad_marks 里的 `"is not allowed"` 是死代码，
  grep 上游后发现它**不只**匹配已消失的 import 越界报错，**仍命中**
  `Invoking a builtin function ... is not allowed`（local_python_executor.py:908）。
  ⇒ 判定某个错误字符串"已死"前，必须 grep 上游**全部**产生点，而非只看触发本次清理的那一条。

## smolagents 执行机制事实（2026-09-18 实证，署名：agent 接线清理）

- **`PlanningStep` 的 plan 是纯文本，永不被执行**：`_generate_planning_step`
  （agents.py:639-747）只 yield `PlanningStep(plan=...)` 进 memory，不解析更不执行其中的代码。
  触发条件 `planning_interval is not None and (step==1 or (step-1)%interval==0)`（agents.py:549-552）。
- **曾据此踩坑（已修）**：`code_agent.yaml` 的 `planning.initial_plan` 曾要求模型输出
  **完整代码骨架**（一个 `<code>` 块）。那段代码 ①永不执行 ②作为上下文**每步重喂**
  ③实测也**没能阻止**模型分步 ⇒ 三重纯浪费。2026-09-18 改为「3~6 行要点式，明确不写完整代码」。
  实测生效：单段任务 Step 1 input 由（含 115 行骨架）降到 **4,864**。
- **分步执行是模型行为，不是框架拆的**：实测 glm-5.3-flash 在 Thought 里主动写
  「分两阶段执行 / 阶段3 二次验证」，即使 plan 是单块骨架也照拆。
  实测 input 线性增长：4.8k → 11.5k → 17.6k → 25.4k → 36.4k（Step5 已是 Step1 的 7.5 倍）。
  ⇒ 调 prompt 只能压初始体积，根治要换更稳的模型或加引擎层护栏（§8.10）。

## 测试红灯的判读原则（2026-09-18 教训，署名：agent 接线清理）

- **不要因为"怀疑并发改写"就把测试失败一律当噪音放过。** 先读失败断言在说什么——
  断言描述的是**契约**，若它指向"某条通道/说明必须在场"，那失败 == 该通道真的断了。
- **实例（代价很大）**：`tests/test_wiring.py::test_plan_prompt_exposes_single_segment_naming_channel`
  连续多轮显示 `1 failed`，我因 MEMORY 里"先怀疑并发改写"的原则，把它当既有红灯放过，
  还向用户报告"与本次无关"。实际它是真信号：`prompts/plan_system.txt` 丢失了
  ①`"仅无 phases 时使用"`（单段任务的顶层 `tools` 点名通道说明）②`"必须点名才会注入"`
  ③能力名单示例 `list_signals` ⇒ planner 不知道单段要在顶层点名 ⇒ **数据能力不注入**，
  沙箱只剩 common 工具——正是用户报的"必须注入的工具链路又断掉了"。补回后 **36 passed**。
- **正确顺序**：看到红灯 → 读断言文本 → 判断它守护的是哪条契约 → 再决定是并发噪音还是真断链。
  "怀疑并发改写"是**排除手段**不是**结论**。
- **plan_system.txt 的两条点名通道（勿再精简掉）**：
  无 phases（单段）→ 顶层 `tools` 点名（**仅无 phases 时使用**，是单段唯一注入通道）；
  有 phases → 顶层留空、写入 `phases[].tools`。数据能力（`list_signals`/`all_codes`/`daily`/`quote`）
  必须点名才注入，留空 = 本轮不用。
- **领涨追击（lead_chase）接入 auto 系统（2026-09-27，来源：lead_chase接入任务，agent 审查落地）**：用户交付 tarball（署名 agent(归组化)），审查后落地 3 文件——strategies/lead_chase.py（盘中分钟级两段管线：intraday_shortlist 横截面板块共振+领涨+追涨区间2~7%/近封板剔/活跃度 → scan_signals 单票深判①量价近似资金流 flow_ratio≥0.05&comove≥0.6 ②距20日高≤2% ③量能预估≥1.5x ⑤前20日涨幅≤15% OR 回撤≥5% ⑥市值20~250亿；出场默认 D1 开盘卖未定稿）、hub.py +sector_map()（stock_basic_info 行业归属，纯增量与 lhb() 同模式）、config.json +lead_chase 块（**enabled=false 待回测拍板**）。⚠️ 拦截 tarball 夹带污染：其 config.json 快照落后，含 tail_oversold amp_min 10→8 的回退（09-26 他人改动），落地时只摘 lead_chase 块未整文件覆盖。框架契约逐项核对通过（ScanSpec intraday_window/windows/interval_sec、scan.py 两段管线调用、frames 快照重建语义当日累计+previousClose、backtest 时间线引擎、tail_oversold 同构类属性模式）；接线冒烟 9/9 PASS（tmp/verify_lead_chase.py 零DB monkeypatch）。60 天 kline_1m 回测后台启动中（首跑建 frames 缓存），产物 tmp/lead_chase_bt.json。待拍板：出场规则（D1 开盘卖 vs v1 引擎 vs 盘中冲高卖）、"起涨时间最早"升级版领涨判定、概念共振（多对多映射表）。
