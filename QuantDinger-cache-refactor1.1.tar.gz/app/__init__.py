"""
QuantDinger Python API - Flask application factory.
"""
import math
import logging
import traceback

from flask import Flask
from flask.json.provider import DefaultJSONProvider
from flask_cors import CORS

from app.utils.logger import setup_logger, get_logger


class SafeJSONProvider(DefaultJSONProvider):
    """JSON provider that converts NaN / Infinity to null.

    Python's ``json.dumps`` with ``allow_nan=True`` (the default) emits
    literal ``NaN`` / ``Infinity`` tokens which are **not** valid JSON per
    RFC 8259.  JavaScript's ``JSON.parse()`` will throw on them, breaking
    every frontend consumer.  This provider silently replaces those values
    with ``None`` (→ ``null``) so the output is always spec-compliant.
    """

    @staticmethod
    def default(o):
        """Handle non-serializable objects (same as super)."""
        return DefaultJSONProvider.default(o)

    def dumps(self, obj, **kwargs):
        kwargs.setdefault("default", self.default)
        return _safe_json_dumps(obj, **kwargs)


def _safe_json_dumps(obj, **kwargs):
    """Recursively sanitize NaN/Inf then serialize."""
    import json
    return json.dumps(_sanitize(obj), **kwargs)


def _sanitize(obj):
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return None
        return obj
    if isinstance(obj, dict):
        return {k: _sanitize(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_sanitize(v) for v in obj]
    return obj

logger = get_logger(__name__)

# Global singletons (avoid duplicate strategy threads).
_trading_executor = None
_pending_order_worker = None


def get_trading_executor():
    """Get the trading executor singleton."""
    global _trading_executor
    if _trading_executor is None:
        from app.services.trading_executor import TradingExecutor
        _trading_executor = TradingExecutor()
    return _trading_executor


def get_pending_order_worker():
    """Get the pending order worker singleton."""
    global _pending_order_worker
    if _pending_order_worker is None:
        from app.services.pending_order_worker import PendingOrderWorker
        _pending_order_worker = PendingOrderWorker()
    return _pending_order_worker


def start_polymarket_worker():
    """[DISCONNECTED] Polymarket后台任务 — 已断开，不启动"""
    logger.info("Polymarket worker is disconnected (code preserved, not started)")
    return
    # ── Original code below (preserved) ──
    try:
        from app.services.polymarket_worker import get_polymarket_worker
        get_polymarket_worker().start()
    except Exception as e:
        logger.error(f"Failed to start Polymarket worker: {e}")


def start_portfolio_monitor():
    """Start the portfolio monitor service if enabled.
    
    To enable it, set ENABLE_PORTFOLIO_MONITOR=true.
    """
    import os
    enabled = os.getenv("ENABLE_PORTFOLIO_MONITOR", "true").lower() == "true"
    if not enabled:
        logger.info("Portfolio monitor is disabled. Set ENABLE_PORTFOLIO_MONITOR=true to enable.")
        return
    
    # Avoid running twice with Flask reloader
    debug = os.getenv("PYTHON_API_DEBUG", "false").lower() == "true"
    if debug:
        if os.environ.get("WERKZEUG_RUN_MAIN") != "true":
            return
    
    try:
        from app.services.portfolio_monitor import start_monitor_service
        start_monitor_service()
    except Exception as e:
        logger.error(f"Failed to start portfolio monitor: {e}")


def start_pending_order_worker():
    """Start the pending order worker (disabled by default in paper mode).

    To enable it, set ENABLE_PENDING_ORDER_WORKER=true.
    """
    import os
    # Local deployment: default to enabled so queued orders can be dispatched automatically.
    # To disable it, set ENABLE_PENDING_ORDER_WORKER=false explicitly.
    if os.getenv('ENABLE_PENDING_ORDER_WORKER', 'true').lower() != 'true':
        logger.info("Pending order worker is disabled (paper mode). Set ENABLE_PENDING_ORDER_WORKER=true to enable.")
        return
    try:
        get_pending_order_worker().start()
    except Exception as e:
        logger.error(f"Failed to start pending order worker: {e}")


def start_usdt_order_worker():
    """Start the USDT order background worker.

    Periodically scans pending/paid USDT orders and checks on-chain status.
    Ensures orders are confirmed even if the user closes the browser after payment.
    Only starts if USDT_PAY_ENABLED=true.
    """
    import os
    if str(os.getenv("USDT_PAY_ENABLED", "False")).lower() not in ("1", "true", "yes"):
        logger.info("USDT order worker not started (USDT_PAY_ENABLED is not true).")
        return

    # Avoid running twice with Flask reloader
    debug = os.getenv("PYTHON_API_DEBUG", "false").lower() == "true"
    if debug:
        if os.environ.get("WERKZEUG_RUN_MAIN") != "true":
            return

    try:
        from app.services.usdt_payment_service import get_usdt_order_worker
        get_usdt_order_worker().start()
    except Exception as e:
        logger.error(f"Failed to start USDT order worker: {e}")


def start_sector_history_scheduler():
    """启动板块历史采集调度器（仅在 SECTOR_HISTORY_ENABLED=true 时）

    每日收盘后 15:30 采集行业板块 & 概念板块排名存入 feather，
    保留 ~200 天（~6.5 个月），供趋势/周期/预测分析使用。
    """
    import os
    if os.getenv("SECTOR_HISTORY_ENABLED", "false").lower() != "true":
        logger.info("Sector history scheduler is disabled. Set SECTOR_HISTORY_ENABLED=true to enable.")
        return

    debug = os.getenv("PYTHON_API_DEBUG", "false").lower() == "true"
    if debug and os.environ.get("WERKZEUG_RUN_MAIN") != "true":
        return

    try:
        from app.market_cn.sector_history import SectorHistoryScheduler

        scheduler = SectorHistoryScheduler()
        scheduler.start()
    except Exception as e:
        logger.error(f"Failed to start sector history scheduler: {e}")


def restore_running_strategies():
    """
    Restore running strategies on startup.
    Local deployment: only restores IndicatorStrategy.
    """
    import os
    # You can disable auto-restore to avoid starting many threads on low-resource hosts.
    if os.getenv('DISABLE_RESTORE_RUNNING_STRATEGIES', 'false').lower() == 'true':
        logger.info("Startup strategy restore is disabled via DISABLE_RESTORE_RUNNING_STRATEGIES")
        return
    try:
        from app.services.strategy import StrategyService
        
        strategy_service = StrategyService()
        trading_executor = get_trading_executor()
        
        running_strategies = strategy_service.get_running_strategies_with_type()
        
        if not running_strategies:
            logger.info("No running strategies to restore.")
            return
        
        logger.info(f"Restoring {len(running_strategies)} running strategies...")
        
        restored_count = 0
        for strategy_info in running_strategies:
            strategy_id = strategy_info['id']
            strategy_type = strategy_info.get('strategy_type', '')
            
            try:
                if strategy_type and strategy_type != 'IndicatorStrategy':
                    logger.info(f"Skip restore unsupported strategy type: id={strategy_id}, type={strategy_type}")
                    continue

                success = trading_executor.start_strategy(strategy_id)
                strategy_type_name = 'IndicatorStrategy'
                
                if success:
                    restored_count += 1
                    logger.info(f"[OK] {strategy_type_name} {strategy_id} restored")
                else:
                    logger.warning(f"[FAIL] {strategy_type_name} {strategy_id} restore failed (state may be stale)")
                    # 如果恢复失败，更新数据库状态为stopped，避免策略处于"僵尸"状态
                    try:
                        strategy_service.update_strategy_status(strategy_id, 'stopped')
                        logger.info(f"[FIX] Updated strategy {strategy_id} status to 'stopped' after restore failure")
                    except Exception as e:
                        logger.error(f"Failed to update strategy {strategy_id} status after restore failure: {e}")
            except Exception as e:
                logger.error(f"Error restoring strategy {strategy_id}: {str(e)}")
                logger.error(traceback.format_exc())
        
        logger.info(f"Strategy restore completed: {restored_count}/{len(running_strategies)} restored")
        
    except Exception as e:
        logger.error(f"Failed to restore running strategies: {str(e)}")
        logger.error(traceback.format_exc())
        # Do not raise; avoid breaking app startup.


def create_app(config_name='default'):
    """
    Flask application factory.
    
    Args:
        config_name: config name
        
    Returns:
        Flask app
    """
    app = Flask(__name__)
    app.json_provider_class = SafeJSONProvider
    app.json = SafeJSONProvider(app)

    app.config['JSON_AS_ASCII'] = False
    app.config['MAX_CONTENT_LENGTH'] = 2 * 1024 * 1024  # 2 MB max request body
    
    CORS(app)
    
    setup_logger()
    
    # Initialize database and ensure admin user exists
    try:
        from app.utils.db import init_database, get_db_type
        logger.info(f"Database type: {get_db_type()}")
        init_database()
        
        # Ensure admin user exists (multi-user mode)
        from app.services.user_service import get_user_service
        get_user_service().ensure_admin_exists()
    except Exception as e:
        logger.warning(f"Database initialization note: {e}")

    # ── 安全启动检查 ──────────────────────────────────────────
    import os as _os
    _secret = _os.getenv('SECRET_KEY', '')
    _admin_pw = _os.getenv('ADMIN_PASSWORD', '')
    _is_debug = _os.getenv('PYTHON_API_DEBUG', 'False').lower() == 'true'

    if not _secret or _secret == 'quantdinger-secret-key-change-me':
        if not _is_debug:
            logger.critical(
                "SECURITY: SECRET_KEY is using the default value. "
                "Set the SECRET_KEY environment variable to a random string before starting in production. "
                "Example: export SECRET_KEY=$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
            )
        else:
            logger.warning("SECRET_KEY is using the default value — acceptable in debug mode only.")

    if not _admin_pw or _admin_pw == '123456':
        if not _is_debug:
            logger.critical(
                "SECURITY: ADMIN_PASSWORD is using the default '123456'. "
                "Set the ADMIN_PASSWORD environment variable before starting in production."
            )
        else:
            logger.warning("ADMIN_PASSWORD is using the default '123456' — acceptable in debug mode only.")

    from app.routes import register_routes
    register_routes(app)

    # ── SSE TCP_NODELAY 中间件 ───────────────────────────────
    # 问题：Gunicorn gthread worker 的 socket 默认启用 Nagle 算法，
    # 小数据包（SSE 消息 ~100字节）滞留在内核 TCP 发送缓冲区，
    # 前端收不到进度更新，直到连接关闭时才一次性 flush。
    # 解决：对 SSE 响应设置 TCP_NODELAY，强制每个 packet 立即发送。
    # 原理：TCP_NODELAY 作用于 socket fd（内核级别），
    #       socket.fromfd(fd) 创建的新对象与原始 socket 共享同一个 fd，
    #       setsockopt 对 fd 生效后，原始 socket 的发送行为也改变。
    import socket as _socket_module

    class _SSENoDelayMiddleware:
        def __init__(self, wsgi_app):
            self.app = wsgi_app

        def __call__(self, environ, start_response):
            resp = self.app(environ, start_response)
            # 仅对 SSE 响应设置 TCP_NODELAY
            ct = ''
            if hasattr(resp, 'headers'):
                ct = resp.headers.get('Content-Type', '') or resp.headers.get('content-type', '')
            if 'text/event-stream' not in ct:
                return resp

            # 获取底层 socket fd 并设置 TCP_NODELAY
            # 兼容多种 WSGI 服务器（Gunicorn gthread/eventlet/gevent）
            _fd = None
            try:
                if hasattr(resp, 'response'):
                    _sock_obj = resp.response
                    # Gunicorn socket 对象：_sock 是原始 socket.socket
                    if hasattr(_sock_obj, '_sock') and hasattr(_sock_obj._sock, 'fileno'):
                        _fd = _sock_obj._sock.fileno()
                    elif hasattr(_sock_obj, 'fileno'):
                        _fd = _sock_obj.fileno()
                # 降级：从 WSGI environ 获取
                if _fd is None and 'gunicorn.socket' in environ:
                    _fd = environ['gunicorn.socket'].fileno()
            except Exception:
                pass

            if _fd is not None:
                try:
                    _dup = _socket_module.fromfd(_fd, _socket_module.AF_INET, _socket_module.SOCK_STREAM)
                    _dup.setsockopt(_socket_module.IPPROTO_TCP, _socket_module.TCP_NODELAY, 1)
                    _dup.detach()  # 不关闭原始 fd
                except Exception:
                    pass  # 非 TCP socket（如 Unix socket）或 fd 无效，静默降级

            return resp

    app.wsgi_app = _SSENoDelayMiddleware(app.wsgi_app)

    # ── 静默 GeneratorExit ───────────────────────────────────
    # werkzeug 的 _iter_encoded 在客户端断开连接时会抛 GeneratorExit，
    # 这是正常的生成器清理行为，不应作为错误记录。
    @app.teardown_request
    def _silence_generator_exit(exc):
        if isinstance(exc, GeneratorExit):
            return  # 静默，不记录
        # 其他异常交给 Flask 默认处理
    
    # Startup hooks.
    with app.app_context():
        start_pending_order_worker()
        start_portfolio_monitor()
        start_usdt_order_worker()
#        start_polymarket_worker()
        # Offline calibration to make AI thresholds self-tuning.
        restore_running_strategies()

        # ── A股股票基本信息表初始化 ────────────────────────────
        # 每次启动后台同步一次（增量更新 name/status 等字段）。
        # 拉取数量 >= 5200 视为数据完整，才执行停牌/退市标记。
        try:
            from app.utils.basicinfo_db import get_stock_basic_db
            _stock_db = get_stock_basic_db()
            _stock_db.ensure_table()
            import threading
            threading.Thread(
                target=_stock_db.sync_from_remote,
                daemon=True,
                name="stock-basic-init-sync",
            ).start()
            logger.info("[StockBasic] 后台启动同步")
        except Exception as e:
            logger.warning(f"[StockBasic] 初始化跳过: {e}")
        
        # ── A股K线增量同步调度 ──────────────────────────────────
        try:
            from app.data_sources.backfill_db import start_scheduler
            start_scheduler()  # ← 启动统一调度器（15m + 1D）
        except ImportError:
            pass
        except Exception as e:
            logger.debug(f"[Backfill] A股K线增量调度器未启动: {e}")

        # ── AI 反思 & 校准 worker（必须在 stock_basic_db + backfill 之后）──
        # 这两个 worker 会从 qd_analysis_memory 捞历史记录，通过 Coordinator 拉行情验证。
        # 如果在 Provider / stock_basic_db 就绪前启动，所有请求失败会打爆熔断器。
        try:
            from app.services.ai_calibration import start_ai_calibration_worker
            start_ai_calibration_worker()
        except Exception as e:
            logger.warning(f"AI calibration worker not started: {e}")
        try:
            from app.services.reflection import start_reflection_worker
            start_reflection_worker()
        except Exception as e:
            logger.warning(f"Reflection worker not started: {e}")
        try:
            from app.agent.chain.evaluator import start_eval_worker
            start_eval_worker()
        except Exception as e:
            logger.warning(f"Chain eval worker not started: {e}")

        # ── market_cn 数据刷新调度器 ─────────────────────────
        try:
            from app.market_cn.scheduler import start as start_market_cn_scheduler
            start_market_cn_scheduler()
        except Exception as e:
            logger.warning(f"market_cn scheduler not started: {e}")

    return app

