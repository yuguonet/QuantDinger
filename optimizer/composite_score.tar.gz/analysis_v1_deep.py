#!/usr/bin/env python3
"""
连板猎手 V1 深度挖掘 — 三合一分析

1. D+1盘中行为: 开盘后走势模式 (高开高走/高开低走/低开高走...)
2. 复合评分: 多弱因子组合连续评分 vs 硬阈值
3. D0涨停类型: 封板时间/方式/首次vs回封 细分

数据: dragon_ohlcv.csv
"""
import csv, os, json, sys
from collections import defaultdict
from math import sqrt

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# ================================================================
# 数据加载
# ================================================================

def load_cycles(csv_path):
    groups = defaultdict(list)
    with open(csv_path, encoding='utf-8-sig') as f:
        for row in csv.DictReader(f):
            groups[(row['code'], row['run_first_limit_date'])].append(row)
    cycles = []
    for (code, fl_date), rows in groups.items():
        rows.sort(key=lambda r: r['time'])
        n_limit = int(rows[0].get('run_n_limit_ups', 1))
        bt = 'gem_star' if code.startswith(('30','68')) else 'main'
        threshold = 0.198 if bt == 'gem_star' else 0.098
        cycles.append({'code': code, 'bt': bt, 'threshold': threshold,
                       'n_limit': n_limit, 'rows': rows})
    return cycles

def find_limit_indices(rows, threshold):
    return [i for i in range(1, len(rows))
            if float(rows[i-1]['close']) > 0
            and (float(rows[i]['close']) / float(rows[i-1]['close']) - 1) >= threshold * 0.98]

# ================================================================
# 分析1: D+1盘中行为
# ================================================================

def analyze_d1_intraday(cycles):
    """D+1当天的K线形态分析: 开盘后怎么走"""
    print(f"\n{'='*70}")
    print(f"  分析1: D+1盘中行为分析")
    print(f"{'='*70}")

    d1_data = []
    for cycle in cycles:
        rows = cycle['rows']
        threshold = cycle['threshold']
        limit_indices = find_limit_indices(rows, threshold)
        if not limit_indices:
            continue

        d0_idx = limit_indices[0]
        if d0_idx + 1 >= len(rows):
            continue

        d0 = rows[d0_idx]
        d1 = rows[d0_idx + 1]
        d0_close = float(d0['close'])
        d1_open = float(d1['open'])
        d1_close = float(d1['close'])
        d1_high = float(d1['high'])
        d1_low = float(d1['low'])
        d1_vol = float(d1['volume'])

        if d0_close <= 0 or d1_open <= 0:
            continue

        continued = len(limit_indices) > 1
        d1_gap = (d1_open / d0_close - 1) * 100
        d1_ret = (d1_close / d1_open - 1) * 100  # 开盘到收盘
        d1_intra_range = (d1_high - d1_low) / d1_open * 100
        d1_upper = (d1_high - d1_close) / d1_open * 100
        d1_lower = (d1_open - d1_low) / d1_open * 100 if d1_close >= d1_open else (d1_close - d1_low) / d1_open * 100

        # D+1类型分类
        if d1_ret >= 5:
            d1_type = 'strong_up'    # 高开高走/低开高走
        elif d1_ret >= 0:
            d1_type = 'flat_up'      # 平开微涨
        elif d1_ret >= -3:
            d1_type = 'flat_down'    # 平开微跌
        else:
            d1_type = 'strong_down'  # 高开低走/低开低走

        # D+1是否涨停/跌停
        d1_is_limit_up = (d1_close / d1_open - 1) >= threshold * 0.98 if d1_open > 0 else False
        d1_is_limit_down = (d1_close / d1_open - 1) <= -threshold * 0.98 if d1_open > 0 else False

        # D+2 (如果有的话)
        d2_ret = None
        if d0_idx + 2 < len(rows):
            d2 = rows[d0_idx + 2]
            d2_ret = (float(d2['close']) / d1_close - 1) * 100 if d1_close > 0 else None

        d1_data.append({
            'code': cycle['code'],
            'n_limit': cycle['n_limit'],
            'bt': cycle['bt'],
            'continued': continued,
            'd1_gap': d1_gap,
            'd1_ret': d1_ret,
            'd1_intra_range': d1_intra_range,
            'd1_upper': d1_upper,
            'd1_type': d1_type,
            'd1_is_limit_up': d1_is_limit_up,
            'd1_is_limit_down': d1_is_limit_down,
            'd2_ret': d2_ret,
        })

    cont = [x for x in d1_data if x['continued']]
    stop = [x for x in d1_data if not x['continued']]
    print(f"\n  样本: 续板D0={len(cont)}  断板D0={len(stop)}")

    # D+1类型分布
    print(f"\n  ── D+1走势类型 vs 续板率 ──")
    type_labels = {
        'strong_up': '强势上涨(>=5%)',
        'flat_up':   '平开微涨(0~5%)',
        'flat_down': '平开微跌(0~-3%)',
        'strong_down': '强势下跌(<-3%)',
    }
    print(f"  {'类型':<22} {'续板':>6} {'断板':>6} {'续板率':>8} {'D+2均涨幅':>10}")
    print(f"  {'─'*56}")
    for t in ['strong_up', 'flat_up', 'flat_down', 'strong_down']:
        c = sum(1 for x in cont if x['d1_type'] == t)
        s = sum(1 for x in stop if x['d1_type'] == t)
        total = c + s
        if total < 5:
            continue
        wr = c / total * 100
        d2_vals = [x['d2_ret'] for x in cont + stop if x['d1_type'] == t and x['d2_ret'] is not None]
        d2_avg = sum(d2_vals) / len(d2_vals) if d2_vals else 0
        star = "⭐" if wr > 30 else "  "
        print(f"  {star}{type_labels[t]:<20} {c:>6} {s:>6} {wr:>7.1f}% {d2_avg:>+9.2f}%")

    # D+1高开幅度分段
    print(f"\n  ── D+1高开幅度 vs 续板率 ──")
    bins = [(-10,-3),(-3,-1),(-1,0),(0,1),(1,2),(2,3),(3,5),(5,8),(8,15)]
    print(f"  {'高开区间':<16} {'续板':>6} {'断板':>6} {'续板率':>8} {'D+2均涨幅':>10}")
    print(f"  {'─'*50}")
    for lo, hi in bins:
        c = sum(1 for x in cont if lo <= x['d1_gap'] < hi)
        s = sum(1 for x in stop if lo <= x['d1_gap'] < hi)
        total = c + s
        if total < 5:
            continue
        wr = c / total * 100
        d2_vals = [x['d2_ret'] for x in cont + stop if lo <= x['d1_gap'] < hi and x['d2_ret'] is not None]
        d2_avg = sum(d2_vals) / len(d2_vals) if d2_vals else 0
        star = "⭐" if wr > 30 or d2_avg > 3 else "  "
        print(f"  {star}{lo:>5}~{hi:<5}%     {c:>6} {s:>6} {wr:>7.1f}% {d2_avg:>+9.2f}%")

    # D+1盘中振幅
    print(f"\n  ── D+1盘中振幅 vs 续板率 ──")
    for lo, hi in [(0,3),(3,5),(5,8),(8,12),(12,20)]:
        c = sum(1 for x in cont if lo <= x['d1_intra_range'] < hi)
        s = sum(1 for x in stop if lo <= x['d1_intra_range'] < hi)
        total = c + s
        if total < 5:
            continue
        wr = c / total * 100
        print(f"  {lo:>3}~{hi:<3}%:  续{c:>4} 断{s:>5} 续板率{wr:>5.1f}%")

    # D+1是否涨停
    print(f"\n  ── D+1涨停/跌停 ──")
    for label, fn in [('D+1涨停', True), ('D+1跌停', False)]:
        if fn:
            c = sum(1 for x in cont if x['d1_is_limit_up'])
            s = sum(1 for x in stop if x['d1_is_limit_up'])
        else:
            c = sum(1 for x in cont if x['d1_is_limit_down'])
            s = sum(1 for x in stop if x['d1_is_limit_down'])
        total = c + s
        if total < 3:
            continue
        wr = c / total * 100
        print(f"  {label}: {c}续/{s}断 续板率{wr:.1f}% (共{total})")

    return d1_data


# ================================================================
# 分析2: 复合评分
# ================================================================

def analyze_composite_score(cycles):
    """多弱因子组合连续评分"""
    print(f"\n{'='*70}")
    print(f"  分析2: 复合评分系统")
    print(f"{'='*70}")

    # 提取所有D0特征
    features = []
    for cycle in cycles:
        rows = cycle['rows']
        threshold = cycle['threshold']
        limit_indices = find_limit_indices(rows, threshold)
        if not limit_indices:
            continue

        d0_idx = limit_indices[0]
        d0 = rows[d0_idx]
        prev = rows[d0_idx - 1]
        close = float(d0['close'])
        high = float(d0['high'])
        low = float(d0['low'])
        vol = float(d0['volume'])
        prev_close = float(prev['close'])
        prev_vol = float(prev['volume'])
        d0_open = float(d0['open'])

        if prev_close <= 0 or prev_vol <= 0:
            continue

        # 前5日均量
        vol_window = [float(rows[j]['volume']) for j in range(max(0, d0_idx-5), d0_idx)]
        avg_vol = sum(vol_window) / len(vol_window) if vol_window else vol

        # 前5日涨幅
        prev5_ret = None
        if d0_idx >= 5:
            p5c = float(rows[d0_idx-5]['close'])
            prev5_ret = (prev_close / p5c - 1) * 100 if p5c > 0 else None

        continued = len(limit_indices) > 1
        bar_range = (high - low) / prev_close * 100

        feat = {
            'code': cycle['code'],
            'n_limit': cycle['n_limit'],
            'continued': continued,
            # 原始因子
            'vol_ratio': vol / prev_vol,
            'vol_ratio_5d': vol / avg_vol if avg_vol > 0 else 0,
            'bar_range': bar_range,
            'upper_shadow': (high - close) / prev_close * 100,
            'body_pct': abs(close - d0_open) / prev_close * 100,
            'gap_pct': (d0_open / prev_close - 1) * 100,
            'ret': (close / prev_close - 1) * 100,
            'prev5_ret': prev5_ret,
            'seal_pct': (close - low) / close * 100 if close > 0 else 0,
        }

        # D+1 (如果有的话)
        if d0_idx + 1 < len(rows):
            d1 = rows[d0_idx + 1]
            d1_open = float(d1['open'])
            feat['d1_gap'] = (d1_open / close - 1) * 100 if close > 0 else 0

        features.append(feat)

    print(f"\n  样本: {len(features)}")
    cont = [x for x in features if x['continued']]
    stop = [x for x in features if not x['continued']]
    print(f"  续板: {len(cont)}  断板: {len(stop)}  基础续板率: {len(cont)/len(features)*100:.1f}%")

    # === 单因子评分 ===
    print(f"\n  ── 单因子评分 (各因子独立打分, 按区分度加权) ──")

    # 定义每个因子的评分函数 (返回0-100分)
    def score_vol_ratio(v):
        """量比越低越好"""
        if v <= 0.5: return 100
        if v <= 0.8: return 80
        if v <= 1.0: return 60
        if v <= 1.5: return 40
        if v <= 2.0: return 20
        return 0

    def score_bar_range(v):
        """振幅越小越好"""
        if v <= 3: return 100
        if v <= 5: return 80
        if v <= 7: return 60
        if v <= 9: return 40
        if v <= 12: return 20
        return 0

    def score_gap(v):
        """高开适度好 (3-8%最佳)"""
        if 3 <= v <= 8: return 100
        if 2 <= v < 3: return 70
        if 8 < v <= 10: return 60
        if 1 <= v < 2: return 50
        if 10 < v <= 15: return 30
        if 0 <= v < 1: return 30
        return 0

    def score_body(v):
        """实体越小越好"""
        if v <= 1: return 100
        if v <= 2: return 80
        if v <= 3: return 60
        if v <= 5: return 40
        return 20

    def score_prev5(v):
        """前5日微涨最佳"""
        if v is None: return 50
        if -2 <= v <= 5: return 100
        if 5 < v <= 10: return 70
        if -5 <= v < -2: return 60
        if 10 < v <= 20: return 40
        return 20

    scoring = [
        ('vol_ratio', score_vol_ratio, '量比'),
        ('bar_range', score_bar_range, '振幅'),
        ('gap_pct', score_gap, '高开幅度'),
        ('body_pct', score_body, '实体'),
        ('prev5_ret', score_prev5, '前5日涨幅'),
    ]

    # 计算每个因子的Cohen's d来确定权重
    weights = []
    for fname, _, label in scoring:
        c_vals = [x[fname] for x in cont if fname in x and x[fname] is not None]
        s_vals = [x[fname] for x in stop if fname in x and x[fname] is not None]
        if len(c_vals) < 5 or len(s_vals) < 5:
            weights.append((fname, label, 1.0))
            continue
        c_mean = sum(c_vals) / len(c_vals)
        s_mean = sum(s_vals) / len(s_vals)
        c_var = sum((v-c_mean)**2 for v in c_vals) / len(c_vals)
        s_var = sum((v-s_mean)**2 for v in s_vals) / len(s_vals)
        pooled = sqrt((c_var + s_var) / 2) if (c_var + s_var) > 0 else 1
        d = abs(c_mean - s_mean) / pooled
        weights.append((fname, label, max(d, 0.1)))

    total_w = sum(w for _, _, w in weights)
    print(f"  {'因子':<16} {'Cohen_d':>8} {'权重':>8}")
    print(f"  {'─'*34}")
    for fname, label, w in weights:
        print(f"  {label:<14} {w/total_w*100:>7.1f}%")

    # === 计算复合评分 ===
    for feat in features:
        total_score = 0
        for fname, score_fn, _ in scoring:
            val = feat.get(fname)
            if val is None:
                continue
            s = score_fn(val)
            w = dict(zip([f for f, _, _ in weights], [wt for _, _, wt in weights])).get(fname, 1.0)
            total_score += s * w
        feat['composite_score'] = total_score / total_w

    # 按评分分段看续板率
    print(f"\n  ── 复合评分 vs 续板率 ──")
    score_bins = [(0,20),(20,30),(30,40),(40,50),(50,60),(60,70),(70,80),(80,90),(90,101)]
    print(f"  {'评分区间':<14} {'续板':>6} {'断板':>6} {'续板率':>8} {'样本占比':>8}")
    print(f"  {'─'*46}")
    for lo, hi in score_bins:
        c = sum(1 for x in features if x['continued'] and lo <= x['composite_score'] < hi)
        s = sum(1 for x in features if not x['continued'] and lo <= x['composite_score'] < hi)
        total = c + s
        if total < 5:
            continue
        wr = c / total * 100
        pct = total / len(features) * 100
        star = "⭐" if wr > 25 else "  "
        print(f"  {star}{lo:>3}~{hi:<3}分      {c:>6} {s:>6} {wr:>7.1f}% {pct:>7.1f}%")

    # === vs 原始硬阈值 ===
    print(f"\n  ── 复合评分 vs V1硬阈值 对比 ──")
    # V1硬阈值
    v1_pass = [x for x in features if x['vol_ratio'] >= 2 and x['upper_shadow'] < 0.5 and x['bar_range'] >= 0.2]
    v1_cont = sum(1 for x in v1_pass if x['continued'])
    v1_wr = v1_cont / len(v1_pass) * 100 if v1_pass else 0

    # 复合评分各阈值
    for thresh in [40, 50, 60, 70, 80]:
        passed = [x for x in features if x['composite_score'] >= thresh]
        p_cont = sum(1 for x in passed if x['continued'])
        p_wr = p_cont / len(passed) * 100 if passed else 0
        print(f"  评分>={thresh}: {len(passed):>5}只 续板率{p_wr:>5.1f}%  "
              f"(V1硬阈值: {len(v1_pass)}只 续板率{v1_wr:>5.1f}%)")

    # 最优评分阈值搜索
    print(f"\n  ── 最优阈值搜索 (最大化 续板率 × 样本量) ──")
    best = None
    for thresh in range(20, 90, 5):
        passed = [x for x in features if x['composite_score'] >= thresh]
        if len(passed) < 10:
            continue
        p_cont = sum(1 for x in passed if x['continued'])
        p_wr = p_cont / len(passed) * 100
        # F1-like score: 2 * precision * recall / (precision + recall)
        recall = p_cont / len(cont) * 100 if cont else 0
        f1 = 2 * p_wr * recall / (p_wr + recall) if (p_wr + recall) > 0 else 0
        if best is None or f1 > best['f1']:
            best = {'thresh': thresh, 'n': len(passed), 'wr': p_wr, 'recall': recall, 'f1': f1}

    if best:
        print(f"  最优: 评分>={best['thresh']}  样本{best['n']}只  "
              f"续板率{best['wr']:.1f}%  召回率{best['recall']:.1f}%  F1={best['f1']:.1f}")

    return features


# ================================================================
# 分析3: D0涨停类型细分
# ================================================================

def analyze_d0_type(cycles):
    """D0涨停类型: 封板时间/方式/位置 细分"""
    print(f"\n{'='*70}")
    print(f"  分析3: D0涨停类型细分")
    print(f"{'='*70}")

    d0_types = []
    for cycle in cycles:
        rows = cycle['rows']
        threshold = cycle['threshold']
        limit_indices = find_limit_indices(rows, threshold)
        if not limit_indices:
            continue

        d0_idx = limit_indices[0]
        d0 = rows[d0_idx]
        prev = rows[d0_idx - 1]
        close = float(d0['close'])
        high = float(d0['high'])
        low = float(d0['low'])
        d0_open = float(d0['open'])
        vol = float(d0['volume'])
        prev_close = float(prev['close'])
        prev_vol = float(prev['volume'])

        if prev_close <= 0 or prev_vol <= 0:
            continue

        continued = len(limit_indices) > 1
        gap = (d0_open / prev_close - 1) * 100
        bar_range = (high - low) / prev_close * 100
        body = abs(close - d0_open) / prev_close * 100

        # 封板方式
        if bar_range < 0.2:
            seal_type = 'one_word'  # 一字板
        elif gap >= 8 and (close / prev_close - 1) >= threshold * 0.98:
            seal_type = 'open_limit'  # 开盘秒板
        elif (high - close) / prev_close * 100 < 0.3:
            seal_type = 'tight_seal'  # 封死无分歧
        else:
            seal_type = 'loose_seal'  # 封板有分歧

        # 开盘位置
        if gap >= 5:
            open_type = 'high_open'
        elif gap >= 2:
            open_type = 'mid_open'
        elif gap >= 0:
            open_type = 'flat_open'
        else:
            open_type = 'low_open'

        # D-1走势 (前一天)
        d_1_type = 'unknown'
        if d0_idx >= 2:
            prev2 = rows[d0_idx - 2]
            prev2_close = float(prev2['close'])
            if prev2_close > 0:
                d_1_ret = (prev_close / prev2_close - 1) * 100
                if d_1_ret >= 5:
                    d_1_type = 'd_1_strong'
                elif d_1_ret >= 0:
                    d_1_type = d_1_type = 'd_1_up'
                elif d_1_ret >= -3:
                    d_1_type = 'd_1_flat_down'
                else:
                    d_1_type = 'd_1_weak'

        # 是否近期有涨停 (非首次)
        is_first_limit = True
        if d0_idx >= 3:
            for j in range(max(1, d0_idx - 10), d0_idx):
                pj = rows[j - 1]
                cj = float(rows[j]['close'])
                pc = float(pj['close'])
                if pc > 0 and (cj / pc - 1) >= threshold * 0.98:
                    is_first_limit = False
                    break

        d0_types.append({
            'code': cycle['code'],
            'n_limit': cycle['n_limit'],
            'bt': cycle['bt'],
            'continued': continued,
            'seal_type': seal_type,
            'open_type': open_type,
            'd_1_type': d_1_type,
            'is_first_limit': is_first_limit,
            'gap': gap,
            'bar_range': bar_range,
            'body': body,
            'vol_ratio': vol / prev_vol,
        })

    cont = [x for x in d0_types if x['continued']]
    stop = [x for x in d0_types if not x['continued']]
    print(f"\n  样本: 续板={len(cont)} 断板={len(stop)}")

    # 封板方式
    print(f"\n  ── 封板方式 vs 续板率 ──")
    seal_labels = {
        'one_word': '一字板',
        'open_limit': '开盘秒板',
        'tight_seal': '封死无分歧',
        'loose_seal': '封板有分歧',
    }
    print(f"  {'封板方式':<16} {'续板':>6} {'断板':>6} {'续板率':>8} {'占比':>6}")
    print(f"  {'─'*46}")
    for st in ['one_word', 'open_limit', 'tight_seal', 'loose_seal']:
        c = sum(1 for x in cont if x['seal_type'] == st)
        s = sum(1 for x in stop if x['seal_type'] == st)
        total = c + s
        if total < 3:
            continue
        wr = c / total * 100
        pct = total / len(d0_types) * 100
        star = "⭐" if wr > 25 else "  "
        print(f"  {star}{seal_labels[st]:<14} {c:>6} {s:>6} {wr:>7.1f}% {pct:>5.1f}%")

    # 开盘位置
    print(f"\n  ── 开盘位置 vs 续板率 ──")
    open_labels = {
        'high_open': '高开(>=5%)',
        'mid_open': '中开(2~5%)',
        'flat_open': '平开(0~2%)',
        'low_open': '低开(<0%)',
    }
    print(f"  {'开盘位置':<16} {'续板':>6} {'断板':>6} {'续板率':>8}")
    print(f"  {'─'*40}")
    for ot in ['high_open', 'mid_open', 'flat_open', 'low_open']:
        c = sum(1 for x in cont if x['open_type'] == ot)
        s = sum(1 for x in stop if x['open_type'] == ot)
        total = c + s
        if total < 5:
            continue
        wr = c / total * 100
        star = "⭐" if wr > 25 else "  "
        print(f"  {star}{open_labels[ot]:<14} {c:>6} {s:>6} {wr:>7.1f}%")

    # D-1走势
    print(f"\n  ── D-1(前一天)走势 vs 续板率 ──")
    d1_labels = {
        'd_1_strong': 'D-1强势(>=5%)',
        'd_1_up': 'D-1上涨(0~5%)',
        'd_1_flat_down': 'D-1微跌(0~-3%)',
        'd_1_weak': 'D-1弱势(<-3%)',
        'unknown': '未知',
    }
    print(f"  {'D-1类型':<20} {'续板':>6} {'断板':>6} {'续板率':>8}")
    print(f"  {'─'*44}")
    for dt in ['d_1_strong', 'd_1_up', 'd_1_flat_down', 'd_1_weak', 'unknown']:
        c = sum(1 for x in cont if x['d_1_type'] == dt)
        s = sum(1 for x in stop if x['d_1_type'] == dt)
        total = c + s
        if total < 5:
            continue
        wr = c / total * 100
        star = "⭐" if wr > 25 else "  "
        print(f"  {star}{d1_labels[dt]:<18} {c:>6} {s:>6} {wr:>7.1f}%")

    # 首次涨停 vs 非首次
    print(f"\n  ── 首次涨停 vs 近期有涨停 ──")
    for label, fn in [('首次涨停(10日内)', True), ('近期有涨停', False)]:
        c = sum(1 for x in cont if x['is_first_limit'] == fn)
        s = sum(1 for x in stop if x['is_first_limit'] == fn)
        total = c + s
        if total < 5:
            continue
        wr = c / total * 100
        print(f"  {label}: {c}续/{s}断 续板率{wr:.1f}% (共{total})")

    # 组合: 封板方式 × 开盘位置
    print(f"\n  ── 封板方式 × 开盘位置 组合 ──")
    print(f"  {'组合':<28} {'续板':>6} {'断板':>6} {'续板率':>8}")
    print(f"  {'─'*50}")
    combos = []
    for st in ['tight_seal', 'loose_seal', 'open_limit']:
        for ot in ['high_open', 'mid_open', 'flat_open', 'low_open']:
            c = sum(1 for x in cont if x['seal_type'] == st and x['open_type'] == ot)
            s = sum(1 for x in stop if x['seal_type'] == st and x['open_type'] == ot)
            total = c + s
            if total < 5:
                continue
            wr = c / total * 100
            combos.append((f"{seal_labels[st]}×{open_labels[ot]}", c, s, wr, total))
    combos.sort(key=lambda x: -x[3])
    for label, c, s, wr, total in combos:
        star = "⭐" if wr > 30 else "  "
        print(f"  {star}{label:<26} {c:>6} {s:>6} {wr:>7.1f}%")

    return d0_types


# ================================================================
# 主函数
# ================================================================

def main():
    csv_path = os.path.join(SCRIPT_DIR, 'analysis_output', 'dragon_ohlcv.csv')
    print("📊 加载数据...")
    cycles = load_cycles(csv_path)
    print(f"   连板段: {len(cycles)}")

    d1_data = analyze_d1_intraday(cycles)
    composite = analyze_composite_score(cycles)
    d0_types = analyze_d0_type(cycles)

    # 保存
    out = os.path.join(SCRIPT_DIR, 'analysis_output', 'v1_deep_analysis.json')
    with open(out, 'w', encoding='utf-8') as f:
        json.dump({
            'd1_intraday': d1_data,
            'composite': composite,
            'd0_types': d0_types,
        }, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n💾 保存: {out}")


if __name__ == '__main__':
    main()
