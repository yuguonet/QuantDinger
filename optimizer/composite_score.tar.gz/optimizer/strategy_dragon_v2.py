#!/usr/bin/env python3
"""
连板猎手 V2 — 复合评分策略

基于V1深度分析的复合评分系统:
- 实体比 (33.4%) — 越小越好
- 振幅 (27.0%) — 越小越好
- 前5日涨幅 (13.1%) — 微涨最佳
- 量比 (14.9%) — 越低越好
- 高开幅度 (11.7%) — 3-8%最佳

用法:
  python optimizer/strategy_dragon_v2.py --csv analysis_output/dragon_ohlcv.csv
  python optimizer/strategy_dragon_v2.py --csv analysis_output/dragon_ohlcv.csv --min-score 60
  python optimizer/strategy_dragon_v2.py --csv analysis_output/dragon_ohlcv.csv --compare-v1
"""
from __future__ import annotations
import os, sys, csv, argparse
from collections import defaultdict
from math import sqrt

_optimizer_dir = os.path.dirname(os.path.abspath(__file__))
_project_root = os.path.dirname(_optimizer_dir)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

# ================================================================
# V2 评分函数
# ================================================================

def score_vol_ratio(v):
    """量比越低越好"""
    if v <= 0.5: return 100
    if v <= 0.8: return 80
    if v <= 1.0: return 60
    if v <= 1.5: return 40
    if v <= 2.0: return 20
    return 0

def score_bar_range(v):
    """振幅越小越好"""
    if v <= 3: return 100
    if v <= 5: return 80
    if v <= 7: return 60
    if v <= 9: return 40
    if v <= 12: return 20
    return 0

def score_gap(v):
    """高开适度好 (3-8%最佳)"""
    if 3 <= v <= 8: return 100
    if 2 <= v < 3: return 70
    if 8 < v <= 10: return 60
    if 1 <= v < 2: return 50
    if 10 < v <= 15: return 30
    if 0 <= v < 1: return 30
    return 0

def score_body(v):
    """实体越小越好"""
    if v <= 1: return 100
    if v <= 2: return 80
    if v <= 3: return 60
    if v <= 5: return 40
    return 20

def score_prev5(v):
    """前5日微涨最佳"""
    if v is None: return 50
    if -2 <= v <= 5: return 100
    if 5 < v <= 10: return 70
    if -5 <= v < -2: return 60
    if 10 < v <= 20: return 40
    return 20

# 权重 (来自Cohen's d分析, 归一化)
WEIGHTS = {
    'vol_ratio': 0.149,
    'bar_range': 0.270,
    'gap_pct':   0.117,
    'body_pct':  0.334,
    'prev5_ret': 0.131,
}
TOTAL_W = sum(WEIGHTS.values())

SCORING = {
    'vol_ratio': score_vol_ratio,
    'bar_range': score_bar_range,
    'gap_pct':   score_gap,
    'body_pct':  score_body,
    'prev5_ret': score_prev5,
}


def compute_composite_score(feat):
    """计算复合评分 (0-100)"""
    total = 0
    for fname, score_fn in SCORING.items():
        val = feat.get(fname)
        if val is None:
            continue
        s = score_fn(val)
        w = WEIGHTS.get(fname, 0)
        total += s * w
    return total / TOTAL_W


# ================================================================
# V2 回测
# ================================================================

def try_float(v, default=0.0):
    try: return float(v)
    except: return default

def get_board_type(code):
    c = str(code)[:3]
    if c.startswith("30") or c.startswith("68"): return "gem_star"
    return "main"

def get_board_name(code):
    c = str(code)[:3]
    if c.startswith("68"): return "科创板"
    elif c.startswith("30"): return "创业板"
    elif c.startswith("6"): return "沪主板"
    elif c.startswith(("0","2")): return "深主板"
    return "未知"

BOARD_PARAMS = {
    "main": {"threshold": 0.098, "stop_loss_pct": -8, "trailing_stop_pct": -6, "take_profit_pct": 15},
    "gem_star": {"threshold": 0.198, "stop_loss_pct": -12, "trailing_stop_pct": -8, "take_profit_pct": 20},
}


def backtest_v2_csv(rows, params, min_score=70, max_d1_gap=2.0):
    """V2回测: 复合评分选股 + D+1开盘买入"""
    if len(rows) < 7:
        return []

    threshold = params["threshold"]

    # 找第一板
    first_limit_idx = None
    for i in range(1, len(rows)):
        close = try_float(rows[i]["close"])
        prev_close = try_float(rows[i-1]["close"])
        if prev_close <= 0: continue
        ret = (close / prev_close - 1)
        if ret >= threshold * 0.98:
            if i >= 2:
                prev2_close = try_float(rows[i-2]["close"])
                if prev2_close > 0 and prev_close / prev2_close - 1 >= threshold * 0.98:
                    continue
            first_limit_idx = i
            break

    if first_limit_idx is None or first_limit_idx < 5:
        return []

    fl = rows[first_limit_idx]
    prev = rows[first_limit_idx - 1]
    fl_close = try_float(fl["close"])
    fl_high = try_float(fl["high"])
    fl_low = try_float(fl["low"])
    fl_vol = try_float(fl["volume"])
    fl_open = try_float(fl["open"])
    prev_close = try_float(prev["close"])
    prev_vol = try_float(prev["volume"])

    if prev_close <= 0 or prev_vol <= 0:
        return []

    # 前5日均量
    vol_window = [try_float(rows[j]["volume"]) for j in range(max(0, first_limit_idx-5), first_limit_idx)]
    avg_vol = sum(vol_window) / len(vol_window) if vol_window else fl_vol

    # 前5日涨幅
    prev5_ret = None
    if first_limit_idx >= 5:
        p5c = try_float(rows[first_limit_idx - 5]["close"])
        prev5_ret = (prev_close / p5c - 1) * 100 if p5c > 0 else None

    # 构建特征
    bar_range = (fl_high - fl_low) / prev_close * 100
    feat = {
        'vol_ratio': fl_vol / prev_vol,
        'bar_range': bar_range,
        'gap_pct': (fl_open / prev_close - 1) * 100,
        'body_pct': abs(fl_close - fl_open) / prev_close * 100,
        'prev5_ret': prev5_ret,
        'upper_shadow': (fl_high - fl_close) / prev_close * 100,
    }

    # 一字板排除
    if bar_range < 0.2:
        return []

    # 复合评分
    score = compute_composite_score(feat)
    if score < min_score:
        return []

    # D+1
    if first_limit_idx + 1 >= len(rows):
        return []
    d1 = rows[first_limit_idx + 1]
    d1_open = try_float(d1["open"])
    if d1_open <= 0:
        return []

    d1_gap = (d1_open / fl_close - 1) * 100
    if d1_gap > max_d1_gap:
        return []

    # 持仓回测
    trades = []
    buy_price = d1_open
    highest = buy_price
    for i in range(first_limit_idx + 2, len(rows)):
        close = try_float(rows[i]["close"])
        high = try_float(rows[i]["high"])
        if high > highest:
            highest = high
        ret_from_buy = (close / buy_price - 1) * 100
        ret_from_high = (close / highest - 1) * 100 if highest > 0 else 0

        sell = False
        sell_type = ""
        if ret_from_buy <= params["stop_loss_pct"]:
            sell = True; sell_type = "stop_loss"
        elif ret_from_high <= params["trailing_stop_pct"] and ret_from_buy > 0:
            sell = True; sell_type = "trailing_stop"
        elif ret_from_buy >= params["take_profit_pct"]:
            sell = True; sell_type = "take_profit"

        if sell:
            trades.append({
                "buy_date": rows[first_limit_idx + 1]["time"],
                "buy_price": buy_price,
                "sell_date": rows[i]["time"],
                "sell_price": close,
                "return_pct": round(ret_from_buy, 2),
                "max_return_pct": round((highest / buy_price - 1) * 100, 2),
                "sell_type": sell_type,
                "composite_score": round(score, 1),
                "d1_gap": round(d1_gap, 2),
            })
            return trades

    # 数据结束
    last_close = try_float(rows[-1]["close"])
    trades.append({
        "buy_date": rows[first_limit_idx + 1]["time"],
        "buy_price": buy_price,
        "sell_date": rows[-1]["time"],
        "sell_price": last_close,
        "return_pct": round((last_close / buy_price - 1) * 100, 2),
        "max_return_pct": round((highest / buy_price - 1) * 100, 2),
        "sell_type": "end_of_data",
        "composite_score": round(score, 1),
        "d1_gap": round(d1_gap, 2),
    })
    return trades


def backtest_v1_csv(rows, params, max_d1_gap=2.0, min_vol_ratio=2.0, max_upper_shadow=0.5):
    """V1回测 (原版, 用于对比)"""
    if len(rows) < 6:
        return []
    threshold = params["threshold"]
    first_limit_idx = None
    for i in range(1, len(rows)):
        close = try_float(rows[i]["close"])
        prev_close = try_float(rows[i-1]["close"])
        if prev_close <= 0: continue
        ret = (close / prev_close - 1)
        if ret >= threshold * 0.98:
            if i >= 2:
                prev2_close = try_float(rows[i-2]["close"])
                if prev2_close > 0 and prev_close / prev2_close - 1 >= threshold * 0.98:
                    continue
            first_limit_idx = i
            break
    if first_limit_idx is None or first_limit_idx < 2:
        return []

    fl = rows[first_limit_idx]
    prev = rows[first_limit_idx - 1]
    fl_close = try_float(fl["close"])
    fl_high = try_float(fl["high"])
    fl_low = try_float(fl["low"])
    fl_vol = try_float(fl["volume"])
    prev_close = try_float(prev["close"])
    prev_vol = try_float(prev["volume"])
    prev2_close = try_float(rows[first_limit_idx - 2]["close"]) if first_limit_idx >= 2 else prev_close

    if prev_close <= 0 or fl_close <= 0 or prev_vol <= 0:
        return []

    bar_range = (fl_high - fl_low) / prev2_close * 100
    if bar_range < 0.2: return []
    vol_ratio = fl_vol / prev_vol
    if vol_ratio < min_vol_ratio: return []
    upper_shadow = (fl_high - fl_close) / prev2_close * 100
    if upper_shadow >= max_upper_shadow: return []

    if first_limit_idx + 1 >= len(rows): return []
    d1 = rows[first_limit_idx + 1]
    d1_open = try_float(d1["open"])
    if d1_open <= 0: return []
    d1_gap = (d1_open / fl_close - 1) * 100
    if d1_gap > max_d1_gap: return []

    buy_price = d1_open
    highest = buy_price
    for i in range(first_limit_idx + 2, len(rows)):
        close = try_float(rows[i]["close"])
        high = try_float(rows[i]["high"])
        if high > highest: highest = high
        ret_from_buy = (close / buy_price - 1) * 100
        ret_from_high = (close / highest - 1) * 100 if highest > 0 else 0
        sell = False
        sell_type = ""
        if ret_from_buy <= params["stop_loss_pct"]:
            sell = True; sell_type = "stop_loss"
        elif ret_from_high <= params["trailing_stop_pct"] and ret_from_buy > 0:
            sell = True; sell_type = "trailing_stop"
        elif ret_from_buy >= params["take_profit_pct"]:
            sell = True; sell_type = "take_profit"
        if sell:
            return [{"buy_date": rows[first_limit_idx+1]["time"], "buy_price": buy_price,
                      "sell_date": rows[i]["time"], "sell_price": close,
                      "return_pct": round(ret_from_buy, 2),
                      "max_return_pct": round((highest/buy_price-1)*100, 2),
                      "sell_type": sell_type, "vol_ratio": round(vol_ratio, 2),
                      "upper_shadow": round(upper_shadow, 4), "d1_gap": round(d1_gap, 2)}]
    last_close = try_float(rows[-1]["close"])
    return [{"buy_date": rows[first_limit_idx+1]["time"], "buy_price": buy_price,
              "sell_date": rows[-1]["time"], "sell_price": last_close,
              "return_pct": round((last_close/buy_price-1)*100, 2),
              "max_return_pct": round((highest/buy_price-1)*100, 2),
              "sell_type": "end_of_data", "vol_ratio": round(vol_ratio, 2),
              "upper_shadow": round(upper_shadow, 4), "d1_gap": round(d1_gap, 2)}]


# ================================================================
# 全量回测 + 对比
# ================================================================

def run_backtest(csv_path, min_score=70, max_d1_gap=2.0, compare_v1=False):
    """V2全量回测"""
    groups = defaultdict(list)
    with open(csv_path, encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            key = (row["code"], row["run_first_limit_date"])
            groups[key].append(row)
    for key in groups:
        groups[key].sort(key=lambda x: x["time"])

    total = len(groups)
    print(f"📊 加载 {total} 连板段")

    # V2 回测
    v2_trades = []
    for (code, fl_str), rows in groups.items():
        board_type = get_board_type(code)
        params = BOARD_PARAMS[board_type]
        try:
            n_limit = int(rows[0].get("run_n_limit_ups", 1))
        except:
            n_limit = 1
        if n_limit < 2:
            continue
        trades = backtest_v2_csv(rows, params, min_score, max_d1_gap)
        for t in trades:
            t["code"] = code
            t["board"] = get_board_name(code)
            t["board_type"] = board_type
            t["n_limit"] = n_limit
        v2_trades.extend(trades)

    print_summary(v2_trades, f"V2 (评分>={min_score})")

    # V1 对比
    if compare_v1:
        v1_trades = []
        for (code, fl_str), rows in groups.items():
            board_type = get_board_type(code)
            params = BOARD_PARAMS[board_type]
            try:
                n_limit = int(rows[0].get("run_n_limit_ups", 1))
            except:
                n_limit = 1
            if n_limit < 2:
                continue
            trades = backtest_v1_csv(rows, params, max_d1_gap)
            for t in trades:
                t["code"] = code
                t["board"] = get_board_name(code)
                t["board_type"] = board_type
                t["n_limit"] = n_limit
            v1_trades.extend(trades)

        print_summary(v1_trades, "V1 (原始)")

        # 评分阈值扫描
        print(f"\n{'='*70}")
        print(f"  V2评分阈值扫描")
        print(f"{'='*70}")
        print(f"  {'阈值':<8} {'笔数':<8} {'胜率':<10} {'均收益':<12} {'盈亏比':<8}")
        print(f"  {'─'*48}")
        for thresh in [30, 40, 50, 55, 60, 65, 70, 75, 80, 85, 90]:
            trades_t = []
            for (code, fl_str), rows in groups.items():
                board_type = get_board_type(code)
                params = BOARD_PARAMS[board_type]
                try:
                    n_limit = int(rows[0].get("run_n_limit_ups", 1))
                except:
                    n_limit = 1
                if n_limit < 2:
                    continue
                trades_t.extend(backtest_v2_csv(rows, params, thresh, max_d1_gap))
            if not trades_t:
                continue
            rets = [t["return_pct"] for t in trades_t]
            wins = [r for r in rets if r > 0]
            losses = [r for r in rets if r < 0]
            wr = len(wins) / len(rets) * 100 if rets else 0
            avg = sum(rets) / len(rets) if rets else 0
            pl = sum(wins)/len(wins) / abs(sum(losses)/len(losses)) if wins and losses else 0
            print(f"  {thresh:<8} {len(trades_t):<8} {wr:<10.1f} {avg:<+12.2f} {pl:<8.2f}")

    return v2_trades


def print_summary(trades, label=""):
    if not trades:
        print(f"\n  {label}: ❌ 无交易信号")
        return

    rets = [t["return_pct"] for t in trades]
    wins = [r for r in rets if r > 0]
    losses = [r for r in rets if r < 0]

    print(f"\n{'='*70}")
    print(f"  {label} 回测结果")
    print(f"{'='*70}")
    print(f"  总交易数: {len(trades)}")
    print(f"  胜率: {len(wins)/len(rets)*100:.1f}%")
    print(f"  平均收益: {sum(rets)/len(rets):.2f}%")
    print(f"  中位收益: {sorted(rets)[len(rets)//2]:.2f}%")
    if wins and losses:
        print(f"  盈亏比: {sum(wins)/len(wins) / abs(sum(losses)/len(losses)):.2f}")

    # 按板块
    by_bt = defaultdict(list)
    for t in trades:
        by_bt[t.get("board_type", "unknown")].append(t)
    for bt in ["main", "gem_star"]:
        sub = by_bt.get(bt, [])
        if not sub: continue
        blabel = "沪深主板" if bt == "main" else "创/科板"
        sub_rets = [t["return_pct"] for t in sub]
        sub_wins = [r for r in sub_rets if r > 0]
        print(f"\n  --- {blabel} ({len(sub)}笔) ---")
        print(f"    胜率: {len(sub_wins)/len(sub_rets)*100:.1f}%")
        print(f"    均收益: {sum(sub_rets)/len(sub_rets):.2f}%")

    # 按连板数
    by_nl = defaultdict(list)
    for t in trades:
        by_nl[t.get("n_limit", 0)].append(t)
    print(f"\n  --- 按连板数 ---")
    for nl in sorted(by_nl.keys()):
        sub = by_nl[nl]
        if len(sub) < 3: continue
        sub_rets = [t["return_pct"] for t in sub]
        sub_wins = [r for r in sub_rets if r > 0]
        print(f"    {nl}板: {len(sub)}笔 胜率{len(sub_wins)/len(sub_rets)*100:.1f}% 均收益{sum(sub_rets)/len(sub_rets):.2f}%")

    # 卖出类型
    print(f"\n  --- 卖出类型 ---")
    by_st = defaultdict(list)
    for t in trades:
        by_st[t.get("sell_type", "unknown")].append(t)
    for st in ["take_profit", "trailing_stop", "stop_loss", "end_of_data"]:
        st_trades = by_st.get(st, [])
        if not st_trades: continue
        sub_rets = [t["return_pct"] for t in st_trades]
        print(f"    {st}: {len(st_trades)}笔 均收益{sum(sub_rets)/len(sub_rets):.2f}%")


def main():
    parser = argparse.ArgumentParser(description="连板猎手V2 — 复合评分策略")
    parser.add_argument("--csv", default="analysis_output/dragon_ohlcv.csv")
    parser.add_argument("--min-score", type=float, default=70, help="最低评分阈值 (默认70)")
    parser.add_argument("--max-d1-gap", type=float, default=2.0, help="D+1最大高开% (默认2.0)")
    parser.add_argument("--compare-v1", action="store_true", help="同时运行V1对比")
    args = parser.parse_args()

    csv_path = args.csv
    if not os.path.isabs(csv_path):
        csv_path = os.path.join(_project_root, csv_path)

    trades = run_backtest(csv_path, args.min_score, args.max_d1_gap, args.compare_v1)

    if trades:
        out_path = os.path.join(_project_root, "analysis_output", "backtest_v2_trades.csv")
        fieldnames = list(trades[0].keys())
        with open(out_path, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(trades)
        print(f"\n💾 交易明细: {out_path}")


if __name__ == "__main__":
    main()
