#!/usr/bin/env python3
"""
连板猎手 V2.1 — 方向过滤 + 复合评分叠加策略

第一层: 方向过滤 (跳空高开 + 低量比 + 小振幅)
第二层: 复合评分 (实体 + 振幅 + 前5日 + 量比 + 高开)

叠加: 方向过滤通过后, 用复合评分排序, 优先买入高分标的
"""
from __future__ import annotations
import os, sys, csv, argparse
from collections import defaultdict
from math import sqrt

_optimizer_dir = os.path.dirname(os.path.abspath(__file__))
_project_root = os.path.dirname(_optimizer_dir)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

# ================================================================
# 评分函数
# ================================================================

def score_vol_ratio(v):
    if v <= 0.5: return 100
    if v <= 0.8: return 80
    if v <= 1.0: return 60
    if v <= 1.5: return 40
    if v <= 2.0: return 20
    return 0

def score_bar_range(v):
    if v <= 3: return 100
    if v <= 5: return 80
    if v <= 7: return 60
    if v <= 9: return 40
    if v <= 12: return 20
    return 0

def score_gap(v):
    if 3 <= v <= 8: return 100
    if 2 <= v < 3: return 70
    if 8 < v <= 10: return 60
    if 1 <= v < 2: return 50
    if 10 < v <= 15: return 30
    if 0 <= v < 1: return 30
    return 0

def score_body(v):
    if v <= 1: return 100
    if v <= 2: return 80
    if v <= 3: return 60
    if v <= 5: return 40
    return 20

def score_prev5(v):
    if v is None: return 50
    if -2 <= v <= 5: return 100
    if 5 < v <= 10: return 70
    if -5 <= v < -2: return 60
    if 10 < v <= 20: return 40
    return 20

WEIGHTS = {
    'vol_ratio': 0.149,
    'bar_range': 0.270,
    'gap_pct':   0.117,
    'body_pct':  0.334,
    'prev5_ret': 0.131,
}
TOTAL_W = sum(WEIGHTS.values())
SCORING = {
    'vol_ratio': score_vol_ratio,
    'bar_range': score_bar_range,
    'gap_pct':   score_gap,
    'body_pct':  score_body,
    'prev5_ret': score_prev5,
}

def compute_score(feat):
    total = 0
    for fname, score_fn in SCORING.items():
        val = feat.get(fname)
        if val is None: continue
        total += score_fn(val) * WEIGHTS.get(fname, 0)
    return total / TOTAL_W

# ================================================================
# 通用
# ================================================================

def try_float(v, default=0.0):
    try: return float(v)
    except: return default

def get_board_type(code):
    c = str(code)[:3]
    if c.startswith("30") or c.startswith("68"): return "gem_star"
    return "main"

def get_board_name(code):
    c = str(code)[:3]
    if c.startswith("68"): return "科创板"
    elif c.startswith("30"): return "创业板"
    elif c.startswith("6"): return "沪主板"
    elif c.startswith(("0","2")): return "深主板"
    return "未知"

BOARD_PARAMS = {
    "main": {"threshold": 0.098, "stop_loss_pct": -8, "trailing_stop_pct": -6, "take_profit_pct": 15},
    "gem_star": {"threshold": 0.198, "stop_loss_pct": -12, "trailing_stop_pct": -8, "take_profit_pct": 20},
}

# ================================================================
# V2.1 叠加策略回测
# ================================================================

def backtest_v21(rows, params, direction, min_score=0, max_d1_gap=2.0):
    """
    V2.1: 方向过滤 + 复合评分叠加

    direction: dict of directional filters
      - min_gap: 最低跳空%
      - max_vol_ratio: 最高量比
      - max_range: 最高振幅%
    """
    if len(rows) < 7:
        return []

    threshold = params["threshold"]

    # 找第一板
    first_limit_idx = None
    for i in range(1, len(rows)):
        close = try_float(rows[i]["close"])
        prev_close = try_float(rows[i-1]["close"])
        if prev_close <= 0: continue
        ret = (close / prev_close - 1)
        if ret >= threshold * 0.98:
            if i >= 2:
                prev2_close = try_float(rows[i-2]["close"])
                if prev2_close > 0 and prev_close / prev2_close - 1 >= threshold * 0.98:
                    continue
            first_limit_idx = i
            break

    if first_limit_idx is None or first_limit_idx < 5:
        return []

    fl = rows[first_limit_idx]
    prev = rows[first_limit_idx - 1]
    fl_close = try_float(fl["close"])
    fl_high = try_float(fl["high"])
    fl_low = try_float(fl["low"])
    fl_vol = try_float(fl["volume"])
    fl_open = try_float(fl["open"])
    prev_close = try_float(prev["close"])
    prev_vol = try_float(prev["volume"])

    if prev_close <= 0 or prev_vol <= 0:
        return []

    # 一字板排除
    bar_range = (fl_high - fl_low) / prev_close * 100
    if bar_range < 0.2:
        return []

    # 前5日
    vol_window = [try_float(rows[j]["volume"]) for j in range(max(0, first_limit_idx-5), first_limit_idx)]
    avg_vol = sum(vol_window) / len(vol_window) if vol_window else fl_vol
    prev5_ret = None
    if first_limit_idx >= 5:
        p5c = try_float(rows[first_limit_idx - 5]["close"])
        prev5_ret = (prev_close / p5c - 1) * 100 if p5c > 0 else None

    gap_pct = (fl_open / prev_close - 1) * 100
    vol_ratio = fl_vol / prev_vol

    # === 第一层: 方向过滤 ===
    if direction.get('min_gap') is not None and gap_pct < direction['min_gap']:
        return []
    if direction.get('max_vol_ratio') is not None and vol_ratio > direction['max_vol_ratio']:
        return []
    if direction.get('max_range') is not None and bar_range > direction['max_range']:
        return []

    # === 第二层: 复合评分 ===
    feat = {
        'vol_ratio': vol_ratio,
        'bar_range': bar_range,
        'gap_pct': gap_pct,
        'body_pct': abs(fl_close - fl_open) / prev_close * 100,
        'prev5_ret': prev5_ret,
        'upper_shadow': (fl_high - fl_close) / prev_close * 100,
    }
    score = compute_score(feat)
    if score < min_score:
        return []

    # D+1
    if first_limit_idx + 1 >= len(rows):
        return []
    d1 = rows[first_limit_idx + 1]
    d1_open = try_float(d1["open"])
    if d1_open <= 0:
        return []
    d1_gap = (d1_open / fl_close - 1) * 100
    if d1_gap > max_d1_gap:
        return []

    # 持仓回测
    buy_price = d1_open
    highest = buy_price
    for i in range(first_limit_idx + 2, len(rows)):
        close = try_float(rows[i]["close"])
        high = try_float(rows[i]["high"])
        if high > highest: highest = high
        ret_from_buy = (close / buy_price - 1) * 100
        ret_from_high = (close / highest - 1) * 100 if highest > 0 else 0

        sell = False
        sell_type = ""
        if ret_from_buy <= params["stop_loss_pct"]:
            sell = True; sell_type = "stop_loss"
        elif ret_from_high <= params["trailing_stop_pct"] and ret_from_buy > 0:
            sell = True; sell_type = "trailing_stop"
        elif ret_from_buy >= params["take_profit_pct"]:
            sell = True; sell_type = "take_profit"

        if sell:
            return [{
                "buy_date": rows[first_limit_idx + 1]["time"], "buy_price": buy_price,
                "sell_date": rows[i]["time"], "sell_price": close,
                "return_pct": round(ret_from_buy, 2),
                "max_return_pct": round((highest / buy_price - 1) * 100, 2),
                "sell_type": sell_type, "composite_score": round(score, 1),
                "d1_gap": round(d1_gap, 2), "gap_pct": round(gap_pct, 2),
                "vol_ratio": round(vol_ratio, 2), "bar_range": round(bar_range, 2),
            }]

    last_close = try_float(rows[-1]["close"])
    return [{
        "buy_date": rows[first_limit_idx + 1]["time"], "buy_price": buy_price,
        "sell_date": rows[-1]["time"], "sell_price": last_close,
        "return_pct": round((last_close / buy_price - 1) * 100, 2),
        "max_return_pct": round((highest / buy_price - 1) * 100, 2),
        "sell_type": "end_of_data", "composite_score": round(score, 1),
        "d1_gap": round(d1_gap, 2), "gap_pct": round(gap_pct, 2),
        "vol_ratio": round(vol_ratio, 2), "bar_range": round(bar_range, 2),
    }]


# ================================================================
# V1 原版回测 (对比用)
# ================================================================

def backtest_v1(rows, params, max_d1_gap=2.0, min_vol_ratio=2.0, max_upper_shadow=0.5):
    if len(rows) < 6: return []
    threshold = params["threshold"]
    first_limit_idx = None
    for i in range(1, len(rows)):
        close = try_float(rows[i]["close"])
        prev_close = try_float(rows[i-1]["close"])
        if prev_close <= 0: continue
        if (close / prev_close - 1) >= threshold * 0.98:
            if i >= 2:
                p2 = try_float(rows[i-2]["close"])
                if p2 > 0 and (prev_close / p2 - 1) >= threshold * 0.98: continue
            first_limit_idx = i; break
    if not first_limit_idx or first_limit_idx < 2: return []

    fl = rows[first_limit_idx]
    prev = rows[first_limit_idx - 1]
    fl_close, fl_high, fl_low, fl_vol = try_float(fl["close"]), try_float(fl["high"]), try_float(fl["low"]), try_float(fl["volume"])
    prev_close, prev_vol = try_float(prev["close"]), try_float(prev["volume"])
    prev2_close = try_float(rows[first_limit_idx - 2]["close"]) if first_limit_idx >= 2 else prev_close
    if prev_close <= 0 or fl_close <= 0 or prev_vol <= 0 or prev2_close <= 0: return []

    bar_range = (fl_high - fl_low) / prev2_close * 100
    if bar_range < 0.2: return []
    vol_ratio = fl_vol / prev_vol
    if vol_ratio < min_vol_ratio: return []
    upper_shadow = (fl_high - fl_close) / prev2_close * 100
    if upper_shadow >= max_upper_shadow: return []

    if first_limit_idx + 1 >= len(rows): return []
    d1 = rows[first_limit_idx + 1]
    d1_open = try_float(d1["open"])
    if d1_open <= 0: return []
    d1_gap = (d1_open / fl_close - 1) * 100
    if d1_gap > max_d1_gap: return []

    buy_price = d1_open
    highest = buy_price
    for i in range(first_limit_idx + 2, len(rows)):
        c, h = try_float(rows[i]["close"]), try_float(rows[i]["high"])
        if h > highest: highest = h
        ret = (c / buy_price - 1) * 100
        ret_h = (c / highest - 1) * 100 if highest > 0 else 0
        if ret <= params["stop_loss_pct"]:
            return [{"return_pct": round(ret,2), "sell_type": "stop_loss", "max_return_pct": round((highest/buy_price-1)*100,2)}]
        elif ret_h <= params["trailing_stop_pct"] and ret > 0:
            return [{"return_pct": round(ret,2), "sell_type": "trailing_stop", "max_return_pct": round((highest/buy_price-1)*100,2)}]
        elif ret >= params["take_profit_pct"]:
            return [{"return_pct": round(ret,2), "sell_type": "take_profit", "max_return_pct": round((highest/buy_price-1)*100,2)}]
    last = try_float(rows[-1]["close"])
    return [{"return_pct": round((last/buy_price-1)*100,2), "sell_type": "end_of_data", "max_return_pct": round((highest/buy_price-1)*100,2)}]


# ================================================================
# 输出
# ================================================================

def print_summary(trades, label):
    if not trades:
        print(f"  {label}: ❌ 无信号")
        return
    rets = [t["return_pct"] for t in trades]
    wins = [r for r in rets if r > 0]
    losses = [r for r in rets if r < 0]
    wr = len(wins)/len(rets)*100 if rets else 0
    avg = sum(rets)/len(rets) if rets else 0
    pl = sum(wins)/len(wins) / abs(sum(losses)/len(losses)) if wins and losses else 0
    print(f"  {label:<40} {len(trades):>5}笔  胜率{wr:>5.1f}%  均收益{avg:>+6.2f}%  盈亏比{pl:>5.2f}")

    # 按连板数
    by_nl = defaultdict(list)
    for t in trades: by_nl[t.get("n_limit",0)].append(t)
    for nl in sorted(by_nl.keys()):
        sub = by_nl[nl]
        if len(sub) < 3: continue
        sr = [t["return_pct"] for t in sub]
        sw = [r for r in sr if r > 0]
        print(f"    {nl}板: {len(sub)}笔 胜率{len(sw)/len(sr)*100:.1f}% 均收益{sum(sr)/len(sr):+.2f}%")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", default="analysis_output/dragon_ohlcv.csv")
    parser.add_argument("--max-d1-gap", type=float, default=2.0)
    args = parser.parse_args()

    csv_path = args.csv
    if not os.path.isabs(csv_path):
        csv_path = os.path.join(_project_root, csv_path)

    # 加载
    groups = defaultdict(list)
    with open(csv_path, encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            groups[(row["code"], row["run_first_limit_date"])].append(row)
    for k in groups:
        groups[k].sort(key=lambda x: x["time"])

    def run(direction, min_score, label):
        trades = []
        for (code, _), rows in groups.items():
            bt = get_board_type(code)
            params = BOARD_PARAMS[bt]
            try: nl = int(rows[0].get("run_n_limit_ups", 1))
            except: nl = 1
            if nl < 2: continue
            t = backtest_v21(rows, params, direction, min_score, args.max_d1_gap)
            for x in t:
                x["code"] = code; x["board"] = get_board_name(code); x["n_limit"] = nl
            trades.extend(t)
        print_summary(trades, label)
        return trades

    print(f"\n{'='*70}")
    print(f"  连板猎手 V2.1 — 方向过滤 + 复合评分叠加")
    print(f"{'='*70}")

    # === V1 基准 ===
    v1_trades = []
    for (code, _), rows in groups.items():
        bt = get_board_type(code)
        params = BOARD_PARAMS[bt]
        try: nl = int(rows[0].get("run_n_limit_ups", 1))
        except: nl = 1
        if nl < 2: continue
        t = backtest_v1(rows, params, args.max_d1_gap)
        for x in t: x["code"] = code; x["board"] = get_board_name(code); x["n_limit"] = nl
        v1_trades.extend(t)
    print_summary(v1_trades, "V1基准 (量比>2x + 上影<0.5%)")

    print()

    # === 方向过滤单独 ===
    d1 = {'min_gap': 5}
    run(d1, 0, "方向: 跳空>5%")

    d2 = {'max_vol_ratio': 1.5}
    run(d2, 0, "方向: 量比<1.5x")

    d3 = {'max_range': 5}
    run(d3, 0, "方向: 振幅<5%")

    print()

    # === 双因子组合 ===
    d4 = {'min_gap': 5, 'max_vol_ratio': 1.5}
    run(d4, 0, "方向: 跳空>5% + 量比<1.5x")

    d5 = {'min_gap': 3, 'max_range': 7.5}
    run(d5, 0, "方向: 跳空>3% + 振幅<7.5%")

    d6 = {'min_gap': 5, 'max_range': 5}
    run(d6, 0, "方向: 跳空>5% + 振幅<5%")

    d7 = {'max_vol_ratio': 1.5, 'max_range': 5}
    run(d7, 0, "方向: 量比<1.5x + 振幅<5%")

    print()

    # === 三因子组合 ===
    d8 = {'min_gap': 5, 'max_vol_ratio': 1.5, 'max_range': 5}
    run(d8, 0, "方向: 跳空>5% + 量比<1.5x + 振幅<5%")

    d9 = {'min_gap': 3, 'max_vol_ratio': 1.5, 'max_range': 7.5}
    run(d9, 0, "方向: 跳空>3% + 量比<1.5x + 振幅<7.5%")

    print()

    # === 叠加: 方向过滤 + 复合评分 ===
    print(f"{'─'*70}")
    print(f"  叠加: 方向过滤 + 复合评分")
    print(f"{'─'*70}")

    base_dir = {'min_gap': 5, 'max_vol_ratio': 1.5}
    for score in [0, 30, 40, 50, 60, 70, 80]:
        run(base_dir, score, f"跳空>5%+量比<1.5x + 评分>={score}")

    print()
    base_dir2 = {'min_gap': 3, 'max_range': 7.5}
    for score in [0, 30, 40, 50, 60, 70, 80]:
        run(base_dir2, score, f"跳空>3%+振幅<7.5% + 评分>={score}")

    print()
    base_dir3 = {'min_gap': 5, 'max_vol_ratio': 1.5, 'max_range': 5}
    for score in [0, 30, 40, 50, 60, 70]:
        run(base_dir3, score, f"跳空>5%+量比<1.5x+振幅<5% + 评分>={score}")


if __name__ == "__main__":
    main()
